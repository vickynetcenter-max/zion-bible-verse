package com.vicky.tamilbible.games

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.random.Random

class LetterPathGameTest {

    private fun adjacent(n: Int, a: Int, b: Int) = abs(a / n - b / n) + abs(a % n - b % n) == 1

    @Test fun generatorAlwaysBuildsAFullValidPath() {
        for (n in 4..8) repeat(25) { seed ->
            val path = LetterPathGenerator.hamiltonianPath(n, Random(seed * 31 + n))
            assertEquals(n * n, path.size)
            assertEquals(n * n, path.toSet().size)                          // every cell exactly once
            path.zipWithNext().forEach { (a, b) -> assertTrue(adjacent(n, a, b)) }
        }
    }

    @Test fun lettersAreInOrderAlongTheSolution() {
        LetterPathLevels.ALL.forEachIndexed { i, level ->
            repeat(5) { seed ->
                val p = LetterPathGenerator.build(level, Random(seed + i * 100))
                val positions = p.letterAt.entries.sortedBy { it.value }.map { p.solution.indexOf(it.key) }
                assertEquals(level.letters.size, positions.size)
                assertEquals(0, positions.first())
                assertEquals(p.cells - 1, positions.last())
                positions.zipWithNext().forEach { (a, b) -> assertTrue(a < b) }
            }
        }
    }

    @Test fun followingTheSolutionSolvesEveryLevel() {
        LetterPathLevels.ALL.forEach { level ->
            val s = LetterPathState(LetterPathGenerator.build(level, Random(7)))
            s.puzzle.solution.forEachIndexed { i, cell ->
                assertEquals(if (i == 0) Move.STARTED else Move.ADDED, s.touch(cell))
            }
            assertTrue(s.solved)
        }
    }

    @Test fun mustStartOnTheFirstLetter() {
        val s = LetterPathState(LetterPathGenerator.build(LetterPathLevels.ALL[0], Random(1)))
        val notFirst = (0 until s.puzzle.cells).first { s.puzzle.letterAt[it] != 0 }
        assertEquals(Move.NOT_FIRST, s.touch(notFirst))
        assertTrue(s.path.isEmpty())
    }

    @Test fun letterOutOfOrderIsRefused() {
        // Hand-made 2-row board: path 0,1,2,3 / letters at 0 (first), 1 (second), 3 (third).
        val p = LetterPathPuzzle(2, listOf("அ", "ஆ", "இ"), listOf(0, 1, 3, 2), mapOf(0 to 0, 1 to 1, 2 to 2))
        val s = LetterPathState(p)
        assertEquals(Move.STARTED, s.touch(0))
        assertEquals(Move.NOT_NEXT, s.touch(2))                            // third letter before the second
        assertEquals(listOf(0), s.path)
        assertEquals(Move.ADDED, s.touch(1))
    }

    @Test fun noDiagonalNoRevisitBackRemovesAndCut() {
        val p = LetterPathGenerator.build(LetterPathLevel(listOf("அ", "ம்"), "test", 4), Random(3))
        val s = LetterPathState(p)
        val sol = p.solution
        s.touch(sol[0]); s.touch(sol[1]); s.touch(sol[2]); s.touch(sol[3])
        val far = (0 until p.cells).first { it !in s.path && !adjacent(4, it, s.path.last()) }
        assertEquals(Move.IGNORED, s.touch(far))                           // only one step at a time
        assertEquals(Move.REMOVED, s.touch(sol[2]))                        // back over previous square
        assertEquals(sol.take(3), s.path)
        assertEquals(Move.CUT, s.touch(sol[0]))                            // earlier square cuts the line
        assertEquals(listOf(sol[0]), s.path)
        assertTrue(s.undo())
        assertTrue(s.path.isEmpty())
    }

    @Test fun notSolvedUntilEverySquareIsFilled() {
        val p = LetterPathGenerator.build(LetterPathLevels.ALL[0], Random(9))
        val s = LetterPathState(p)
        p.solution.dropLast(1).forEach { s.touch(it) }
        assertFalse(s.solved)
        s.touch(p.solution.last())
        assertTrue(s.solved)
        assertEquals(Move.IGNORED, s.touch(p.solution.first()))            // board locked once solved
    }

    @Test fun starsFollowPar() {
        assertEquals(3, LetterPathState.stars(16, 32))
        assertEquals(2, LetterPathState.stars(16, 64))
        assertEquals(1, LetterPathState.stars(16, 65))
    }
}
