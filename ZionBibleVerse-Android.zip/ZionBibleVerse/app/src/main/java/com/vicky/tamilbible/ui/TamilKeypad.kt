package com.vicky.tamilbible.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.ui.theme.TamilFont

private val VOWELS = "அ ஆ இ ஈ உ ஊ எ ஏ ஐ ஒ ஓ ஔ ஃ".split(" ")
private val CONSONANTS = "க ங ச ஞ ட ண த ந ப ம ய ர ல வ ழ ள ற ன ஜ ஷ ஸ ஹ".split(" ")
private val SIGNS = "ா ி ீ ு ூ ெ ே ை ொ ோ ௌ ்".split(" ")
private const val PER_ROW = 9

/**
 * On-screen Tamil letter keypad for the search box, for phones without a Tamil keyboard.
 * Vowels (orange), consonants (grey) and vowel signs (shown on ◌) — e.g. க + ா = கா.
 */
@Composable
fun TamilKeypad(onKey: (String) -> Unit, onBackspace: () -> Unit) {
    val vowelBg = MaterialTheme.colorScheme.primaryContainer
    val vowelFg = Color(0xFFE8740C)
    val consBg = MaterialTheme.colorScheme.surfaceVariant
    val consFg = MaterialTheme.colorScheme.onSurface
    val signBg = MaterialTheme.colorScheme.secondaryContainer
    val signFg = MaterialTheme.colorScheme.onSecondaryContainer

    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        (VOWELS.map { Triple(it, it, 0) } + CONSONANTS.map { Triple(it, it, 1) } + SIGNS.map { Triple(it, "◌$it", 2) })
            .chunked(PER_ROW).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { (value, label, kind) ->
                        Key(
                            label,
                            bg = when (kind) { 0 -> vowelBg; 1 -> consBg; else -> signBg },
                            fg = when (kind) { 0 -> vowelFg; 1 -> consFg; else -> signFg },
                            modifier = Modifier.weight(1f),
                        ) { onKey(value) }
                    }
                    repeat(PER_ROW - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Key("Space", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer,
                Modifier.weight(3f), small = true) { onKey(" ") }
            Box(
                Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer).clickable(onClick = onBackspace),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "அழி", tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun Key(label: String, bg: Color, fg: Color, modifier: Modifier, small: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.height(42.dp).clip(RoundedCornerShape(8.dp)).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
            fontSize = if (small) 15.sp else 18.sp, maxLines = 1)
    }
}
