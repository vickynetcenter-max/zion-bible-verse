package com.vicky.tamilbible.data

import android.content.Context
import com.vicky.tamilbible.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Newer app version published on GitHub Releases. */
data class AppUpdateInfo(val versionCode: Int, val versionName: String, val notes: String, val apkUrl: String)

/**
 * Checks GitHub Releases for a newer build. Every release carries a small version.json
 * (written by the build workflow), so nothing has to be done by hand when publishing.
 */
object AppUpdate {
    private const val RELEASES = "https://github.com/vickynetcenter-max/zion-bible-verse/releases/latest/download/"
    private val apkName get() = if (BuildConfig.IS_ADMIN) "ZionAdmin.apk" else "ZionBibleVerse.apk"
    private fun prefs(c: Context) = c.getSharedPreferences("update", Context.MODE_PRIVATE)

    /** Returns the newer version, or null if this app is up to date / offline. Checks at most every 6 hours unless [force]. */
    suspend fun check(c: Context, force: Boolean = false): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val p = prefs(c)
        val now = System.currentTimeMillis()
        if (!force && now - p.getLong("checked", 0) < 6 * 60 * 60 * 1000) return@withContext cached(c)
        val info = runCatching {
            var conn = URL(RELEASES + "version.json").openConnection() as HttpURLConnection
            conn.connectTimeout = 15000; conn.readTimeout = 15000; conn.instanceFollowRedirects = true
            var hops = 0
            while (conn.responseCode in 300..399 && hops++ < 5) {
                val loc = conn.getHeaderField("Location"); conn.disconnect()
                conn = URL(loc).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 15000
            }
            val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            conn.disconnect()
            AppUpdateInfo(o.optInt("versionCode"), o.optString("versionName"), o.optString("notes"), RELEASES + apkName)
        }.getOrNull() ?: return@withContext cached(c)
        p.edit().putLong("checked", now).putInt("code", info.versionCode).putString("name", info.versionName)
            .putString("notes", info.notes).apply()
        info.takeIf { it.versionCode > BuildConfig.VERSION_CODE }
    }

    private fun cached(c: Context): AppUpdateInfo? {
        val p = prefs(c)
        val code = p.getInt("code", 0)
        if (code <= BuildConfig.VERSION_CODE) return null
        return AppUpdateInfo(code, p.getString("name", "") ?: "", p.getString("notes", "") ?: "", RELEASES + apkName)
    }

    /** True once per new version — used to send a single "update available" notification. */
    fun shouldNotify(c: Context, code: Int): Boolean {
        val p = prefs(c)
        if (p.getInt("notified", 0) >= code) return false
        p.edit().putInt("notified", code).apply()
        return true
    }
}
