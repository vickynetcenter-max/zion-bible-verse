package com.vicky.tamilbible

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.RefHit
import com.vicky.tamilbible.data.SearchHit
import com.vicky.tamilbible.data.ThemeMode
import com.vicky.tamilbible.data.Verse
import kotlinx.coroutines.launch

/** A request to move the reader to a chapter page, optionally highlighting one verse. */
data class Jump(val page: Int, val verse: Int?, val id: Long = System.nanoTime())

class BibleViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = BibleRepository(app)
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var books by mutableStateOf<List<Book>>(emptyList()); private set

    /** First global page index of each book; pages run through all 1,189 chapters. */
    private var bookStart = IntArray(0)
    var totalPages by mutableStateOf(0); private set

    var lang by mutableStateOf(enumOrDefault(prefs.getString("lang", null), Lang.TA)); private set
    var theme by mutableStateOf(enumOrDefault(prefs.getString("theme", null), ThemeMode.SYSTEM)); private set
    var fontSize by mutableFloatStateOf(prefs.getFloat("font", 19f)); private set

    val savedPage: Int get() = prefs.getInt("page", 0)

    var jump by mutableStateOf<Jump?>(null); private set

    private val chapterCache = object : LinkedHashMap<Int, List<Verse>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, List<Verse>>?) = size > 12
    }

    init {
        viewModelScope.launch {
            val list = repo.books()
            val starts = IntArray(list.size)
            var acc = 0
            list.forEachIndexed { i, b -> starts[i] = acc; acc += b.chapters }
            bookStart = starts
            books = list
            totalPages = acc
        }
    }

    // ---- page <-> reference -------------------------------------------------

    fun pageOf(bookOrd: Int, chapter: Int): Int = bookStart[bookOrd - 1] + chapter - 1

    fun refOf(page: Int): Pair<Book, Int> {
        var i = bookStart.size - 1
        while (i > 0 && bookStart[i] > page) i--
        return books[i] to (page - bookStart[i] + 1)
    }

    suspend fun versesFor(page: Int): List<Verse> {
        chapterCache[page]?.let { return it }
        val (book, ch) = refOf(page)
        return repo.chapter(book.ord, ch).also { chapterCache[page] = it }
    }

    // ---- navigation ---------------------------------------------------------

    fun goTo(bookOrd: Int, chapter: Int, verse: Int? = null) {
        jump = Jump(pageOf(bookOrd, chapter), verse)
    }

    fun consumeJump(j: Jump) {
        if (jump?.id == j.id) jump = null
    }

    fun savePage(page: Int) = prefs.edit().putInt("page", page).apply()

    // ---- settings -----------------------------------------------------------

    fun updateLang(value: Lang) {
        lang = value; prefs.edit().putString("lang", value.name).apply()
    }

    fun updateTheme(value: ThemeMode) {
        theme = value; prefs.edit().putString("theme", value.name).apply()
    }

    fun updateFontSize(value: Float) {
        fontSize = value; prefs.edit().putFloat("font", value).apply()
    }

    // ---- search -------------------------------------------------------------

    suspend fun search(query: String): List<SearchHit> = repo.search(query, lang)

    private val refPattern = Regex("""^\s*(.+?)\s*(\d+)(?:\s*[:.\s]\s*(\d+))?\s*$""")

    /** Understands "John 3:16", "jn 3", "யோவான் 3:16", "1 Samuel 17". */
    fun parseReference(query: String): RefHit? {
        val m = refPattern.find(query) ?: return null
        val name = m.groupValues[1].trim().lowercase()
        if (name.isEmpty()) return null
        val chapter = m.groupValues[2].toIntOrNull() ?: return null
        val verse = m.groupValues[3].toIntOrNull()
        val book = books.firstOrNull {
            it.en.lowercase() == name || it.ta == name || it.code.lowercase() == name
        } ?: books.firstOrNull {
            it.en.lowercase().startsWith(name) || it.ta.startsWith(name)
        } ?: return null
        if (chapter !in 1..book.chapters) return null
        return RefHit(book, chapter, verse)
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(v: String?, d: T): T =
        v?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: d
}
