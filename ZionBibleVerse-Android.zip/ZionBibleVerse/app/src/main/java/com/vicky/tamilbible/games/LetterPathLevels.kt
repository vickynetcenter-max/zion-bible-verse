package com.vicky.tamilbible.games

/**
 * எழுத்துப் பாதை levels. Each word is stored as its list of Tamil letters (as the player sees
 * them on the board). Add more words here; [n] is the board size (n × n) and must have room:
 * letters.size ≤ n * n.
 */
data class LetterPathLevel(val letters: List<String>, val meaning: String, val n: Int) {
    val word: String get() = letters.joinToString("")
}

object LetterPathLevels {
    val ALL: List<LetterPathLevel> = listOf(
        LetterPathLevel(listOf("இ", "யே", "சு"), "Jesus", 4),
        LetterPathLevel(listOf("அ", "ன்", "பு"), "Love", 4),
        LetterPathLevel(listOf("தே", "வ", "ன்"), "God", 4),
        LetterPathLevel(listOf("நா", "ச", "ரே", "த்"), "Nazareth", 5),
        LetterPathLevel(listOf("தா", "னி", "யே", "ல்"), "Daniel", 5),
        LetterPathLevel(listOf("ம", "த்", "தே", "யு"), "Matthew", 5),
        LetterPathLevel(listOf("யோ", "சே", "ப்", "பு"), "Joseph", 5),
        LetterPathLevel(listOf("எ", "ரு", "ச", "லே", "ம்"), "Jerusalem", 6),
        LetterPathLevel(listOf("இ", "ஸ்", "ர", "வே", "ல்"), "Israel", 6),
        LetterPathLevel(listOf("பெ", "த்", "லெ", "கே", "ம்"), "Bethlehem", 6),
        LetterPathLevel(listOf("ப", "ர", "லோ", "க", "ம்"), "Heaven", 6),
        LetterPathLevel(listOf("ப", "ரி", "சு", "த்", "த", "ர்"), "Holy One", 7),
        LetterPathLevel(listOf("ஆ", "சீ", "ர்", "வா", "த", "ம்"), "Blessing", 7),
        LetterPathLevel(listOf("இ", "ர", "ட்", "ச", "க", "ர்"), "Saviour", 7),
        LetterPathLevel(listOf("க", "ப்", "ப", "ர்", "ந", "கூ", "ம்"), "Capernaum", 7),
        LetterPathLevel(listOf("தீ", "ர்", "க்", "க", "த", "ரி", "சி"), "Prophet", 7),
        LetterPathLevel(listOf("நி", "த்", "தி", "ய", "ஜீ", "வ", "ன்"), "Eternal life", 7),
        LetterPathLevel(listOf("உ", "யி", "ர்", "த்", "தெ", "ழு", "த", "ல்"), "Resurrection", 8),
        LetterPathLevel(listOf("ம", "ன", "ந்", "தி", "ரு", "ம்", "பு", "த", "ல்"), "Repentance", 8),
        LetterPathLevel(listOf("உ", "யி", "ர்", "த்", "தெ", "ழு", "ந்", "த", "வ", "ர்"), "The Risen One", 8),
    )
}
