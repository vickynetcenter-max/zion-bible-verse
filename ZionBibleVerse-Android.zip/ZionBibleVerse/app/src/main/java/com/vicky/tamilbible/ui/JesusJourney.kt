package com.vicky.tamilbible.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

// Generated from a small scene description (see README): 15 cartoon scenes from the life of
// Jesus, one per quiz level, drawn in a 100×100 box at (ox, oy) scaled by s.

/** Caption shown under each scene. */
internal val JOURNEY_CAPTIONS = listOf("இயேசு பிறப்பு", "ஞானிகளின் காணிக்கை", "எகிப்துக்குப் பயணம்", "ஆலயத்தில் சிறுவன் இயேசு", "யோர்தானில் ஞானஸ்நானம்", "வனாந்தரத்தில் 40 நாள்", "சீஷர்களை அழைத்தல்", "கானா கல்யாணம்", "இரவில் நிக்கொதேமு", "மலைப் பிரசங்கம்", "5 அப்பம், 2 மீன்", "கடலின் மேல் நடந்தார்", "மறுரூபமானார்", "பிள்ளைகளை ஆசீர்வதித்தார்", "சகேயுவின் வீட்டில்", "லாசருவை எழுப்பினார்", "எருசலேம் பிரவேசம்", "கடைசி இராப்போஜனம்", "கல்வாரி சிலுவை", "உயிர்த்தெழுதல்")

/** Sky colours from the top of the map (night of the nativity) to the bottom (resurrection dawn). */
internal val JOURNEY_SKY = arrayOf(0.0f to Color(0xFF141B3D), 0.06f to Color(0xFF2B3A6B), 0.13f to Color(0xFFF6C99A), 0.2f to Color(0xFFBFE3F5), 0.8f to Color(0xFFBFE3F5), 0.88f to Color(0xFFF4A36B), 0.93f to Color(0xFF6B4E71), 0.98f to Color(0xFFFFE39A), 1.0f to Color(0xFFFFF3C4))

private fun k(rgb: Long, a: Float) = Color(0xFF000000 or rgb).copy(alpha = a)

private fun DrawScope.poly(p: FloatArray, c: Color, ox: Float, oy: Float, s: Float) {
    val path = Path()
    path.moveTo(ox + p[0] * s, oy + p[1] * s)
    var i = 2
    while (i < p.size) { path.lineTo(ox + p[i] * s, oy + p[i + 1] * s); i += 2 }
    path.close()
    drawPath(path, c)
}

private fun DrawScope.polyline(p: FloatArray, c: Color, w: Float, ox: Float, oy: Float, s: Float) {
    val path = Path()
    path.moveTo(ox + p[0] * s, oy + p[1] * s)
    var i = 2
    while (i < p.size) { path.lineTo(ox + p[i] * s, oy + p[i + 1] * s); i += 2 }
    drawPath(path, c, style = Stroke(width = w * s, cap = StrokeCap.Round))
}

internal fun DrawScope.jesusScene(n: Int, ox: Float, oy: Float, s: Float) {
    when (n) {
        1 -> {
            drawOval(k(0xC8B28A, 0.60f), Offset(ox + -2.00f * s, oy + 77.00f * s), Size(84.00f * s, 14.00f * s))
            poly(floatArrayOf(74.00f, 5.00f, 76.91f, 12.00f, 84.46f, 12.60f, 78.71f, 17.53f, 80.47f, 24.90f, 74.00f, 20.95f, 67.53f, 24.90f, 69.29f, 17.53f, 63.54f, 12.60f, 71.09f, 12.00f), k(0xFFE066, 1.00f), ox, oy, s)
            drawLine(k(0xFFE066, 0.50f), Offset(ox + 74.00f * s, oy + 16.00f * s), Offset(ox + 74.00f * s, oy + 40.00f * s), 1.50f * s, StrokeCap.Round)
            poly(floatArrayOf(14.00f, 50.00f, 56.00f, 50.00f, 35.00f, 28.00f), k(0x8D5A2B, 1.00f), ox, oy, s)
            drawRect(k(0xB98A56, 1.00f), Offset(ox + 19.00f * s, oy + 50.00f * s), Size(32.00f * s, 30.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 26.00f * s, oy + 57.00f * s), Size(18.00f * s, 23.00f * s))
            drawCircle(k(0xFFF59D, 0.55f), 8.00f * s, Offset(ox + 35.00f * s, oy + 70.00f * s))
            poly(floatArrayOf(27.00f, 73.00f, 43.00f, 73.00f, 40.00f, 80.00f, 30.00f, 80.00f), k(0xE8C15A, 1.00f), ox, oy, s)
            drawOval(k(0xFFF3E0, 1.00f), Offset(ox + 30.00f * s, oy + 68.00f * s), Size(10.00f * s, 6.00f * s))
            poly(floatArrayOf(56.35f, 84.50f, 71.65f, 84.50f, 68.25f, 65.80f, 59.75f, 65.80f), k(0x1E88E5, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.10f * s, Offset(ox + 64.00f * s, oy + 60.70f * s))
            poly(floatArrayOf(74.35f, 84.50f, 89.65f, 84.50f, 86.25f, 65.80f, 77.75f, 65.80f), k(0x8D6E63, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.10f * s, Offset(ox + 82.00f * s, oy + 60.70f * s))
        }
        2 -> {
            drawOval(k(0xE9C98B, 0.80f), Offset(ox + 6.00f * s, oy + 82.00f * s), Size(88.00f * s, 12.00f * s))
            poly(floatArrayOf(50.00f, 6.00f, 52.65f, 12.36f, 59.51f, 12.91f, 54.28f, 17.39f, 55.88f, 24.09f, 50.00f, 20.50f, 44.12f, 24.09f, 45.72f, 17.39f, 40.49f, 12.91f, 47.35f, 12.36f), k(0xFFE066, 1.00f), ox, oy, s)
            drawLine(k(0xFFE066, 0.40f), Offset(ox + 50.00f * s, oy + 26.00f * s), Offset(ox + 50.00f * s, oy + 48.00f * s), 1.50f * s, StrokeCap.Round)
            drawRect(k(0xE53935, 1.00f), Offset(ox + 16.00f * s, oy + 64.00f * s), Size(20.00f * s, 20.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 25.00f * s, oy + 64.00f * s), Size(3.00f * s, 20.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 16.00f * s, oy + 72.00f * s), Size(20.00f * s, 3.00f * s))
            drawRect(k(0x1E88E5, 1.00f), Offset(ox + 41.00f * s, oy + 58.00f * s), Size(20.00f * s, 26.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 50.00f * s, oy + 58.00f * s), Size(3.00f * s, 26.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 41.00f * s, oy + 69.00f * s), Size(20.00f * s, 3.00f * s))
            drawRect(k(0x43A047, 1.00f), Offset(ox + 66.00f * s, oy + 66.00f * s), Size(18.00f * s, 18.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 74.00f * s, oy + 66.00f * s), Size(3.00f * s, 18.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 66.00f * s, oy + 73.00f * s), Size(18.00f * s, 3.00f * s))
        }
        3 -> {
            drawCircle(k(0xFFB300, 1.00f), 9.00f * s, Offset(ox + 80.00f * s, oy + 20.00f * s))
            poly(floatArrayOf(46.00f, 86.00f, 72.00f, 42.00f, 98.00f, 86.00f), k(0xD9B26F, 1.00f), ox, oy, s)
            poly(floatArrayOf(72.00f, 42.00f, 98.00f, 86.00f, 80.00f, 86.00f), k(0xC99A4E, 1.00f), ox, oy, s)
            poly(floatArrayOf(28.00f, 86.00f, 44.00f, 60.00f, 60.00f, 86.00f), k(0xC99A4E, 1.00f), ox, oy, s)
            drawRect(k(0xE9C98B, 1.00f), Offset(ox + 0.00f * s, oy + 84.00f * s), Size(100.00f * s, 16.00f * s))
            poly(floatArrayOf(7.25f, 93.50f, 20.75f, 93.50f, 17.75f, 77.00f, 10.25f, 77.00f), k(0x1E88E5, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.50f * s, Offset(ox + 14.00f * s, oy + 72.50f * s))
            poly(floatArrayOf(25.25f, 93.50f, 38.75f, 93.50f, 35.75f, 77.00f, 28.25f, 77.00f), k(0x8D6E63, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.50f * s, Offset(ox + 32.00f * s, oy + 72.50f * s))
        }
        4 -> {
            poly(floatArrayOf(10.00f, 40.00f, 90.00f, 40.00f, 50.00f, 20.00f), k(0xB0BEC5, 1.00f), ox, oy, s)
            drawRect(k(0xECEFF1, 1.00f), Offset(ox + 17.00f * s, oy + 40.00f * s), Size(7.00f * s, 32.00f * s))
            drawRect(k(0xECEFF1, 1.00f), Offset(ox + 31.00f * s, oy + 40.00f * s), Size(7.00f * s, 32.00f * s))
            drawRect(k(0xECEFF1, 1.00f), Offset(ox + 46.00f * s, oy + 40.00f * s), Size(7.00f * s, 32.00f * s))
            drawRect(k(0xECEFF1, 1.00f), Offset(ox + 61.00f * s, oy + 40.00f * s), Size(7.00f * s, 32.00f * s))
            drawRect(k(0xECEFF1, 1.00f), Offset(ox + 76.00f * s, oy + 40.00f * s), Size(7.00f * s, 32.00f * s))
            drawRect(k(0xB0BEC5, 1.00f), Offset(ox + 12.00f * s, oy + 72.00f * s), Size(76.00f * s, 7.00f * s))
            poly(floatArrayOf(43.70f, 99.00f, 56.30f, 99.00f, 53.50f, 83.60f, 46.50f, 83.60f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.20f * s, Offset(ox + 50.00f * s, oy + 79.40f * s))
            poly(floatArrayOf(46.50f, 83.60f, 49.30f, 83.60f, 54.20f, 99.00f, 51.40f, 99.00f), k(0xC62828, 1.00f), ox, oy, s)
        }
        5 -> {
            poly(floatArrayOf(43.00f, 28.00f, 57.00f, 28.00f, 64.00f, 60.00f, 36.00f, 60.00f), k(0xFFF59D, 0.45f), ox, oy, s)
            drawRect(k(0x4FA3D1, 0.85f), Offset(ox + 0.00f * s, oy + 62.00f * s), Size(100.00f * s, 38.00f * s))
            polyline(floatArrayOf(0.00f, 70.00f, 5.00f, 72.33f, 10.00f, 71.69f, 15.00f, 68.89f, 20.00f, 67.51f, 25.00f, 69.30f, 30.00f, 71.98f, 35.00f, 72.14f, 40.00f, 69.56f, 45.00f, 67.55f, 50.00f, 68.66f, 55.00f, 71.48f, 60.00f, 72.41f, 65.00f, 70.27f, 70.00f, 67.78f, 75.00f, 68.12f, 80.00f, 70.86f, 85.00f, 72.50f, 90.00f, 70.95f, 95.00f, 68.19f, 100.00f, 67.74f), k(0x2F7FB0, 1.00f), 2.50f, ox, oy, s)
            polyline(floatArrayOf(0.00f, 84.00f, 5.00f, 86.33f, 10.00f, 85.69f, 15.00f, 82.89f, 20.00f, 81.51f, 25.00f, 83.30f, 30.00f, 85.98f, 35.00f, 86.14f, 40.00f, 83.56f, 45.00f, 81.55f, 50.00f, 82.66f, 55.00f, 85.48f, 60.00f, 86.41f, 65.00f, 84.27f, 70.00f, 81.78f, 75.00f, 82.12f, 80.00f, 84.86f, 85.00f, 86.50f, 90.00f, 84.95f, 95.00f, 82.19f, 100.00f, 81.74f), k(0x2F7FB0, 0.80f), 2.50f, ox, oy, s)
            poly(floatArrayOf(41.45f, 79.50f, 58.55f, 79.50f, 54.75f, 58.60f, 45.25f, 58.60f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.70f * s, Offset(ox + 50.00f * s, oy + 52.90f * s))
            poly(floatArrayOf(45.25f, 58.60f, 49.05f, 58.60f, 55.70f, 79.50f, 51.90f, 79.50f), k(0xC62828, 1.00f), ox, oy, s)
            poly(floatArrayOf(38.00f, 16.80f, 43.60f, 12.60f, 52.00f, 12.60f, 57.60f, 15.40f, 61.80f, 14.00f, 59.70f, 17.50f, 53.40f, 21.00f, 43.60f, 21.00f), k(0xFFFFFF, 1.00f), ox, oy, s)
            poly(floatArrayOf(46.40f, 15.40f, 50.60f, 5.60f, 53.40f, 15.40f), k(0xFFFFFF, 1.00f), ox, oy, s)
        }
        6 -> {
            drawCircle(k(0xFFB300, 1.00f), 10.00f * s, Offset(ox + 78.00f * s, oy + 22.00f * s))
            poly(floatArrayOf(0.00f, 82.00f, 30.00f, 58.00f, 62.00f, 82.00f), k(0xE9C98B, 1.00f), ox, oy, s)
            poly(floatArrayOf(34.00f, 86.00f, 70.00f, 60.00f, 100.00f, 86.00f), k(0xD9B26F, 1.00f), ox, oy, s)
            drawRect(k(0xE9C98B, 1.00f), Offset(ox + 0.00f * s, oy + 82.00f * s), Size(100.00f * s, 18.00f * s))
            drawOval(k(0xA1887F, 1.00f), Offset(ox + 10.00f * s, oy + 84.00f * s), Size(16.00f * s, 8.00f * s))
            drawOval(k(0xA1887F, 1.00f), Offset(ox + 78.00f * s, oy + 89.00f * s), Size(12.00f * s, 6.00f * s))
            poly(floatArrayOf(42.80f, 88.00f, 57.20f, 88.00f, 54.00f, 70.40f, 46.00f, 70.40f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.80f * s, Offset(ox + 50.00f * s, oy + 65.60f * s))
            poly(floatArrayOf(46.00f, 70.40f, 49.20f, 70.40f, 54.80f, 88.00f, 51.60f, 88.00f), k(0xC62828, 1.00f), ox, oy, s)
        }
        7 -> {
            drawRect(k(0x4FA3D1, 0.85f), Offset(ox + 0.00f * s, oy + 66.00f * s), Size(100.00f * s, 34.00f * s))
            polyline(floatArrayOf(0.00f, 74.00f, 5.00f, 76.33f, 10.00f, 75.69f, 15.00f, 72.89f, 20.00f, 71.51f, 25.00f, 73.30f, 30.00f, 75.98f, 35.00f, 76.14f, 40.00f, 73.56f, 45.00f, 71.55f, 50.00f, 72.66f, 55.00f, 75.48f, 60.00f, 76.41f, 65.00f, 74.27f, 70.00f, 71.78f, 75.00f, 72.12f, 80.00f, 74.86f, 85.00f, 76.50f, 90.00f, 74.95f, 95.00f, 72.19f, 100.00f, 71.74f), k(0x2F7FB0, 1.00f), 2.50f, ox, oy, s)
            poly(floatArrayOf(16.00f, 60.00f, 84.00f, 60.00f, 72.00f, 75.00f, 28.00f, 75.00f), k(0x8D5A2B, 1.00f), ox, oy, s)
            drawLine(k(0x5D4037, 1.00f), Offset(ox + 50.00f * s, oy + 60.00f * s), Offset(ox + 50.00f * s, oy + 20.00f * s), 2.50f * s, StrokeCap.Round)
            poly(floatArrayOf(53.00f, 22.00f, 53.00f, 56.00f, 78.00f, 56.00f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 22.00f * s, oy + 64.00f * s), Offset(ox + 10.00f * s, oy + 92.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 22.00f * s, oy + 64.00f * s), Offset(ox + 14.00f * s, oy + 92.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 22.00f * s, oy + 64.00f * s), Offset(ox + 18.00f * s, oy + 92.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 22.00f * s, oy + 64.00f * s), Offset(ox + 22.00f * s, oy + 92.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 22.00f * s, oy + 64.00f * s), Offset(ox + 26.00f * s, oy + 92.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 8.00f * s, oy + 78.00f * s), Offset(ox + 30.00f * s, oy + 78.00f * s), 1.00f * s, StrokeCap.Round)
            drawLine(k(0x5D4037, 0.70f), Offset(ox + 10.00f * s, oy + 86.00f * s), Offset(ox + 28.00f * s, oy + 86.00f * s), 1.00f * s, StrokeCap.Round)
            drawOval(k(0x90A4AE, 1.00f), Offset(ox + 12.00f * s, oy + 92.00f * s), Size(8.00f * s, 4.00f * s))
            drawOval(k(0x90A4AE, 1.00f), Offset(ox + 22.00f * s, oy + 88.00f * s), Size(8.00f * s, 4.00f * s))
        }
        8 -> {
            drawRect(k(0x795548, 1.00f), Offset(ox + 8.00f * s, oy + 84.00f * s), Size(84.00f * s, 5.00f * s))
            drawOval(k(0xB0876B, 1.00f), Offset(ox + 14.00f * s, oy + 52.00f * s), Size(22.00f * s, 32.00f * s))
            drawRect(k(0xB0876B, 1.00f), Offset(ox + 19.00f * s, oy + 48.00f * s), Size(12.00f * s, 6.00f * s))
            drawOval(k(0x7B1F3A, 1.00f), Offset(ox + 19.00f * s, oy + 48.00f * s), Size(12.00f * s, 4.00f * s))
            drawOval(k(0xB0876B, 1.00f), Offset(ox + 39.00f * s, oy + 52.00f * s), Size(22.00f * s, 32.00f * s))
            drawRect(k(0xB0876B, 1.00f), Offset(ox + 44.00f * s, oy + 48.00f * s), Size(12.00f * s, 6.00f * s))
            drawOval(k(0x7B1F3A, 1.00f), Offset(ox + 44.00f * s, oy + 48.00f * s), Size(12.00f * s, 4.00f * s))
            drawOval(k(0xB0876B, 1.00f), Offset(ox + 64.00f * s, oy + 52.00f * s), Size(22.00f * s, 32.00f * s))
            drawRect(k(0xB0876B, 1.00f), Offset(ox + 69.00f * s, oy + 48.00f * s), Size(12.00f * s, 6.00f * s))
            drawOval(k(0x7B1F3A, 1.00f), Offset(ox + 69.00f * s, oy + 48.00f * s), Size(12.00f * s, 4.00f * s))
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 85.00f * s, oy + 28.00f * s))
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 91.00f * s, oy + 28.00f * s))
            poly(floatArrayOf(81.00f, 29.00f, 95.00f, 29.00f, 88.00f, 37.00f), k(0xE57373, 1.00f), ox, oy, s)
        }
        9 -> {
            drawCircle(k(0xFFF9C4, 1.00f), 7.00f * s, Offset(ox + 82.00f * s, oy + 16.00f * s))
            drawCircle(k(0xFFF59D, 0.45f), 16.00f * s, Offset(ox + 50.00f * s, oy + 58.00f * s))
            poly(floatArrayOf(47.00f, 62.00f, 53.00f, 62.00f, 51.00f, 70.00f, 49.00f, 70.00f), k(0x795548, 1.00f), ox, oy, s)
            poly(floatArrayOf(50.00f, 52.00f, 53.00f, 58.00f, 47.00f, 58.00f), k(0xFFB300, 1.00f), ox, oy, s)
            drawOval(k(0xC8B28A, 0.60f), Offset(ox + 6.00f * s, oy + 88.00f * s), Size(88.00f * s, 8.00f * s))
            poly(floatArrayOf(19.90f, 93.00f, 36.10f, 93.00f, 32.50f, 73.20f, 23.50f, 73.20f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.40f * s, Offset(ox + 28.00f * s, oy + 67.80f * s))
            poly(floatArrayOf(23.50f, 73.20f, 27.10f, 73.20f, 33.40f, 93.00f, 29.80f, 93.00f), k(0xC62828, 1.00f), ox, oy, s)
            poly(floatArrayOf(63.90f, 93.00f, 80.10f, 93.00f, 76.50f, 73.20f, 67.50f, 73.20f), k(0x6A1B9A, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.40f * s, Offset(ox + 72.00f * s, oy + 67.80f * s))
        }
        10 -> {
            poly(floatArrayOf(0.00f, 92.00f, 28.00f, 52.00f, 55.00f, 38.00f, 82.00f, 54.00f, 100.00f, 92.00f), k(0x7CB342, 1.00f), ox, oy, s)
            poly(floatArrayOf(0.00f, 92.00f, 22.00f, 70.00f, 50.00f, 62.00f, 80.00f, 72.00f, 100.00f, 92.00f), k(0x558B2F, 1.00f), ox, oy, s)
            poly(floatArrayOf(48.70f, 47.00f, 61.30f, 47.00f, 58.50f, 31.60f, 51.50f, 31.60f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.20f * s, Offset(ox + 55.00f * s, oy + 27.40f * s))
            poly(floatArrayOf(51.50f, 31.60f, 54.30f, 31.60f, 59.20f, 47.00f, 56.40f, 47.00f), k(0xC62828, 1.00f), ox, oy, s)
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 16.00f * s, oy + 78.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 28.00f * s, oy + 72.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 38.00f * s, oy + 80.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 66.00f * s, oy + 74.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 76.00f * s, oy + 80.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 86.00f * s, oy + 84.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 3.00f * s, Offset(ox + 48.00f * s, oy + 86.00f * s))
        }
        11 -> {
            drawOval(k(0x90A4AE, 1.00f), Offset(ox + 22.00f * s, oy + 35.50f * s), Size(20.00f * s, 9.00f * s))
            poly(floatArrayOf(22.00f, 40.00f, 15.00f, 35.00f, 15.00f, 45.00f), k(0x90A4AE, 1.00f), ox, oy, s)
            drawOval(k(0x90A4AE, 1.00f), Offset(ox + 56.00f * s, oy + 29.50f * s), Size(20.00f * s, 9.00f * s))
            poly(floatArrayOf(76.00f, 34.00f, 83.00f, 29.00f, 83.00f, 39.00f), k(0x90A4AE, 1.00f), ox, oy, s)
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 25.00f * s, oy + 50.50f * s), Size(18.00f * s, 11.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 41.00f * s, oy + 46.50f * s), Size(18.00f * s, 11.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 57.00f * s, oy + 50.50f * s), Size(18.00f * s, 11.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 33.00f * s, oy + 56.50f * s), Size(18.00f * s, 11.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 49.00f * s, oy + 56.50f * s), Size(18.00f * s, 11.00f * s))
            poly(floatArrayOf(18.00f, 62.00f, 82.00f, 62.00f, 72.00f, 88.00f, 28.00f, 88.00f), k(0xA1887F, 1.00f), ox, oy, s)
            drawLine(k(0x8D6E63, 0.60f), Offset(ox + 22.00f * s, oy + 70.00f * s), Offset(ox + 78.00f * s, oy + 70.00f * s), 1.50f * s, StrokeCap.Round)
            drawLine(k(0x8D6E63, 0.60f), Offset(ox + 25.00f * s, oy + 78.00f * s), Offset(ox + 75.00f * s, oy + 78.00f * s), 1.50f * s, StrokeCap.Round)
        }
        12 -> {
            drawCircle(k(0xFFF9C4, 1.00f), 8.00f * s, Offset(ox + 80.00f * s, oy + 16.00f * s))
            drawCircle(k(0xFFFFFF, 0.22f), 20.00f * s, Offset(ox + 48.00f * s, oy + 52.00f * s))
            drawRect(k(0x2F6F9E, 0.90f), Offset(ox + 0.00f * s, oy + 66.00f * s), Size(100.00f * s, 34.00f * s))
            polyline(floatArrayOf(0.00f, 66.00f, 5.00f, 68.33f, 10.00f, 67.69f, 15.00f, 64.89f, 20.00f, 63.51f, 25.00f, 65.30f, 30.00f, 67.98f, 35.00f, 68.14f, 40.00f, 65.56f, 45.00f, 63.55f, 50.00f, 64.66f, 55.00f, 67.48f, 60.00f, 68.41f, 65.00f, 66.27f, 70.00f, 63.78f, 75.00f, 64.12f, 80.00f, 66.86f, 85.00f, 68.50f, 90.00f, 66.95f, 95.00f, 64.19f, 100.00f, 63.74f), k(0xFFFFFF, 0.60f), 2.50f, ox, oy, s)
            polyline(floatArrayOf(0.00f, 78.00f, 5.00f, 80.33f, 10.00f, 79.69f, 15.00f, 76.89f, 20.00f, 75.51f, 25.00f, 77.30f, 30.00f, 79.98f, 35.00f, 80.14f, 40.00f, 77.56f, 45.00f, 75.55f, 50.00f, 76.66f, 55.00f, 79.48f, 60.00f, 80.41f, 65.00f, 78.27f, 70.00f, 75.78f, 75.00f, 76.12f, 80.00f, 78.86f, 85.00f, 80.50f, 90.00f, 78.95f, 95.00f, 76.19f, 100.00f, 75.74f), k(0x2F7FB0, 1.00f), 2.50f, ox, oy, s)
            polyline(floatArrayOf(0.00f, 90.00f, 5.00f, 92.33f, 10.00f, 91.69f, 15.00f, 88.89f, 20.00f, 87.51f, 25.00f, 89.30f, 30.00f, 91.98f, 35.00f, 92.14f, 40.00f, 89.56f, 45.00f, 87.55f, 50.00f, 88.66f, 55.00f, 91.48f, 60.00f, 92.41f, 65.00f, 90.27f, 70.00f, 87.78f, 75.00f, 88.12f, 80.00f, 90.86f, 85.00f, 92.50f, 90.00f, 90.95f, 95.00f, 88.19f, 100.00f, 87.74f), k(0x2F7FB0, 1.00f), 2.50f, ox, oy, s)
            poly(floatArrayOf(39.00f, 76.00f, 57.00f, 76.00f, 53.00f, 54.00f, 43.00f, 54.00f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 6.00f * s, Offset(ox + 48.00f * s, oy + 48.00f * s))
            poly(floatArrayOf(43.00f, 54.00f, 47.00f, 54.00f, 54.00f, 76.00f, 50.00f, 76.00f), k(0xC62828, 1.00f), ox, oy, s)
        }
        13 -> {
            poly(floatArrayOf(0.00f, 96.00f, 50.00f, 46.00f, 100.00f, 96.00f), k(0x558B2F, 1.00f), ox, oy, s)
            drawCircle(k(0xFFFFFF, 0.35f), 26.00f * s, Offset(ox + 50.00f * s, oy + 34.00f * s))
            drawCircle(k(0xFFF59D, 0.60f), 16.00f * s, Offset(ox + 50.00f * s, oy + 34.00f * s))
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 80.00f * s, oy + 34.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 75.98f * s, oy + 49.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 65.00f * s, oy + 59.98f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 50.00f * s, oy + 64.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 35.00f * s, oy + 59.98f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 24.02f * s, oy + 49.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 20.00f * s, oy + 34.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 24.02f * s, oy + 19.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 35.00f * s, oy + 8.02f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 50.00f * s, oy + 4.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 65.00f * s, oy + 8.02f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFF59D, 0.80f), Offset(ox + 50.00f * s, oy + 34.00f * s), Offset(ox + 75.98f * s, oy + 19.00f * s), 2.00f * s, StrokeCap.Round)
            poly(floatArrayOf(41.90f, 59.00f, 58.10f, 59.00f, 54.50f, 39.20f, 45.50f, 39.20f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.40f * s, Offset(ox + 50.00f * s, oy + 33.80f * s))
        }
        14 -> {
            poly(floatArrayOf(29.00f, 92.00f, 47.00f, 92.00f, 43.00f, 70.00f, 33.00f, 70.00f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 6.00f * s, Offset(ox + 38.00f * s, oy + 64.00f * s))
            poly(floatArrayOf(33.00f, 70.00f, 37.00f, 70.00f, 44.00f, 92.00f, 40.00f, 92.00f), k(0xC62828, 1.00f), ox, oy, s)
            poly(floatArrayOf(56.60f, 94.00f, 67.40f, 94.00f, 65.00f, 80.80f, 59.00f, 80.80f), k(0xFFB74D, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 3.60f * s, Offset(ox + 62.00f * s, oy + 77.20f * s))
            poly(floatArrayOf(71.05f, 93.50f, 80.95f, 93.50f, 78.75f, 81.40f, 73.25f, 81.40f), k(0x81C784, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 3.30f * s, Offset(ox + 76.00f * s, oy + 78.10f * s))
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 53.00f * s, oy + 40.00f * s))
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 59.00f * s, oy + 40.00f * s))
            poly(floatArrayOf(49.00f, 41.00f, 63.00f, 41.00f, 56.00f, 49.00f), k(0xE57373, 1.00f), ox, oy, s)
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 69.00f * s, oy + 30.00f * s))
            drawCircle(k(0xE57373, 1.00f), 4.00f * s, Offset(ox + 75.00f * s, oy + 30.00f * s))
            poly(floatArrayOf(65.00f, 31.00f, 79.00f, 31.00f, 72.00f, 39.00f), k(0xE57373, 1.00f), ox, oy, s)
            drawOval(k(0xC8B28A, 0.60f), Offset(ox + 15.00f * s, oy + 93.00f * s), Size(80.00f * s, 6.00f * s))
        }
        15 -> {
            drawRect(k(0x8D6E63, 1.00f), Offset(ox + 46.00f * s, oy + 48.00f * s), Size(9.00f * s, 46.00f * s))
            drawCircle(k(0x43A047, 1.00f), 20.00f * s, Offset(ox + 50.00f * s, oy + 32.00f * s))
            drawCircle(k(0x43A047, 1.00f), 13.00f * s, Offset(ox + 32.00f * s, oy + 42.00f * s))
            drawCircle(k(0x43A047, 1.00f), 13.00f * s, Offset(ox + 68.00f * s, oy + 42.00f * s))
            poly(floatArrayOf(55.50f, 49.00f, 64.50f, 49.00f, 62.50f, 38.00f, 57.50f, 38.00f), k(0xFFB74D, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 3.00f * s, Offset(ox + 60.00f * s, oy + 35.00f * s))
            poly(floatArrayOf(10.80f, 96.00f, 25.20f, 96.00f, 22.00f, 78.40f, 14.00f, 78.40f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.80f * s, Offset(ox + 18.00f * s, oy + 73.60f * s))
            poly(floatArrayOf(14.00f, 78.40f, 17.20f, 78.40f, 22.80f, 96.00f, 19.60f, 96.00f), k(0xC62828, 1.00f), ox, oy, s)
            drawOval(k(0xC8B28A, 0.60f), Offset(ox + 2.00f * s, oy + 92.00f * s), Size(96.00f * s, 6.00f * s))
        }
        16 -> {
            poly(floatArrayOf(0.00f, 96.00f, 4.00f, 56.00f, 34.00f, 40.00f, 62.00f, 58.00f, 70.00f, 96.00f), k(0x8D8D8D, 1.00f), ox, oy, s)
            drawOval(k(0x2B2B2B, 1.00f), Offset(ox + 19.00f * s, oy + 59.00f * s), Size(26.00f * s, 34.00f * s))
            drawCircle(k(0xFFF59D, 0.35f), 16.00f * s, Offset(ox + 32.00f * s, oy + 72.00f * s))
            poly(floatArrayOf(24.80f, 94.00f, 39.20f, 94.00f, 36.00f, 76.40f, 28.00f, 76.40f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 4.80f * s, Offset(ox + 32.00f * s, oy + 71.60f * s))
            poly(floatArrayOf(74.35f, 96.50f, 89.65f, 96.50f, 86.25f, 77.80f, 77.75f, 77.80f), k(0xFFFFFF, 1.00f), ox, oy, s)
            drawCircle(k(0xE0B089, 1.00f), 5.10f * s, Offset(ox + 82.00f * s, oy + 72.70f * s))
            poly(floatArrayOf(77.75f, 77.80f, 81.15f, 77.80f, 87.10f, 96.50f, 83.70f, 96.50f), k(0xC62828, 1.00f), ox, oy, s)
            drawCircle(k(0x9E9E9E, 1.00f), 11.00f * s, Offset(ox + 62.00f * s, oy + 90.00f * s))
        }
        17 -> {
            drawRect(k(0xBCAAA4, 1.00f), Offset(ox + 56.00f * s, oy + 38.00f * s), Size(40.00f * s, 50.00f * s))
            drawRect(k(0xBCAAA4, 1.00f), Offset(ox + 56.00f * s, oy + 32.00f * s), Size(7.00f * s, 7.00f * s))
            drawRect(k(0xBCAAA4, 1.00f), Offset(ox + 72.00f * s, oy + 32.00f * s), Size(7.00f * s, 7.00f * s))
            drawRect(k(0xBCAAA4, 1.00f), Offset(ox + 88.00f * s, oy + 32.00f * s), Size(8.00f * s, 7.00f * s))
            drawRect(k(0x6D4C41, 1.00f), Offset(ox + 66.00f * s, oy + 62.00f * s), Size(20.00f * s, 26.00f * s))
            drawCircle(k(0x6D4C41, 1.00f), 10.00f * s, Offset(ox + 76.00f * s, oy + 62.00f * s))
            drawOval(k(0xE9C98B, 0.80f), Offset(ox + -3.00f * s, oy + 87.00f * s), Size(96.00f * s, 10.00f * s))
            drawLine(k(0x8D6E63, 1.00f), Offset(ox + 20.00f * s, oy + 92.00f * s), Offset(ox + 26.00f * s, oy + 42.00f * s), 3.00f * s, StrokeCap.Round)
            poly(floatArrayOf(26.00f, 42.00f, 10.00f, 48.00f, 18.00f, 48.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(26.00f, 42.00f, 42.00f, 48.00f, 34.00f, 48.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(26.00f, 42.00f, 14.00f, 34.00f, 20.00f, 41.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(26.00f, 42.00f, 38.00f, 34.00f, 32.00f, 41.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(26.00f, 42.00f, 26.00f, 28.00f, 26.00f, 38.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            drawLine(k(0x8D6E63, 1.00f), Offset(ox + 40.00f * s, oy + 92.00f * s), Offset(ox + 36.00f * s, oy + 54.00f * s), 3.00f * s, StrokeCap.Round)
            poly(floatArrayOf(36.00f, 54.00f, 20.00f, 60.00f, 28.00f, 60.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(36.00f, 54.00f, 52.00f, 60.00f, 44.00f, 60.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(36.00f, 54.00f, 24.00f, 46.00f, 30.00f, 53.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(36.00f, 54.00f, 48.00f, 46.00f, 42.00f, 53.00f), k(0x2E7D32, 1.00f), ox, oy, s)
            poly(floatArrayOf(36.00f, 54.00f, 36.00f, 40.00f, 36.00f, 50.00f), k(0x2E7D32, 1.00f), ox, oy, s)
        }
        18 -> {
            drawCircle(k(0xFFF59D, 0.35f), 18.00f * s, Offset(ox + 50.00f * s, oy + 36.00f * s))
            drawRect(k(0x795548, 1.00f), Offset(ox + 8.00f * s, oy + 62.00f * s), Size(84.00f * s, 7.00f * s))
            drawRect(k(0x795548, 1.00f), Offset(ox + 15.00f * s, oy + 69.00f * s), Size(4.00f * s, 20.00f * s))
            drawRect(k(0x795548, 1.00f), Offset(ox + 81.00f * s, oy + 69.00f * s), Size(4.00f * s, 20.00f * s))
            poly(floatArrayOf(43.00f, 42.00f, 57.00f, 42.00f, 54.00f, 55.00f, 46.00f, 55.00f), k(0xFFD54F, 1.00f), ox, oy, s)
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 49.00f * s, oy + 55.00f * s), Size(2.00f * s, 5.00f * s))
            drawRect(k(0xFFD54F, 1.00f), Offset(ox + 44.00f * s, oy + 59.00f * s), Size(12.00f * s, 3.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 16.00f * s, oy + 53.50f * s), Size(20.00f * s, 9.00f * s))
            drawOval(k(0xD7A15B, 1.00f), Offset(ox + 64.00f * s, oy + 53.50f * s), Size(20.00f * s, 9.00f * s))
        }
        19 -> {
            poly(floatArrayOf(0.00f, 96.00f, 50.00f, 56.00f, 100.00f, 96.00f), k(0x6D4C41, 0.95f), ox, oy, s)
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 47.00f * s, oy + 14.00f * s), Size(6.00f * s, 46.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 35.00f * s, oy + 24.00f * s), Size(30.00f * s, 5.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 19.00f * s, oy + 46.00f * s), Size(4.00f * s, 28.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 12.00f * s, oy + 53.00f * s), Size(18.00f * s, 4.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 77.00f * s, oy + 46.00f * s), Size(4.00f * s, 28.00f * s))
            drawRect(k(0x5D4037, 1.00f), Offset(ox + 70.00f * s, oy + 53.00f * s), Size(18.00f * s, 4.00f * s))
        }
        20 -> {
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 104.00f * s, oy + 30.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 99.44f * s, oy + 47.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 87.00f * s, oy + 59.44f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 70.00f * s, oy + 64.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 53.00f * s, oy + 59.44f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 40.56f * s, oy + 47.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 36.00f * s, oy + 30.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 40.56f * s, oy + 13.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 53.00f * s, oy + 0.56f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 70.00f * s, oy + -4.00f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 87.00f * s, oy + 0.56f * s), 2.00f * s, StrokeCap.Round)
            drawLine(k(0xFFB300, 0.60f), Offset(ox + 70.00f * s, oy + 30.00f * s), Offset(ox + 99.44f * s, oy + 13.00f * s), 2.00f * s, StrokeCap.Round)
            drawCircle(k(0xFFB300, 1.00f), 11.00f * s, Offset(ox + 70.00f * s, oy + 30.00f * s))
            poly(floatArrayOf(4.00f, 96.00f, 10.00f, 56.00f, 42.00f, 40.00f, 68.00f, 60.00f, 80.00f, 96.00f), k(0x8D8D8D, 1.00f), ox, oy, s)
            drawOval(k(0x2B2B2B, 1.00f), Offset(ox + 25.00f * s, oy + 59.00f * s), Size(26.00f * s, 34.00f * s))
            drawCircle(k(0x9E9E9E, 1.00f), 13.00f * s, Offset(ox + 68.00f * s, oy + 84.00f * s))
            drawCircle(k(0x8D8D8D, 0.50f), 9.00f * s, Offset(ox + 68.00f * s, oy + 84.00f * s))
            drawCircle(k(0xFFFFFF, 1.00f), 3.00f * s, Offset(ox + 88.00f * s, oy + 92.00f * s))
            drawCircle(k(0xFFFFFF, 1.00f), 3.00f * s, Offset(ox + 94.00f * s, oy + 86.00f * s))
            drawCircle(k(0xFFFFFF, 1.00f), 2.50f * s, Offset(ox + 84.00f * s, oy + 86.00f * s))
        }
    }
}
