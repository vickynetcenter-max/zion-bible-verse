package com.vicky.tamilbible.data

data class Book(
    val ord: Int,
    val code: String,
    val ta: String,
    val en: String,
    val testament: String,
    val chapters: Int,
)

data class Verse(val num: Int, val ta: String, val en: String)

data class SearchHit(val book: Int, val chapter: Int, val verse: Int, val ta: String, val en: String)

/** A reference typed into search, e.g. "John 3:16" or "யோவான் 3 16". */
data class RefHit(val book: Book, val chapter: Int, val verse: Int?)

enum class Lang { TA, EN, BOTH }

enum class ThemeMode { SYSTEM, LIGHT, DARK }
