package com.vicky.tamilbible.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay

/** Colours of each game (card gradient + accent). */
data class GameTheme(val start: Color, val end: Color) {
    val accent: Color get() = start
}

object GameThemes {
    val QUIZ = GameTheme(Color(0xFF1C2951), Color(0xFF8C1C2B))
    val LETTER_PATH = GameTheme(Color(0xFF1F6E4A), Color(0xFF0E4D64))
    val SCRAMBLE = GameTheme(Color(0xFF8C1C2B), Color(0xFFD9822B))
    val MEMORY = GameTheme(Color(0xFF3949AB), Color(0xFF00897B))
    val WHO = GameTheme(Color(0xFF5B2C83), Color(0xFFC2185B))
    val TIMELINE = GameTheme(Color(0xFF6D4C41), Color(0xFFB8860B))
}

val GAME_RED = Color(0xFFE24B4A)
val GAME_GREEN = Color(0xFF3B6D11)
val GAME_GOLD = Color(0xFFE0A11B)

/** Full-screen game page with a gradient header. */
@Composable
fun GameScaffold(
    title: String,
    theme: GameTheme,
    onBack: () -> Unit,
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(
            Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(theme.start, theme.end)))
                .statusBarsPadding().padding(start = 4.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "பின்செல்", tint = Color.White) }
                Text(title, color = Color.White, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
        }
        Column(
            Modifier.fillMaxWidth().weight(1f).then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

/** "நிலை N / 20" with something on the right (e.g. Reset). */
@Composable
fun LevelRow(level: Int, total: Int, right: @Composable () -> Unit = {}) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("நிலை $level / $total", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        right()
    }
}

/** Small rounded English action button (Reset / Undo …). */
@Composable
fun SmallAction(label: String, color: Color = MaterialTheme.colorScheme.surfaceVariant, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = color, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)) {
        Text(label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
    }
}

/** Full-width action button. */
@Composable
fun WideAction(label: String, color: Color, textColor: Color = Color.White, enabled: Boolean = true, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (enabled) color else color.copy(alpha = 0.4f),
        contentColor = textColor,
        modifier = Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(16.dp)).clickable(enabled = enabled, onClick = onClick),
    ) {
        Box(contentAlignment = Alignment.Center) { Text(label, fontWeight = FontWeight.Bold, fontSize = 17.sp, fontFamily = TamilFont) }
    }
}

@Composable
fun StarsRow(stars: Int, size: Dp = 30.dp) {
    Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
        repeat(3) { i ->
            // Each earned star pops in one after another.
            val scale = remember { Animatable(0f) }
            LaunchedEffect(stars) {
                scale.snapTo(0f); delay(150L * i)
                scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
            }
            Text(
                if (i < stars) "★" else "☆", color = GAME_GOLD, fontSize = (size.value).sp,
                modifier = Modifier.padding(horizontal = 4.dp).graphicsLayer { scaleX = scale.value; scaleY = scale.value },
            )
        }
    }
}

/** Seconds since [running] became true (stops counting when it becomes false). */
@Composable
fun rememberGameSeconds(running: Boolean, key: Any?): Int {
    var seconds by remember(key) { mutableIntStateOf(0) }
    LaunchedEffect(running, key) {
        while (running) { delay(1000); seconds++ }
    }
    return seconds
}

fun formatSeconds(s: Int) = "${s / 60}:${(s % 60).toString().padStart(2, '0')}"

/** Result panel shown when a level ends. */
@Composable
fun LevelResult(
    passed: Boolean, stars: Int, headline: String, detail: String, theme: GameTheme,
    onNext: (() -> Unit)?, onRetry: () -> Unit,
) {
    Surface(shape = RoundedCornerShape(20.dp), color = (if (passed) GAME_GREEN else GAME_RED).copy(alpha = 0.08f)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(headline, fontFamily = TamilFont, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp,
                color = if (passed) GAME_GREEN else GAME_RED, textAlign = TextAlign.Center)
            if (passed) StarsRow(stars, 34.dp)
            Text(detail, fontFamily = TamilFont, fontSize = 14.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (passed && onNext != null) WideAction("Next", GAME_GREEN, onClick = onNext)
    WideAction("Retry", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurface, onClick = onRetry)
}

/** Shakes when [trigger] changes (wrong answer). */
@Composable
fun Modifier.shake(trigger: Int): Modifier {
    val x = remember { Animatable(0f) }
    LaunchedEffect(trigger) {
        if (trigger == 0) return@LaunchedEffect
        for (v in listOf(14f, -12f, 9f, -6f, 3f, 0f)) x.animateTo(v, spring(stiffness = Spring.StiffnessHigh))
    }
    return this.graphicsLayer { translationX = x.value }
}

/** Little round badge used for numbers. */
@Composable
fun NumberBadge(n: Int, color: Color) {
    Box(Modifier.size(26.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
        Text("$n", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun Gap(h: Dp) = Spacer(Modifier.height(h))
