package com.vicky.tamilbible.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.MainActivity
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.Booking
import com.vicky.tamilbible.data.BookingsStore
import com.vicky.tamilbible.data.ChurchEvent
import com.vicky.tamilbible.data.ChurchEvents
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * நினைவூட்டல்: reminders for church programmes (from assets/church_events.txt).
 * Each event can be switched off; one shared "how long before" setting. Uses the same
 * receiver as the daily verse (action [ACTION_EVENT]), which also re-arms after reboot.
 */
object EventReminders {
    const val ACTION_EVENT = "com.vicky.zionbibleverse.CHURCH_EVENT"
    private const val CHANNEL_ID = "church_events"
    private const val NOTIFICATION_ID = 7101
    private const val EXTRA_EVENT = "event_id"
    private const val EXTRA_AT = "event_at"
    val LEAD_OPTIONS = listOf(0, 15, 30, 60)

    private fun prefs(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun isOn(c: Context, e: ChurchEvent) = e.id !in prefs(c).getStringSet("event_off", emptySet())!!
    fun setOn(c: Context, e: ChurchEvent, on: Boolean) {
        val off = prefs(c).getStringSet("event_off", emptySet())!!.toMutableSet()
        if (on) off.remove(e.id) else off.add(e.id)
        prefs(c).edit().putStringSet("event_off", off).apply()
        schedule(c)
    }
    fun leadMinutes(c: Context) = prefs(c).getInt("event_lead", 30)
    fun setLeadMinutes(c: Context, m: Int) { prefs(c).edit().putInt("event_lead", m).apply(); schedule(c) }

    private const val EXTRA_BOOKING = "booking_id"
    private const val EXTRA_DAY_BEFORE = "day_before"

    private fun intent(c: Context, e: ChurchEvent? = null, at: LocalDateTime? = null,
                       booking: Booking? = null, dayBefore: Boolean = false): PendingIntent {
        val i = Intent(c, DailyVerseReceiver::class.java).setAction(ACTION_EVENT)
        if (e != null && at != null) i.putExtra(EXTRA_EVENT, e.id).putExtra(EXTRA_AT, at.toString())
        if (booking != null) i.putExtra(EXTRA_BOOKING, booking.id).putExtra(EXTRA_DAY_BEFORE, dayBefore)
        return PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Arms the single next reminder across all enabled events. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(intent(c))
        val lead = leadMinutes(c).toLong()
        val now = LocalDateTime.now()
        var best: Pair<ChurchEvent, LocalDateTime>? = null
        for (e in ChurchEvents.load(c).filter { isOn(c, it) }) {
            for (d in 0..7) {
                val date = LocalDate.now().plusDays(d.toLong())
                if (date.dayOfWeek !in e.days) continue
                val start = LocalDateTime.of(date, e.time)
                if (start.minusMinutes(lead).isAfter(now)) {
                    if (best == null || start.isBefore(best.second)) best = e to start
                    break
                }
            }
        }
        // Personal bookings: remind at 8 PM the day before, and on the day
        // (at the booking time minus the lead, or 7 AM when no time was given).
        var bookingNext: Triple<Booking, LocalDateTime, Boolean>? = null
        for (b in BookingsStore(c).all().filter { it.remind }) {
            val dayBefore = LocalDateTime.of(b.date.minusDays(1), LocalTime.of(20, 0))
            val onDay = b.time?.let { LocalDateTime.of(b.date, it).minusMinutes(lead) } ?: LocalDateTime.of(b.date, LocalTime.of(7, 0))
            for ((t, before) in listOf(dayBefore to true, onDay to false)) {
                if (t.isAfter(now) && (bookingNext == null || t.isBefore(bookingNext.second))) bookingNext = Triple(b, t, before)
            }
        }
        val eventAt = best?.second?.minusMinutes(lead)
        val pi: PendingIntent
        val whenAt: LocalDateTime
        if (bookingNext != null && (eventAt == null || bookingNext.second.isBefore(eventAt))) {
            pi = intent(c, booking = bookingNext.first, dayBefore = bookingNext.third); whenAt = bookingNext.second
        } else {
            val (e, start) = best ?: return
            pi = intent(c, e, start); whenAt = start.minusMinutes(lead)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi)
    }

    private fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "நினைவூட்டல்", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Church programme reminders"
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                )
                enableVibration(true)
            }
        )
    }

    fun show(c: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (intent.hasExtra(EXTRA_BOOKING)) { showBooking(c, intent); return }
        val id = intent.getStringExtra(EXTRA_EVENT) ?: return
        val e = ChurchEvents.load(c).firstOrNull { it.id == id } ?: return
        if (!isOn(c, e)) return
        val start = runCatching { LocalDateTime.parse(intent.getStringExtra(EXTRA_AT)) }.getOrNull() ?: return
        val time = start.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        val lead = leadMinutes(c)
        val text = if (lead == 0) "இப்போது தொடங்குகிறது · $time" else "$lead நிமிடத்தில் தொடங்கும் · $time"

        createChannel(c)
        val open = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(e.title)
            .setContentText(text)
            .setSubText("சீயோன் பேராலயம்")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(c).notify(NOTIFICATION_ID, n)
    }

    private fun showBooking(c: Context, intent: Intent) {
        val b = BookingsStore(c).all().firstOrNull { it.id == intent.getLongExtra(EXTRA_BOOKING, -1) } ?: return
        if (!b.remind) return
        val before = intent.getBooleanExtra(EXTRA_DAY_BEFORE, false)
        val time = b.time?.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        val text = (if (before) "நாளை" else "இன்று") + (time?.let { " · $it" } ?: "") +
            (b.note.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "")
        createChannel(c)
        val open = PendingIntent.getActivity(
            c, 3, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(b.title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(c).notify((NOTIFICATION_ID + 1 + (b.id % 1000)).toInt(), n)
    }
}
