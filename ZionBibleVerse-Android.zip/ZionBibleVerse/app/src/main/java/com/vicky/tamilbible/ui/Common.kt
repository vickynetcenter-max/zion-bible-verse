package com.vicky.tamilbible.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Lang

/** UI copy follows the reading language; "Both" keeps Tamil as the primary UI language. */
fun Lang.ui(tamil: String, english: String): String = if (this == Lang.EN) english else tamil

fun Book.displayName(lang: Lang): String = if (lang == Lang.EN) en else ta

fun Book.secondaryName(lang: Lang): String? = when (lang) {
    Lang.TA -> en
    Lang.EN -> ta
    Lang.BOTH -> en
}

/** Bold-highlights every case-insensitive occurrence of [term] inside [text]. */
fun highlight(text: String, term: String, color: Color): AnnotatedString = buildAnnotatedString {
    val t = term.trim()
    if (t.isEmpty()) { append(text); return@buildAnnotatedString }
    val lower = text.lowercase()
    val needle = t.lowercase()
    var start = 0
    while (true) {
        val i = lower.indexOf(needle, start)
        if (i < 0) { append(text.substring(start)); break }
        append(text.substring(start, i))
        withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) {
            append(text.substring(i, i + t.length))
        }
        start = i + t.length
    }
}

/** Compresses [1,2,3,5,7,8] into "1-3, 5, 7-8" for verse references. */
fun verseRange(nums: List<Int>): String {
    if (nums.isEmpty()) return ""
    val sorted = nums.sorted()
    val parts = mutableListOf<String>()
    var a = sorted[0]; var b = a
    for (n in sorted.drop(1)) {
        if (n == b + 1) b = n else { parts += if (a == b) "$a" else "$a-$b"; a = n; b = n }
    }
    parts += if (a == b) "$a" else "$a-$b"
    return parts.joinToString(", ")
}
