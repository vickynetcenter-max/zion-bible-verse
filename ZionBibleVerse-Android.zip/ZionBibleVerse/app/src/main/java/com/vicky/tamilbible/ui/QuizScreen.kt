package com.vicky.tamilbible.ui
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.DailyVerse
import com.vicky.tamilbible.data.Question
import com.vicky.tamilbible.data.QuizEngine
import com.vicky.tamilbible.data.QuizProgress
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlin.random.Random

private val GREEN = Color(0xFF2E7D32)
private val GOLD = Color(0xFFE0A11B)

/** Badge (prize) earned for completing each level. */
private val BADGES = listOf(
    "தொடக்க வாசகர்", "வசனத் தேடுபவர்", "யாத்ரீகர்", "புத்தக அறிஞர்", "சீஷன்",
    "விசுவாசி", "மீனவன்", "ஜெப வீரன்", "இரவுத் தேடுபவர்", "சத்திய வழி நடப்பவர்",
    "வேத மாணவன்", "விசுவாச நடையாளர்", "ஒளியின் பிள்ளை", "ஞானத் தேடுபவர்", "வேத ஆசிரியர்",
    "சுவிசேஷகர்", "தீர்க்கதரிசன வாசகர்", "வேத வல்லுநர்", "சத்தியக் காவலர்", "வேத வீரன்",
)
private val BADGE_ICONS = listOf("🌱", "🔎", "🐪", "📚", "👣", "🛡️", "🎣", "🙏", "🌙", "🕯️",
    "🎓", "🌊", "✨", "💡", "📖", "📣", "🔥", "⭐", "🏰", "👑")

private sealed interface QState {
    data object Map : QState
    data class Loading(val level: Int) : QState
    data class Play(val level: Int, val questions: List<Question>) : QState
    data class Result(val level: Int, val correct: Int, val score: Int, val newBest: Boolean, val unlockedNew: Boolean) : QState
    data class Prize(val level: Int) : QState
}

/**
 * வேத வினாடி வினா: 15 levels, random questions every time, timer and score,
 * stars per level, celebration on a new high score, and a prize to open for each level passed.
 */
@Composable
fun QuizScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val progress = remember { QuizProgress(context) }
    val engine = remember(vm.books) { vm.quizEngine(progress.seen()) }
    var state by remember { mutableStateOf<QState>(QState.Map) }
    var tick by remember { mutableIntStateOf(0) }   // forces the map to re-read progress

    BackHandler(enabled = state !is QState.Map) { state = QState.Map; tick++ }

    when (val s = state) {
        QState.Map -> LevelMap(progress, tick, onBack,
            onPlay = { state = QState.Loading(it) },
            onReset = { progress.reset(); tick++ })
        is QState.Loading -> {
            LaunchedEffect(s.level) {
                val qs = engine.build(s.level)
                progress.saveSeen(engine.seen)   // remember what was asked, so it won't repeat
                state = QState.Play(s.level, qs)
            }
            Box(Modifier.fillMaxSize().pageBackground(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }
        is QState.Play -> PlayLevel(s.level, s.questions,
            onQuit = { state = QState.Map; tick++ },
            onFinish = { correct, score ->
                val rec = progress.record(s.level, score, correct)
                state = QState.Result(s.level, correct, score, rec.first, rec.second)
            })
        is QState.Result -> ResultView(s, progress,
            onPrize = { state = QState.Prize(s.level) },
            onRetry = { state = QState.Loading(s.level) },
            onNext = { state = QState.Loading(s.level + 1) },
            onMap = { state = QState.Map; tick++ })
        is QState.Prize -> PrizeView(s.level,
            onDone = { progress.openPrize(s.level); state = QState.Map; tick++ })
    }
}

// ---------------------------------------------------------------- level map

@Composable
private fun LevelMap(progress: QuizProgress, tick: Int, onBack: () -> Unit, onPlay: (Int) -> Unit, onReset: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    val unlocked = remember(tick) { progress.unlocked() }
    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "பின்செல்") }
            Text("வேத வினாடி வினா", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { confirmReset = true }) { Icon(Icons.Filled.Refresh, "மதிப்பெண்களை reset செய்") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        // Totals
        Surface(color = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("மொத்த மதிப்பெண்", fontFamily = TamilFont, fontSize = 12.sp)
                    Text("${remember(tick) { progress.total() }}", fontWeight = FontWeight.Bold, fontSize = 26.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("⭐ ${remember(tick) { progress.totalStars() }} / ${QuizEngine.LEVELS * 3}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("நிலை $unlocked / ${QuizEngine.LEVELS}", fontFamily = TamilFont, fontSize = 12.sp)
                }
            }
        }
        JourneyMap(progress, tick, unlocked, onPlay)
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("எல்லா மதிப்பெண்களையும் அழிக்கவா?", fontFamily = TamilFont) },
            text = { Text("நிலைகள் மீண்டும் 1-லிருந்து தொடங்கும்.", fontFamily = TamilFont) },
            confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text("அழி", fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("வேண்டாம்", fontFamily = TamilFont) } },
        )
    }
}

// ---------------------------------------------------------------- playing

@Composable
private fun PlayLevel(level: Int, questions: List<Question>, onQuit: () -> Unit, onFinish: (Int, Int) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    var timedOut by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    val total = QuizEngine.seconds(level)
    var left by remember { mutableFloatStateOf(total.toFloat()) }
    val q = questions[index]
    val answered = chosen != null || timedOut

    LaunchedEffect(index) {
        left = total.toFloat()
        while (left > 0f && chosen == null) { delay(100); left -= 0.1f }
        if (chosen == null) timedOut = true
    }

    fun next() {
        if (index + 1 >= questions.size) onFinish(correct, score)
        else { index++; chosen = null; timedOut = false }
    }

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onQuit) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "நிலைகள்") }
            Text("நிலை $level", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("  ·  ${index + 1}/${questions.size}", fontSize = 15.sp, modifier = Modifier.weight(1f))
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.padding(end = 10.dp)) {
                Text("🏆 $score", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        LinearProgressIndicator(
            progress = { (left / total).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = if (left < 6) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(q.text, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 27.sp)
            q.verse?.let {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Text(it, fontFamily = TamilFont, fontSize = 16.sp, lineHeight = 26.sp, modifier = Modifier.padding(14.dp))
                }
            }
            q.options.forEachIndexed { i, opt ->
                val isRight = i == q.answer
                val bg = when {
                    !answered -> MaterialTheme.colorScheme.surface
                    isRight -> GREEN
                    i == chosen -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.surface
                }
                val fg = if (answered && (isRight || i == chosen)) Color.White else MaterialTheme.colorScheme.onSurface
                Surface(
                    shape = RoundedCornerShape(14.dp), color = bg, contentColor = fg,
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = !answered) {
                            chosen = i
                            if (isRight) { correct++; score += 10 + (left / 2).toInt() }
                        },
                ) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${"அஆஇஈ"[i]}", fontWeight = FontWeight.Bold, fontFamily = TamilFont, modifier = Modifier.padding(end = 12.dp))
                        Text(opt, fontFamily = TamilFont, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        if (answered && isRight) Text("✓", fontWeight = FontWeight.Bold)
                        if (answered && i == chosen && !isRight) Text("✗", fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (answered) {
                Text(
                    when { timedOut && chosen == null -> "⏰ நேரம் முடிந்தது"; chosen == q.answer -> "🎉 சரியான பதில்!"; else -> "தவறு — சரியான பதில் பச்சையில்" },
                    fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
                    color = if (chosen == q.answer) GREEN else MaterialTheme.colorScheme.error,
                )
                q.ref?.let { Text("📖 $it", fontFamily = TamilFont, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Button(onClick = ::next, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text(if (index + 1 >= questions.size) "முடிவைப் பார்" else "அடுத்த கேள்வி", fontFamily = TamilFont, fontSize = 16.sp)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- result

@Composable
private fun ResultView(r: QState.Result, progress: QuizProgress, onPrize: () -> Unit, onRetry: () -> Unit, onNext: () -> Unit, onMap: () -> Unit) {
    val stars = QuizEngine.stars(r.correct)
    val passed = r.correct >= QuizEngine.PASS
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }

    Box(Modifier.fillMaxSize().pageBackground()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Text(if (passed) "நிலை ${r.level} முடிந்தது!" else "மீண்டும் முயற்சி செய்யுங்கள்",
                fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 24.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.scale(pop.value), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..3).forEach { Text(if (it <= stars) "★" else "☆", fontSize = 52.sp, color = GOLD) }
            }
            Spacer(Modifier.height(12.dp))
            Text("சரியான பதில்கள்: ${r.correct} / ${QuizEngine.PER_LEVEL}", fontFamily = TamilFont, fontSize = 17.sp)
            Text("மதிப்பெண்: ${r.score}", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 30.sp,
                color = MaterialTheme.colorScheme.primary)
            Text("இந்த நிலையின் அதிகம்: ${progress.best(r.level)}", fontFamily = TamilFont, fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.newBest) {
                Spacer(Modifier.height(10.dp))
                Surface(shape = RoundedCornerShape(20.dp), color = GOLD, contentColor = Color.White) {
                    Text("🎉 புதிய அதிக மதிப்பெண்!", fontFamily = TamilFont, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).scale(pop.value))
                }
            }
            if (!passed) {
                Spacer(Modifier.height(8.dp))
                Text("அடுத்த நிலையைத் திறக்க குறைந்தது ${QuizEngine.PASS} சரியான பதில்கள் வேண்டும்.",
                    fontFamily = TamilFont, fontSize = 13.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(24.dp))
            if (passed && !progress.prizeOpened(r.level)) {
                Button(onClick = onPrize, colors = ButtonDefaults.buttonColors(containerColor = GOLD),
                    modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("🎁 பரிசைத் திற", fontFamily = TamilFont, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
            }
            if (passed && r.level < QuizEngine.LEVELS) {
                Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text("அடுத்த நிலை ${r.level + 1} →", fontFamily = TamilFont, fontSize = 16.sp)
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onRetry, modifier = Modifier.weight(1f)) { Text("மீண்டும்", fontFamily = TamilFont) }
                OutlinedButton(onClick = onMap, modifier = Modifier.weight(1f)) { Text("நிலைகள்", fontFamily = TamilFont) }
            }
        }
        if (r.newBest || stars == 3) Confetti(Modifier.fillMaxSize())
    }
}

// ---------------------------------------------------------------- prize

@Composable
private fun PrizeView(level: Int, onDone: () -> Unit) {
    val context = LocalContext.current
    var opened by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }
    val reveal = remember { Animatable(0f) }
    val verse = remember {
        val r = DailyVerse.refAt(Random.nextInt(DailyVerse.size))
        r
    }
    var verseText by remember { mutableStateOf<Pair<String, String>?>(null) }
    LaunchedEffect(Unit) {
        val bv = com.vicky.tamilbible.data.BibleRepository(context).verseWithBook(verse[0], verse[1], verse[2])
        verseText = bv?.let { p -> p.second.ta to "${p.first.ta} ${verse[1]}:${verse[2]}" }
    }
    LaunchedEffect(opened) {
        if (!opened) {
            while (true) { shake.animateTo(8f, tween(90)); shake.animateTo(-8f, tween(90)); shake.animateTo(0f, tween(90)); delay(700) }
        } else reveal.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    Box(Modifier.fillMaxSize().pageBackground()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            if (!opened) {
                Text("நிலை $level பரிசு", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Spacer(Modifier.height(24.dp))
                Text("🎁", fontSize = 120.sp, modifier = Modifier.rotate(shake.value).clickable { opened = true })
                Spacer(Modifier.height(16.dp))
                Text("பெட்டியைத் தொட்டுத் திறங்கள்", fontFamily = TamilFont, fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Column(Modifier.scale(0.6f + 0.4f * reveal.value), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(BADGE_ICONS[level - 1], fontSize = 96.sp)
                    Text("புதிய பட்டம்!", fontFamily = TamilFont, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(BADGES[level - 1], fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 26.sp,
                        color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(20.dp))
                val vtNow: Pair<String, String>? = verseText
                vtNow?.let { vt ->
                    val t: String = vt.first; val ref: String = vt.second
                    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.padding(16.dp)) {
                            Text("உங்களுக்கான வாக்குத்தத்தம்", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(6.dp))
                            Text(t, fontFamily = TamilFont, fontSize = 16.sp, lineHeight = 25.sp)
                            Text("— $ref", fontFamily = TamilFont, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text("நிலைகளுக்குத் திரும்பு", fontFamily = TamilFont, fontSize = 16.sp)
                }
            }
        }
        if (opened) Confetti(Modifier.fillMaxSize())
    }
}

// ---------------------------------------------------------------- confetti

private data class Piece(val x: Float, val delay: Float, val speed: Float, val size: Float, val spin: Float, val color: Color, val drift: Float)

/** Falling confetti for celebrations (about 3 seconds). */
@Composable
private fun Confetti(modifier: Modifier) {
    val colors = listOf(Color(0xFFF26A1B), Color(0xFFD7261E), GOLD, Color(0xFF2E7D32), Color(0xFF1C5FA8), Color(0xFF8C1C2B))
    val pieces = remember {
        List(90) {
            Piece(Random.nextFloat(), Random.nextFloat() * 0.35f, 0.7f + Random.nextFloat() * 0.6f,
                6f + Random.nextFloat() * 8f, Random.nextFloat() * 720f, colors.random(), (Random.nextFloat() - 0.5f) * 0.2f)
        }
    }
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(3200, easing = LinearEasing)) }
    if (t.value >= 1f) return
    Canvas(modifier) {
        pieces.forEach { p ->
            val prog = ((t.value - p.delay) / (1f - p.delay)).coerceIn(0f, 1f) * p.speed
            if (prog <= 0f) return@forEach
            val x = (p.x + p.drift * prog) * size.width
            val y = -20f + prog * (size.height + 40f)
            rotate(p.spin * prog, pivot = Offset(x, y)) {
                drawRect(p.color, topLeft = Offset(x, y), size = Size(p.size, p.size * 0.5f))
            }
        }
    }
}

// ---------------------------------------------------------------- journey map

private val ROW = 176.dp
private val TOP = 40.dp

/**
 * The 15 levels laid along a winding road through cartoon scenes of the life of Jesus —
 * from the night sky over Bethlehem at the top to the sunrise of the resurrection at the bottom.
 * Levels sit on alternate sides; each level's scene is drawn on the opposite side.
 */
@Composable
private fun JourneyMap(progress: QuizProgress, tick: Int, unlocked: Int, onPlay: (Int) -> Unit) {
    val scroll = rememberScrollState()
    val density = androidx.compose.ui.platform.LocalDensity.current
    // Open near the level the player is on.
    LaunchedEffect(unlocked) {
        with(density) { scroll.scrollTo(((unlocked - 2).coerceAtLeast(0) * ROW.toPx()).toInt()) }
    }
    val total = TOP * 2 + ROW * QuizEngine.LEVELS
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize().verticalScroll(scroll)) {
        val w = maxWidth
        Box(Modifier.fillMaxWidth().height(total)) {
            Canvas(Modifier.fillMaxSize()) {
                val rowPx = ROW.toPx(); val topPx = TOP.toPx()
                drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(*JOURNEY_SKY))
                // Road through the level nodes
                fun nodeX(lv: Int) = size.width * (if (lv % 2 == 1) 0.27f else 0.73f)
                fun nodeY(lv: Int) = topPx + (lv - 1) * rowPx + rowPx * 0.42f
                val road = androidx.compose.ui.graphics.Path().apply {
                    moveTo(size.width / 2f, 0f)
                    var px = size.width / 2f; var py = 0f
                    for (lv in 1..QuizEngine.LEVELS) {
                        val x = nodeX(lv); val y = nodeY(lv); val dy = y - py
                        cubicTo(px, py + dy / 2f, x, y - dy / 2f, x, y); px = x; py = y
                    }
                    cubicTo(px, py + rowPx / 2f, size.width / 2f, size.height - rowPx / 3f, size.width / 2f, size.height)
                }
                drawPath(road, Color(0x99C9A86A), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 30.dp.toPx()))
                drawPath(road, Color(0xE6EBD9B0), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 24.dp.toPx()))
                drawPath(road, Color(0xB3FFFFFF), style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(18f, 14f))))
                // Scenes on the side opposite each node
                val box = minOf(size.width * 0.40f, rowPx * 0.72f)
                for (lv in 1..QuizEngine.LEVELS) {
                    val cx = size.width * (if (lv % 2 == 1) 0.73f else 0.27f)
                    val top = topPx + (lv - 1) * rowPx + rowPx * 0.06f
                    jesusScene(lv, cx - box / 2f, top, box / 100f)
                }
            }
            // Captions under scenes, and the level nodes
            for (lv in 1..QuizEngine.LEVELS) {
                val sceneLeft = lv % 2 == 0
                val rowTop = TOP + ROW * (lv - 1)
                Surface(
                    shape = RoundedCornerShape(10.dp), color = Color.White.copy(alpha = 0.88f), contentColor = Color(0xFF1B2233),
                    modifier = Modifier.width(w * 0.44f)
                        .offset(x = if (sceneLeft) w * 0.05f else w * 0.51f, y = rowTop + ROW * 0.80f),
                ) {
                    Text(JOURNEY_CAPTIONS[lv - 1], fontFamily = TamilFont, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                }
                LevelNode(lv, lv <= unlocked, remember(tick) { progress.stars(lv) }, remember(tick) { progress.best(lv) }, onPlay,
                    Modifier.width(w * 0.46f).offset(x = if (sceneLeft) w * 0.50f else w * 0.04f, y = rowTop + ROW * 0.42f - 32.dp))
            }
        }
    }
}

@Composable
private fun LevelNode(lv: Int, open: Boolean, stars: Int, best: Int, onPlay: (Int) -> Unit, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(64.dp).clip(CircleShape)
                .background(if (open) MaterialTheme.colorScheme.primary else Color(0xFFD5D8DF))
                .border(3.dp, if (stars == 3) GOLD else Color.White, CircleShape)
                .clickable(enabled = open) { onPlay(lv) },
            contentAlignment = Alignment.Center,
        ) {
            if (open) Text("$lv", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            else Icon(Icons.Filled.Lock, "பூட்டப்பட்டது", tint = Color(0xFF6B7080))
        }
        Surface(shape = RoundedCornerShape(10.dp), color = Color.White.copy(alpha = 0.9f), contentColor = Color(0xFF1B2233),
            modifier = Modifier.padding(top = 4.dp)) {
            Column(Modifier.padding(horizontal = 8.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text((1..3).joinToString("") { if (it <= stars) "★" else "☆" }, color = GOLD, fontSize = 14.sp)
                Text("${BADGE_ICONS[lv - 1]} ${BADGES[lv - 1]}", fontFamily = TamilFont, fontSize = 10.sp, maxLines = 1)
                if (best > 0) Text("அதிகம்: $best", fontSize = 9.sp, fontFamily = TamilFont, color = Color(0xFF5B6478))
            }
        }
    }
}
