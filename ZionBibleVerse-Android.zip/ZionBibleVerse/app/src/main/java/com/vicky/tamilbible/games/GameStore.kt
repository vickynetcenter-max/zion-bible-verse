package com.vicky.tamilbible.games

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gamesStore: DataStore<Preferences> by preferencesDataStore(name = "games")

/** Ids of the games that keep their progress here (the Bible quiz keeps its own). */
object Games {
    const val LETTER_PATH = "letter_path"
    const val SCRAMBLE = "scramble"
    const val MEMORY = "memory"
    const val WHO = "who_am_i"
    const val TIMELINE = "timeline"
    const val LEVELS = 20
}

/** Highest unlocked level and best stars (0–3) per level for one game. */
data class GameProgress(val unlocked: Int, val stars: Map<Int, Int>) {
    val totalStars: Int get() = stars.values.sum()
    val completed: Int get() = stars.count { it.value > 0 }
}

/** Game progress saved with DataStore. Levels open one at a time. */
object GameStore {
    private fun unlockedKey(game: String) = intPreferencesKey("${game}_unlocked")
    private fun starsKey(game: String, level: Int) = intPreferencesKey("${game}_stars_$level")

    fun progress(c: Context, game: String): Flow<GameProgress> = c.gamesStore.data.map { p ->
        GameProgress(
            unlocked = (p[unlockedKey(game)] ?: 1).coerceIn(1, Games.LEVELS),
            stars = (1..Games.LEVELS).associateWith { p[starsKey(game, it)] ?: 0 },
        )
    }

    /** Records a finished level: keeps the best stars and opens the next level. */
    suspend fun complete(c: Context, game: String, level: Int, stars: Int) {
        c.gamesStore.edit { p ->
            val sk = starsKey(game, level)
            if (stars > (p[sk] ?: 0)) p[sk] = stars.coerceIn(1, 3)
            val uk = unlockedKey(game)
            val next = (level + 1).coerceAtMost(Games.LEVELS)
            if (next > (p[uk] ?: 1)) p[uk] = next
        }
    }
}
