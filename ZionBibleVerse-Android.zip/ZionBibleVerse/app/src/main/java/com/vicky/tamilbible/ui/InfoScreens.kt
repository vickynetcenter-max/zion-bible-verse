package com.vicky.tamilbible.ui

import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.vicky.tamilbible.notify.DailyVerseNotifier
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.Church
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, url, Toast.LENGTH_LONG).show()
    }
}

fun dial(context: Context, phone: String) = openUrl(context, "tel:$phone")

/** Back arrow + title header shared by the simple screens. */
@Composable
fun ScreenScaffold(title: String, lang: Lang, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = lang.ui("பின்செல்", "Back"))
            }
            Text(
                title,
                fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                fontWeight = FontWeight.SemiBold, fontSize = 19.sp,
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
fun SocialScreen(lang: Lang, onBack: () -> Unit) {
    val context = LocalContext.current
    ScreenScaffold(lang.ui("சோசியல் மீடியா", "Social Media"), lang, onBack) {
        Text(
            lang.ui("${Church.NAME_TA} உடன் இணைந்திருங்கள்", "Stay connected with ${Church.NAME_EN}"),
            fontFamily = TamilFont, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SocialRow("Instagram", Church.INSTAGRAM_HANDLE, painterResource(R.drawable.ic_camera), Color(0xFFC13584)) {
            openUrl(context, Church.INSTAGRAM_URL)
        }
        SocialRow("YouTube", Church.YOUTUBE_NAME, rememberVectorPainter(Icons.Filled.PlayArrow), Color(0xFFE53935)) {
            openUrl(context, Church.YOUTUBE_URL)
        }
        SocialRow("Facebook", Church.FACEBOOK_HANDLE, rememberVectorPainter(Icons.Filled.Person), Color(0xFF1877F2)) {
            openUrl(context, Church.FACEBOOK_URL)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SocialRow(name: String, handle: String, icon: Painter, color: Color, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
                Icon(icon, null, Modifier.size(24.dp), tint = Color.White)
            }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(handle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: com.vicky.tamilbible.BibleViewModel, onBack: () -> Unit, onLegal: () -> Unit) {
    val lang = vm.lang
    val context = LocalContext.current
    ScreenScaffold(lang.ui("அமைப்பு", "Settings"), lang, onBack) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(vertical = 16.dp)) { ReadingSettings(vm, showLanguage = true) }
        }
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ZionEmblem(size = 44.dp)
                    Spacer(Modifier.size(10.dp))
                    Column {
                        Text(Church.NAME_TA, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(Church.PLACE_TA, fontFamily = TamilFont, fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(Church.PASTOR_TA, fontFamily = TamilFont, fontSize = 14.sp)
                Church.PRAYER_PHONES.forEach { phone ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { dial(context, phone) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Call, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(8.dp))
                        Text(lang.ui("24/7 ஜெப உதவி: ", "24/7 Prayer help: ") + phone, fontFamily = TamilFont, fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        Surface(onClick = onLegal, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(12.dp))
                Text("Disclaimer & Privacy Policy", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            "Zion Bible Verse · v" + appVersion(context),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
        )
    }
}

private fun appVersion(context: Context): String =
    runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: ""

