package com.vicky.tamilbible.data

/**
 * Disclaimer and privacy policy (English). Keep in sync with docs/privacy-policy.html,
 * which is the public page used for the Play Store listing. Bump [VERSION] when the
 * text changes materially so users see the "Before you begin" notice again.
 */
object Legal {
    const val VERSION = 2
    const val EFFECTIVE = "28 September 2026"

    val DISCLAIMER: List<Pair<String, String>> = listOf(
        "About this app" to
            "Zion Bible Verse is a free app made for the members and friends of Zion Cathedral, Jeganathapuram, Nagapattinam. It has no advertisements, no in-app purchases and no commercial purpose.",
        "Scripture text" to
            "The Tamil text is taken from a publicly available Tamil Bible text. The English text is the King James Version (KJV), which is in the public domain. All rights in any Bible translation remain with their respective owners. Great care has been taken, but typing or formatting errors may exist. For study, teaching or quotation, please compare with a printed Bible.",
        "Daily verse, notifications and praise list" to
            "“Today's Word”, its notifications and the praise list (Sthothira Bali) are provided for personal devotion and encouragement only. They are not professional, medical, legal, financial or psychological advice. The app shows the day's verse as a notification five times a day: 6 AM, 10 AM, 12 noon, 4 PM and 8 PM. You can turn these off at any time from your phone's Settings › Apps › Zion Bible Verse › Notifications.",
        "Praise list" to
            "The praise list (1000 ஸ்தோத்திர பலிகள்) is taken from a public-domain Tamil Christian ebook on archive.org (Public Domain Mark 1.0). Small spelling corrections have been made; if you notice an error, please contact us.",
        "Songs" to
            "Song lyrics belong to their authors and publishers. Songs are included only with permission or where they are in the public domain. If you own the rights to a song in this app and want it corrected or removed, please contact us and it will be removed promptly.",
        "24/7 Prayer help" to
            "The prayer help numbers are for prayer support only. They are not an emergency, medical or counselling service. In an emergency in India, call 112. Tapping a number opens your phone's dialer; the app does not place calls by itself.",
        "External links" to
            "The Instagram, YouTube and Facebook links open those apps or websites. Their content and privacy practices are governed by those companies, and Zion Cathedral is not responsible for them.",
        "Names, logos and fonts" to
            "Instagram, YouTube and Facebook are trademarks of their respective owners and are named only to identify the links. The Zion Cathedral name and logo belong to Zion Cathedral. The fonts Noto Sans Tamil and Literata are used under the SIL Open Font License 1.1.",
        "No warranty and limitation of liability" to
            "The app is provided “as is”, without warranties of any kind. To the fullest extent permitted by law, Zion Cathedral, its pastors, staff and the volunteers who built the app are not liable for any loss or damage arising from the use of, or inability to use, the app — including the loss of notes stored on your device.",
        "Contact" to
            "For corrections, content concerns or rights requests: Zion Cathedral, Jeganathapuram, Nagapattinam, Tamil Nadu, India. Phone: 7373839093, 7373835943.",
    )

    val PRIVACY: List<Pair<String, String>> = listOf(
        "Summary" to
            "Zion Bible Verse does not collect, upload, share or sell any personal information. There is no account or login, no advertising, no analytics and no tracking. The app uses the internet only to download church announcements and verse corrections.",
        "Information kept only on your phone" to
            "To work, the app saves a few things on your phone: your settings (language, text size, theme), your last reading position, your place in the praise list, any notes you write, the verses you highlight or bookmark, the dates and reminders you add in the Reminders calendar, and a random number used to choose your personal order of daily verses. This information stays on your device and is never sent to Zion Cathedral or anyone else. It is deleted when you uninstall the app or clear its data.",
        "Church announcements and verse corrections" to
            "When the app opens, and at the daily-verse times, it downloads the church's announcements (with any pictures, kept in Zion Cathedral's Google Drive) and any verse corrections from a Google Sheet run by Zion Cathedral (through Google Apps Script). Nothing about you is sent with this request. As with any web request, Google may receive technical details such as your IP address under Google's own privacy policy. The downloaded text is stored on your phone so it also works offline.",
        "Phone backups" to
            "If Android backup is turned on for your phone, Android may include this app's data (such as your notes and settings) in your own Google account backup. That backup is controlled by Google and your phone settings; Zion Cathedral cannot see or access it.",
        "Permissions" to
            "Internet — to download church announcements and verse corrections. Notifications — to show the daily verse, church announcements and your reminders. Run at startup — to set the verse notifications and your reminders again after the phone restarts. The app does not ask for location, contacts, camera, microphone, files, phone calls or any other personal data.",
        "Sharing" to
            "When you use Share or Copy, the text is passed to the app you choose (for example WhatsApp) or to your clipboard. What happens after that is governed by that app.",
        "Children" to
            "The app is suitable for all ages. It collects no personal information from anyone, including children.",
        "Changes to this policy" to
            "If this policy changes, the updated version will be shown in the app and on this page, with a new effective date.",
        "Contact" to
            "Zion Cathedral, Jeganathapuram, Nagapattinam, Tamil Nadu, India. Phone: 7373839093, 7373835943.",
    )
}
