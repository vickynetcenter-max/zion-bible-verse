package com.vicky.tamilbible.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.HighlightColors
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.Mark
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

/**
 * Two dashboard tiles share this screen: என் வசனங்கள் (bookmarks) and ஹைலைட்ஸ் (colour highlights). Filter highlights by
 * colour, sort by newest or Bible order, open a verse in the reader, share, or remove.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyVersesScreen(vm: BibleViewModel, highlights: Boolean = false, onBack: () -> Unit, onOpen: (book: Int, chapter: Int, verse: Int) -> Unit) {
    val lang = vm.lang
    val context = LocalContext.current
    val tab = if (highlights) 1 else 0                              // 0 = bookmarks, 1 = highlights
    var colorFilter by rememberSaveable { mutableStateOf<Int?>(null) }
    var bibleOrder by rememberSaveable { mutableStateOf(false) }
    // Verse text + reference, loaded as needed.
    val texts = remember { mutableStateMapOf<String, Pair<String, String>>() }

    val all = vm.marks.values.toList()
    val shown = all
        .filter { if (tab == 0) it.bookmark else it.color != null && (colorFilter == null || it.color == colorFilter) }
        .let { list -> if (bibleOrder) list.sortedWith(compareBy({ it.book }, { it.chapter }, { it.verse })) else list.sortedByDescending { it.time } }

    LaunchedEffect(shown.map { it.key }, lang) {
        shown.forEach { m ->
            if (m.key !in texts) {
                vm.verseWithBook(m.book, m.chapter, m.verse)?.let { (b, v) ->
                    texts[m.key] = (if (lang == Lang.EN) v.en else v.ta) to "${b.displayName(lang)} ${m.chapter}:${m.verse}"
                }
            }
        }
    }

    fun shareList() {
        val body = shown.mapNotNull { m -> texts[m.key]?.let { (t, ref) -> "$t\n— $ref" } }.joinToString("\n\n")
        if (body.isNotBlank()) context.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body), null))
    }

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("பின்செல்", "Back")) }
            Text(if (highlights) lang.ui("ஹைலைட்ஸ்", "Highlights") else lang.ui("என் வசனங்கள்", "My Verses"), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
                fontSize = 19.sp, modifier = Modifier.weight(1f))
            if (shown.isNotEmpty()) IconButton(onClick = ::shareList) { Icon(Icons.Filled.Share, lang.ui("அனைத்தையும் பகிர்", "Share all")) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (tab == 1) {
                    // Colour filter: all + each colour
                    LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            Box(Modifier.size(30.dp).clip(CircleShape)
                                .border(if (colorFilter == null) 2.5.dp else 1.dp,
                                    if (colorFilter == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable { colorFilter = null }, contentAlignment = Alignment.Center) {
                                Text(lang.ui("எல்லா", "All"), fontSize = 9.sp, fontFamily = TamilFont)
                            }
                        }
                        items(HighlightColors.ARGB.indices.toList()) { i ->
                            Box(Modifier.size(30.dp).clip(CircleShape).background(Color(HighlightColors.ARGB[i]))
                                .border(if (colorFilter == i) 2.5.dp else 0.dp,
                                    if (colorFilter == i) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                                .clickable { colorFilter = i })
                        }
                    }
                } else Spacer(Modifier.weight(1f))
                TextButton(onClick = { bibleOrder = !bibleOrder }) {
                    Text(if (bibleOrder) lang.ui("வேத வரிசை ⇅", "Bible order ⇅") else lang.ui("புதியவை ⇅", "Newest ⇅"),
                        fontFamily = TamilFont, fontSize = 12.sp)
                }
            }
        }

        if (shown.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(painterResource(if (tab == 0) R.drawable.ic_bookmark_border else R.drawable.ic_highlight), null,
                    Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text(
                    if (tab == 0) lang.ui("இன்னும் புத்தகக்குறிகள் இல்லை.\nவாசிக்கும்போது வசனத்தைத் தொட்டு 🔖 \"குறி\" அழுத்துங்கள்.",
                        "No bookmarks yet.\nTap a verse while reading and choose 🔖 Bookmark.")
                    else lang.ui("இன்னும் வண்ணக் குறிகள் இல்லை.\nவாசிக்கும்போது வசனத்தைத் தொட்டு \"வண்ணம்\" தேர்வு செய்யுங்கள்.",
                        "No highlights yet.\nTap a verse while reading and choose a Colour."),
                    fontFamily = TamilFont, fontSize = 14.sp, lineHeight = 22.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            return@Column
        }

        val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
        LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.key }) { m ->
                val t = texts[m.key]
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(m.book, m.chapter, m.verse) }) {
                    Row {
                        // Colour stripe for highlights
                        Box(Modifier.width(6.dp).height(92.dp).background(
                            m.color?.let { highlightColor(it, dark).copy(alpha = 1f) } ?: MaterialTheme.colorScheme.primary))
                        Column(Modifier.weight(1f).padding(start = 12.dp, top = 10.dp, bottom = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(t?.second ?: "…", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                                if (m.bookmark && tab == 1) Icon(painterResource(R.drawable.ic_bookmark), null,
                                    Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                            Text(t?.first ?: "", fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont, fontSize = 14.sp,
                                lineHeight = 21.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(onClick = { if (tab == 0) vm.removeBookmark(m) else vm.removeHighlight(m) }) {
                            Icon(Icons.Filled.Close, lang.ui("நீக்கு", "Remove"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
