package com.vicky.tamilbible.ui

import androidx.compose.ui.graphics.Color
import com.vicky.tamilbible.data.HighlightColors

/** Highlight colour behind a verse: strong enough to see, soft enough to read through (softer in black mode). */
fun highlightColor(index: Int, dark: Boolean): Color =
    Color(HighlightColors.ARGB[index.coerceIn(0, HighlightColors.ARGB.size - 1)]).copy(alpha = if (dark) 0.32f else 0.55f)
