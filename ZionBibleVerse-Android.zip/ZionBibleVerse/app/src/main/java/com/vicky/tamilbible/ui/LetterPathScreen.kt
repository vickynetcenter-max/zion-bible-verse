package com.vicky.tamilbible.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.games.LetterPathGenerator
import com.vicky.tamilbible.games.LetterPathLevels
import com.vicky.tamilbible.games.LetterPathState
import com.vicky.tamilbible.games.Move
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor
import kotlin.math.max

private val BOARD_BG = Color(0xFFF7F4EF)
private val GRID_LINE = Color(0xFFD9D2C7)

/** ✍️ எழுத்துப் பாதை — draw one line through the letters in order, covering every square. */
@Composable
fun LetterPathScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val total = LetterPathLevels.ALL.size

    // Start at the highest unlocked level.
    var level by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { level = GameStore.progress(context, Games.LETTER_PATH).first().unlocked.coerceAtMost(total) }

    GameScaffold("எழுத்துப் பாதை", GameThemes.LETTER_PATH, onBack) {
        if (level == 0) { CircularProgressIndicator(); return@GameScaffold }
        val def = LetterPathLevels.ALL[level - 1]
        // A fresh, always-solvable board for this level (8×8 is built off the main thread).
        val state by produceState<LetterPathState?>(null, level) {
            value = null
            value = withContext(Dispatchers.Default) { LetterPathState(LetterPathGenerator.build(def)) }
        }
        var version by remember(level) { mutableIntStateOf(0) }          // redraw after each change
        var started by remember(level) { mutableStateOf(false) }
        var message by remember(level) { mutableStateOf<String?>(null) }
        var msgKey by remember(level) { mutableIntStateOf(0) }
        var saved by remember(level) { mutableStateOf(false) }
        var resets by remember(level) { mutableIntStateOf(0) }
        val st = state
        val solved = st?.solved == true && version >= 0
        val seconds = rememberGameSeconds(running = started && !solved, key = "$level-${st.hashCode()}-$resets")
        val stars = LetterPathState.stars(def.n * def.n, seconds)

        LaunchedEffect(msgKey) { if (message != null) { delay(1000); message = null } }
        LaunchedEffect(solved) {
            if (solved && !saved) { saved = true; GameStore.complete(context, Games.LETTER_PATH, level, stars) }
        }

        LevelRow(level, total) {
            SmallAction("Reset") { st?.reset(); started = false; resets++; version++ }
        }
        Row {
            Text("${def.meaning} · ${def.letters.size} எழுத்துகள்", fontFamily = TamilFont, fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("⏱ " + formatSeconds(seconds), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }

        if (st == null) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Board(st, version, solved) { cell ->
                when (st.touch(cell)) {
                    Move.STARTED -> { started = true; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); version++ }
                    Move.ADDED -> { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); version++ }
                    Move.REMOVED, Move.CUT -> version++
                    Move.NOT_FIRST -> { message = "இது முதல் எழுத்து அல்ல"; msgKey++ }
                    Move.NOT_NEXT -> { message = "இது அடுத்த எழுத்து அல்ல"; msgKey++ }
                    Move.IGNORED -> {}
                }
            }
        }

        // Message line (fixed height so the layout doesn't jump)
        Box(Modifier.fillMaxWidth().height(22.dp), contentAlignment = Alignment.Center) {
            message?.let { Text(it, color = GAME_RED, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
        }

        if (solved) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(def.word, color = GAME_GREEN, fontFamily = TamilFont, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                StarsRow(stars, 34.dp)
            }
        }
        WideAction("Undo", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurface, enabled = !solved) {
            if (st?.undo() == true) version++
        }
        if (solved) {
            if (level < total) WideAction("Next", GAME_GREEN) { level += 1 }
            else Text("🎉 எல்லா 20 நிலைகளும் முடிந்தன!", fontFamily = TamilFont, fontWeight = FontWeight.Bold,
                color = GAME_GREEN, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun Board(st: LetterPathState, version: Int, solved: Boolean, onCell: (Int) -> Unit) {
    val n = st.puzzle.n
    val measurer = rememberTextMeasurer()
    val lineColor = if (solved) GAME_GREEN else GAME_RED
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(1f)
            .pointerInput(st) {
                val cellPx = size.width.toFloat() / n
                fun cellAt(p: Offset): Int? {
                    val c = floor(p.x / cellPx).toInt(); val r = floor(p.y / cellPx).toInt()
                    return if (c in 0 until n && r in 0 until n) r * n + c else null
                }
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var last = down.position
                    cellAt(last)?.let(onCell)
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val now = change.position
                        // Fast drags can jump over squares: walk the segment in small steps.
                        val dx = now.x - last.x; val dy = now.y - last.y
                        val steps = max(1, (max(kotlin.math.abs(dx), kotlin.math.abs(dy)) / (cellPx / 4f)).toInt())
                        for (i in 1..steps) cellAt(Offset(last.x + dx * i / steps, last.y + dy * i / steps))?.let(onCell)
                        last = now
                        change.consume()
                    }
                }
            },
    ) {
        @Suppress("UNUSED_EXPRESSION") version
        val cs = size.width / n
        val radius = CornerRadius(cs * 0.22f)
        drawRoundRect(BOARD_BG, cornerRadius = CornerRadius(cs * 0.4f))
        // Covered squares
        st.path.forEach { c ->
            drawRoundRect(lineColor.copy(alpha = if (solved) 0.24f else 0.16f),
                topLeft = Offset((c % n) * cs + 3f, (c / n) * cs + 3f), size = Size(cs - 6f, cs - 6f), cornerRadius = radius)
        }
        // Thin grid lines
        for (i in 1 until n) {
            drawLine(GRID_LINE, Offset(i * cs, 8f), Offset(i * cs, size.height - 8f), strokeWidth = 1.5f)
            drawLine(GRID_LINE, Offset(8f, i * cs), Offset(size.width - 8f, i * cs), strokeWidth = 1.5f)
        }
        // The line
        if (st.path.size > 1) {
            val path = Path()
            st.path.forEachIndexed { i, c ->
                val x = (c % n + 0.5f) * cs; val y = (c / n + 0.5f) * cs
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, lineColor.copy(alpha = 0.9f), style = Stroke(width = cs * 0.24f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else if (st.path.size == 1) {
            val c = st.path[0]
            drawCircle(lineColor.copy(alpha = 0.9f), cs * 0.12f, Offset((c % n + 0.5f) * cs, (c / n + 0.5f) * cs))
        }
        // Letters: black circles with white Tamil text (green when solved)
        val textSize = max(11f, (cs * 0.30f) / density / fontScale)
        st.puzzle.letterAt.forEach { (cell, index) ->
            val center = Offset((cell % n + 0.5f) * cs, (cell / n + 0.5f) * cs)
            drawCircle(if (solved) GAME_GREEN else Color(0xFF1B1B1B), cs * 0.34f, center)
            val layout = measurer.measure(st.puzzle.letters[index],
                TextStyle(color = Color.White, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = textSize.sp))
            drawText(layout, topLeft = Offset(center.x - layout.size.width / 2f, center.y - layout.size.height / 2f))
        }
    }
}
