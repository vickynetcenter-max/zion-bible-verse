package com.vicky.tamilbible.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.Church
import com.vicky.tamilbible.ui.theme.TamilFont
import com.vicky.tamilbible.ui.theme.ZionNavy
import kotlinx.coroutines.delay

/** Animated logo shown on launch; always on white (brand colours). Calls [onDone] when finished. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 1900, easing = FastOutSlowInEasing))
        delay(600)
        onDone()
    }
    val p = progress.value
    Box(Modifier.fillMaxSize().background(Color.White), contentAlignment = Alignment.Center) {
        ZionLogo(size = 180.dp, progress = p)
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 40.dp)
                .alpha(((p - 0.8f) / 0.2f).coerceIn(0f, 1f)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text("Zion Bible Verse", color = ZionNavy, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(2.dp))
            Text(Church.NAME_TA, color = ZionNavy, fontFamily = TamilFont, fontSize = 14.sp)
            Text(Church.PLACE_TA, color = Color(0xFF5B6478), fontFamily = TamilFont, fontSize = 12.sp)
        }
    }
}
