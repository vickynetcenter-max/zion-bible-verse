package com.vicky.tamilbible.data

import android.content.Context
import com.vicky.tamilbible.BuildConfig
import org.json.JSONArray
import java.time.LocalDate
import java.util.UUID

/**
 * Anonymous usage counts for the church admin: a random id per phone (no name, number or
 * location), "opened the app today", and "received / opened announcement X". Each fact is
 * sent once; failures are retried next time.
 */
object Analytics {
    private fun prefs(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun deviceId(c: Context): String {
        val p = prefs(c)
        return p.getString("device", null) ?: UUID.randomUUID().toString().also { p.edit().putString("device", it).apply() }
    }

    /** Once a day, when the app is opened. */
    suspend fun pingDaily(c: Context) {
        if (BuildConfig.IS_ADMIN || !ChurchApi.configured) return
        val today = LocalDate.now().toString()
        if (prefs(c).getString("pinged", null) == today) return
        val res = ChurchApi.postJson("", "ping", mapOf("device" to deviceId(c), "version" to versionName(c)))
        if (res?.optBoolean("ok") == true) prefs(c).edit().putString("pinged", today).apply()
    }

    /** Reports announcements this phone received ("r") or opened ("o") — each only once. */
    suspend fun reach(c: Context, ids: Collection<Long>, type: String) {
        if (BuildConfig.IS_ADMIN || !ChurchApi.configured || ids.isEmpty()) return
        val key = "sent_$type"
        val sent = prefs(c).getStringSet(key, emptySet())!!
        val todo = ids.map { it.toString() }.filter { it !in sent }.take(50)
        if (todo.isEmpty()) return
        val res = ChurchApi.postJson("", "reach", mapOf("device" to deviceId(c), "type" to type, "ids" to JSONArray(todo)))
        if (res?.optBoolean("ok") == true) {
            // Keep the list short: only ids from the last 30 days.
            val cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
            val keep = (sent + todo).filter { (it.toLongOrNull() ?: 0) > cutoff }.toSet()
            prefs(c).edit().putStringSet(key, keep).apply()
        }
    }

    private fun versionName(c: Context): String =
        runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "" }.getOrDefault("")
}

/** Admin dashboard numbers (from the script's "stats" action). */
data class DayCount(val day: String, val active: Int, val installs: Int)
data class Reach(val received: Int, val opened: Int)
data class AnalyticsData(
    val installs: Int, val today: Int, val week: Int, val month: Int,
    val daily: List<DayCount>, val versions: Map<String, Int>, val reach: Map<Long, Reach>,
)
