package com.vicky.tamilbible.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalTime

/** A personal booking / event on a date, e.g. "Wedding" on 2026-11-15 at 10:00. */
data class Booking(
    val id: Long,
    val date: LocalDate,
    val time: LocalTime?,
    val title: String,
    val note: String,
    val remind: Boolean,
)

/** Stored on this phone only (files/bookings.json) — never shared. */
class BookingsStore(context: Context) {
    private val file = File(context.filesDir, "bookings.json")

    fun all(): List<Booking> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Booking(
                o.getLong("id"), LocalDate.parse(o.getString("date")),
                o.optString("time").ifBlank { null }?.let { LocalTime.parse(it) },
                o.optString("title"), o.optString("note"), o.optBoolean("remind", true),
            )
        }.sortedWith(compareBy({ it.date }, { it.time ?: LocalTime.MIN }))
    }.getOrDefault(emptyList())

    private fun save(list: List<Booking>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("date", it.date.toString()).put("time", it.time?.toString() ?: "")
                .put("title", it.title).put("note", it.note).put("remind", it.remind))
        }
        val tmp = File(file.parentFile, "bookings.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }

    fun upsert(b: Booking) = save(all().filter { it.id != b.id } + b)
    fun delete(id: Long) = save(all().filter { it.id != id })
    fun on(date: LocalDate, exceptId: Long? = null) = all().filter { it.date == date && it.id != exceptId }
}
