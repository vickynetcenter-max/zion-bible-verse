package com.vicky.tamilbible.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.games.TimelineEvents
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

/** ⏳ காலவரிசை — tap the events in the order they happened (earliest first). */
@Composable
fun TimelineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val theme = GameThemes.TIMELINE
    var level by remember { mutableIntStateOf(0) }
    var attempt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { level = GameStore.progress(context, Games.TIMELINE).first().unlocked }

    GameScaffold("காலவரிசை", theme, onBack) {
        if (level == 0) { CircularProgressIndicator(); return@GameScaffold }
        val count = TimelineEvents.countFor(level)
        // Each round: a random set of events (by their position in history), shown shuffled.
        val rounds = remember(level, attempt) {
            List(TimelineEvents.ROUNDS) { TimelineEvents.ALL.indices.shuffled().take(count).sorted() }
        }
        var round by remember(rounds) { mutableIntStateOf(0) }
        val done = remember(rounds, round) { mutableStateListOf<Int>() }       // event indices placed so far
        val shuffled = remember(rounds, round) { rounds[round].shuffled() }
        var mistakes by remember(rounds) { mutableIntStateOf(0) }
        var wrongIdx by remember(rounds, round) { mutableIntStateOf(-1) }
        var wrongKey by remember(rounds, round) { mutableIntStateOf(0) }
        var started by remember(rounds) { mutableStateOf(false) }
        var finished by remember(rounds) { mutableStateOf(false) }
        val seconds = rememberGameSeconds(started && !finished, rounds)
        val stars = when { mistakes == 0 -> 3; mistakes <= 2 -> 2; else -> 1 }
        val roundDone = done.size == count

        LaunchedEffect(finished) { if (finished) GameStore.complete(context, Games.TIMELINE, level, stars) }
        LaunchedEffect(roundDone, round) {
            if (roundDone) { delay(1000); if (round + 1 < rounds.size) round++ else finished = true }
        }

        LevelRow(level, Games.LEVELS) { Text("⏱ " + formatSeconds(seconds), fontWeight = FontWeight.SemiBold) }
        Row {
            Text("சுற்று ${(round + 1).coerceAtMost(rounds.size)} / ${rounds.size} · முதலில் நடந்ததிலிருந்து தொடுங்கள்",
                fontFamily = TamilFont, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("❌ $mistakes", fontSize = 14.sp, color = if (mistakes > 0) GAME_RED else MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (finished) {
            LevelResult(true, stars, "வரிசை சரி! 🎉", "${rounds.size} சுற்றுகள் · ${formatSeconds(seconds)} · தவறுகள் $mistakes", theme,
                onNext = if (level < Games.LEVELS) ({ level += 1 }) else null, onRetry = { attempt++ })
            return@GameScaffold
        }

        // The timeline built so far: a vertical line with numbered stops.
        Surface(shape = RoundedCornerShape(18.dp), color = theme.start.copy(alpha = 0.07f)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                if (done.isEmpty()) Text("📜 இங்கே வரிசை உருவாகும்", fontFamily = TamilFont, color = MaterialTheme.colorScheme.onSurfaceVariant)
                done.forEachIndexed { i, ev ->
                    Row(verticalAlignment = Alignment.Top) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            NumberBadge(i + 1, if (roundDone) GAME_GREEN else theme.start)
                            if (i < done.size - 1) Box(Modifier.padding(vertical = 2.dp).width(3.dp).height(16.dp)
                                .clip(RoundedCornerShape(2.dp)).background(theme.end.copy(alpha = 0.55f)))
                        }
                        Spacer(Modifier.size(10.dp))
                        Text(TimelineEvents.ALL[ev], fontFamily = TamilFont, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                            color = if (roundDone) GAME_GREEN else MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 3.dp))
                    }
                }
            }
        }
        // Events still to place
        shuffled.filter { it !in done }.forEach { ev ->
            val wrong = ev == wrongIdx
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (wrong) GAME_RED.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth().then(if (wrong) Modifier.shake(wrongKey) else Modifier)
                    .border(1.5.dp, if (wrong) GAME_RED else theme.start.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(enabled = !roundDone) {
                        started = true
                        val next = rounds[round][done.size]
                        if (ev == next) { done += ev; wrongIdx = -1 } else { mistakes++; wrongIdx = ev; wrongKey++ }
                    },
            ) {
                Text(TimelineEvents.ALL[ev], fontFamily = TamilFont, fontSize = 16.sp,
                    color = if (wrong) GAME_RED else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
            }
        }
    }
}
