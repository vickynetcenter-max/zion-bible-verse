package com.vicky.tamilbible.notify

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.vicky.tamilbible.BuildConfig
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Receives an announcement the moment the admin posts it (the Apps Script sends a Firebase
 * message to the "zion-news" topic). Works even when the app is closed. The regular sync is
 * still there as a fallback, and the same announcement is never shown twice.
 */
class ZionMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        if (BuildConfig.IS_ADMIN) return
        val d = message.data
        val id = d["id"]?.toLongOrNull() ?: return
        // Put it in the list right away (the app shows it instantly when opened).
        com.vicky.tamilbible.data.RemoteCache.fromPush { d[it] }?.let { com.vicky.tamilbible.data.RemoteCache.addLocal(applicationContext, it) }
        runBlocking {
            withTimeoutOrNull(8_000) {
                ChurchSync.showPush(applicationContext, id, d["title"].orEmpty(), d["message"].orEmpty(), d["image"].orEmpty(), d["link"].orEmpty())
            }
        }
        // Refresh the saved list in the background (also picks up any verse corrections).
        runBlocking { withTimeoutOrNull(8_000) { runCatching { ChurchSync.sync(applicationContext) } } }
    }

    override fun onNewToken(token: String) { subscribe(applicationContext) }

    companion object {
        const val TOPIC = "zion-news"

        /** Joins the announcements topic (members' app only; no-op until Firebase is configured). */
        private fun prefs(c: Context) = c.getSharedPreferences("push", Context.MODE_PRIVATE)

        fun subscribe(c: Context) {
            if (BuildConfig.IS_ADMIN) return
            val p = prefs(c)
            runCatching {
                if (FirebaseApp.getApps(c).isEmpty()) { p.edit().putString("status", "Firebase not set up in this build").apply(); return }
                FirebaseMessaging.getInstance().subscribeToTopic(TOPIC).addOnCompleteListener { t ->
                    p.edit().putString("status", if (t.isSuccessful) "OK" else "subscribe failed: ${t.exception?.message}").apply()
                }
                FirebaseMessaging.getInstance().token.addOnCompleteListener { t ->
                    if (t.isSuccessful) p.edit().putString("token", t.result).apply()
                }
            }.onFailure { p.edit().putString("status", "error: ${it.message}").apply() }
        }

        /** (status, token) for the Settings → push check. */
        fun diagnostics(c: Context): Pair<String, String> =
            (prefs(c).getString("status", null) ?: "not checked yet") to (prefs(c).getString("token", null) ?: "")
    }
}
