package com.vicky.tamilbible.notify

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.vicky.tamilbible.BuildConfig
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Receives an announcement the moment the admin posts it (the Apps Script sends a Firebase
 * message to the "zion-news" topic). Works even when the app is closed. The regular sync is
 * still there as a fallback, and the same announcement is never shown twice.
 */
class ZionMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        if (BuildConfig.IS_ADMIN) return
        val d = message.data
        val id = d["id"]?.toLongOrNull() ?: return
        runBlocking {
            withTimeoutOrNull(8_000) {
                ChurchSync.showPush(applicationContext, id, d["title"].orEmpty(), d["message"].orEmpty(), d["image"].orEmpty())
            }
        }
        // Refresh the saved list in the background (also picks up any verse corrections).
        runBlocking { withTimeoutOrNull(8_000) { runCatching { ChurchSync.sync(applicationContext) } } }
    }

    override fun onNewToken(token: String) { subscribe(applicationContext) }

    companion object {
        const val TOPIC = "zion-news"

        /** Joins the announcements topic (members' app only; no-op until Firebase is configured). */
        fun subscribe(c: Context) {
            if (BuildConfig.IS_ADMIN) return
            runCatching {
                if (FirebaseApp.getApps(c).isEmpty()) return
                FirebaseMessaging.getInstance().subscribeToTopic(TOPIC)
            }
        }
    }
}
