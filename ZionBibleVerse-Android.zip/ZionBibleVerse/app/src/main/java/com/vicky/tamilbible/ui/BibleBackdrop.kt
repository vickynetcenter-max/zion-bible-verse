package com.vicky.tamilbible.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import kotlin.math.min

/**
 * Page background with a faint Zion Cathedral emblem watermark in the centre.
 * Drawn behind content, so text stays fully readable in both white and black modes.
 */
@Composable
fun Modifier.pageBackground(): Modifier {
    val bg = MaterialTheme.colorScheme.background
    val alpha = if (bg.luminance() < 0.5f) 0.10f else 0.07f
    return this.drawBehind {
        drawRect(bg)
        val s = min(size.width, size.height) * 0.75f
        val left = (size.width - s) / 2f
        val top = (size.height - s) / 2f + size.height * 0.03f
        drawIntoCanvas { canvas ->
            // One translucent layer so the overlapping logo parts fade evenly.
            canvas.saveLayer(Rect(left, top, left + s, top + s), Paint().apply { this.alpha = alpha })
            translate(left, top) {
                scale(s / 200f, s / 200f, pivot = Offset.Zero) { drawEmblem(1f) }
            }
            canvas.restore()
        }
    }
}
