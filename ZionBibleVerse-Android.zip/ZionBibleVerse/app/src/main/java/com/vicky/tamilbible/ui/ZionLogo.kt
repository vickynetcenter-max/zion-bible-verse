package com.vicky.tamilbible.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.ui.theme.ZionNavy
import com.vicky.tamilbible.ui.theme.ZionOrange
import com.vicky.tamilbible.ui.theme.ZionRed

/** Maps overall [p] (0..1) onto a sub-phase [from]..[to], clamped to 0..1. */
private fun phase(p: Float, from: Float, to: Float) = ((p - from) / (to - from)).coerceIn(0f, 1f)

/**
 * Vector redraw of the Zion Cathedral emblem: orange ring, cross with a dove, open book.
 * [progress] 0→1 animates it in (ring draws, cross grows, book rises); 1 = static logo.
 * Replace with the church's official PNG when available.
 */
@Composable
fun ZionEmblem(size: Dp, progress: Float = 1f, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 200f   // drawn on a 200×200 grid
        scale(k, k, pivot = Offset.Zero) { drawEmblem(progress) }
    }
}

private fun DrawScope.drawEmblem(p: Float) {
    val ring = phase(p, 0f, 0.45f)
    val cross = phase(p, 0.25f, 0.6f)
    val dove = phase(p, 0.5f, 0.75f)
    val book = phase(p, 0.45f, 0.8f)

    // Ring, open at the bottom where the book sits.
    if (ring > 0f) {
        drawArc(
            color = ZionOrange,
            startAngle = 125f,
            sweepAngle = 290f * ring,
            useCenter = false,
            topLeft = Offset(34f, 22f),
            size = Size(132f, 132f),
            style = Stroke(width = 11f, cap = StrokeCap.Round),
        )
    }

    // Cross, growing from its centre.
    if (cross > 0f) {
        scale(cross, cross, pivot = Offset(100f, 86f)) {
            drawRect(ZionOrange, Offset(90f, 42f), Size(20f, 98f))
            drawRect(ZionOrange, Offset(62f, 64f), Size(76f, 20f))
        }
    }

    // Dove resting on the crossing.
    if (dove > 0f) {
        val a = dove
        translate(0f, (1f - a) * -14f) {
            val body = Path().apply {
                moveTo(84f, 78f)
                cubicTo(92f, 70f, 108f, 70f, 116f, 76f)
                lineTo(124f, 72f)
                lineTo(120f, 80f)
                cubicTo(110f, 88f, 94f, 88f, 84f, 78f)
                close()
            }
            drawPath(body, Color.White.copy(alpha = a))
            val wing = Path().apply {
                moveTo(96f, 76f)
                lineTo(104f, 58f)
                lineTo(110f, 76f)
                close()
            }
            drawPath(wing, Color.White.copy(alpha = a))
        }
    }

    // Open book rising into place.
    if (book > 0f) {
        translate(0f, (1f - book) * 24f) {
            val left = Path().apply {
                moveTo(100f, 146f)
                cubicTo(84f, 136f, 62f, 134f, 40f, 138f)
                lineTo(40f, 156f)
                cubicTo(62f, 152f, 84f, 154f, 100f, 164f)
                close()
            }
            val right = Path().apply {
                moveTo(100f, 146f)
                cubicTo(116f, 136f, 138f, 134f, 160f, 138f)
                lineTo(160f, 156f)
                cubicTo(138f, 152f, 116f, 154f, 100f, 164f)
                close()
            }
            drawPath(left, ZionRed.copy(alpha = book))
            drawPath(right, ZionRed.copy(alpha = book))
            val pages = Path().apply {
                moveTo(100f, 150f)
                cubicTo(86f, 142f, 66f, 141f, 48f, 143f)
                moveTo(100f, 150f)
                cubicTo(114f, 142f, 134f, 141f, 152f, 143f)
            }
            drawPath(pages, Color.White.copy(alpha = 0.8f * book), style = Stroke(2.5f))
        }
    }
}

/** Emblem plus the "ZION CATHEDRAL" wordmark underneath. */
@Composable
fun ZionLogo(size: Dp, progress: Float = 1f, modifier: Modifier = Modifier) {
    val text = phase(progress, 0.7f, 1f)
    val scaleSp = size.value / 160f
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        ZionEmblem(size, progress)
        Column(
            Modifier.graphicsLayer {
                alpha = text
                translationY = (1f - text) * 30f
            },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = ZionNavy)) { append("Z") }
                    withStyle(SpanStyle(color = ZionRed)) { append("I") }
                    withStyle(SpanStyle(color = ZionNavy)) { append("ON") }
                },
                fontWeight = FontWeight.Black,
                fontSize = (44 * scaleSp).sp,
                letterSpacing = (2 * scaleSp).sp,
            )
            Text(
                "CATHEDRAL",
                color = ZionNavy,
                fontWeight = FontWeight.Bold,
                fontSize = (15 * scaleSp).sp,
                letterSpacing = (4 * scaleSp).sp,
            )
        }
    }
}
