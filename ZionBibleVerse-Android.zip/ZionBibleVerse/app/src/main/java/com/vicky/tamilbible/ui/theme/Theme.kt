@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.vicky.tamilbible.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.ThemeMode

// Palette: cool slate paper, ink blue-black, bible-ribbon maroon, gilt-edge gold.
private val Paper = Color(0xFFF3F4F7)
private val Card = Color(0xFFFFFFFF)
private val Ink = Color(0xFF1B2233)
private val Muted = Color(0xFF5B6478)
private val Maroon = Color(0xFF8C1C2B)
private val Gold = Color(0xFF9A7424)
private val Line = Color(0xFFDADDE5)

private val NightPaper = Color(0xFF12151D)
private val NightCard = Color(0xFF1B1F2A)
private val NightInk = Color(0xFFE6E3DA)
private val NightMuted = Color(0xFF9AA1B2)
private val NightMaroon = Color(0xFFE07B88)
private val NightGold = Color(0xFFD9B25A)
private val NightLine = Color(0xFF2C3242)

private val LightScheme = lightColorScheme(
    primary = Maroon, onPrimary = Color.White,
    primaryContainer = Color(0xFFF5DDE0), onPrimaryContainer = Color(0xFF3E0710),
    secondary = Gold, onSecondary = Color.White,
    secondaryContainer = Color(0xFFF2E6C9), onSecondaryContainer = Color(0xFF3A2B05),
    background = Paper, onBackground = Ink,
    surface = Paper, onSurface = Ink,
    surfaceVariant = Card, onSurfaceVariant = Muted,
    surfaceContainer = Card, surfaceContainerHigh = Card, surfaceContainerLow = Card,
    outline = Line, outlineVariant = Line,
)

private val DarkScheme = darkColorScheme(
    primary = NightMaroon, onPrimary = Color(0xFF3E0710),
    primaryContainer = Color(0xFF4A1620), onPrimaryContainer = Color(0xFFF5DDE0),
    secondary = NightGold, onSecondary = Color(0xFF2A1F04),
    secondaryContainer = Color(0xFF3A2E12), onSecondaryContainer = Color(0xFFF2E6C9),
    background = NightPaper, onBackground = NightInk,
    surface = NightPaper, onSurface = NightInk,
    surfaceVariant = NightCard, onSurfaceVariant = NightMuted,
    surfaceContainer = NightCard, surfaceContainerHigh = NightCard, surfaceContainerLow = NightCard,
    outline = NightLine, outlineVariant = NightLine,
)

val TamilSerif = FontFamily(
    Font(R.font.noto_serif_tamil, FontWeight.Normal,
        variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.noto_serif_tamil, FontWeight.SemiBold,
        variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.noto_serif_tamil, FontWeight.Bold,
        variationSettings = FontVariation.Settings(FontVariation.weight(700))),
)

val EnglishSerif = FontFamily(
    Font(R.font.literata, FontWeight.Normal,
        variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.literata, FontWeight.SemiBold,
        variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.literata, FontWeight.Bold,
        variationSettings = FontVariation.Settings(FontVariation.weight(700))),
)

@Composable
fun isDark(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

@Composable
fun BibleTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content
    )
}
