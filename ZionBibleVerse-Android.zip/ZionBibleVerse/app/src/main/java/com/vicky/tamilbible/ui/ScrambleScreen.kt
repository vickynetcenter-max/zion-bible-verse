package com.vicky.tamilbible.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.DailyVerse
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private data class ScrambleRound(val ref: String, val words: List<String>)
private data class Chip(val id: Int, val word: String)

private const val SCRAMBLE_ROUNDS = 3

/** Promise verses with a word count that suits the level: 5 words at level 1 up to 15 at level 20. */
private suspend fun loadRounds(repo: BibleRepository, level: Int): List<ScrambleRound> {
    val maxW = 5 + level / 2
    val minW = (maxW - 4).coerceAtLeast(3)
    val out = mutableListOf<ScrambleRound>()
    val order = (0 until DailyVerse.size).shuffled()
    for (relax in 0..3) {
        for (i in order) {
            if (out.size >= SCRAMBLE_ROUNDS) return out
            val r = DailyVerse.refAt(i)
            val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: continue
            val words = v.ta.split(" ").filter { it.isNotBlank() }
            val ref = "${book.ta} ${r[1]}:${r[2]}"
            if (words.size in (minW - relax * 2)..(maxW + relax * 3) && out.none { it.ref == ref }) out += ScrambleRound(ref, words)
        }
    }
    return out
}

/** 🧩 வசன அடுக்கு — tap the jumbled words in the right order to build the verse. */
@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun ScrambleScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { BibleRepository(context) }
    val theme = GameThemes.SCRAMBLE
    var level by remember { mutableIntStateOf(0) }
    var attempt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { level = GameStore.progress(context, Games.SCRAMBLE).first().unlocked }

    GameScaffold("வசன அடுக்கு", theme, onBack) {
        if (level == 0) { CircularProgressIndicator(); return@GameScaffold }
        val rounds by produceState<List<ScrambleRound>?>(null, level, attempt) { value = null; value = loadRounds(repo, level) }
        val rs = rounds
        if (rs == null) { CircularProgressIndicator(); return@GameScaffold }

        var round by remember(rs) { mutableIntStateOf(0) }
        var placed by remember(rs) { mutableIntStateOf(0) }
        var mistakes by remember(rs) { mutableIntStateOf(0) }
        var finished by remember(rs) { mutableStateOf(false) }
        var started by remember(rs) { mutableStateOf(false) }
        var wrongId by remember(rs) { mutableIntStateOf(-1) }
        var wrongKey by remember(rs) { mutableIntStateOf(0) }
        val used = remember(rs, round) { mutableStateListOf<Int>() }
        val cur = rs.getOrNull(round)
        val chips = remember(rs, round) { cur?.words?.mapIndexed { i, w -> Chip(i, w) }?.shuffled() ?: emptyList() }
        val seconds = rememberGameSeconds(started && !finished, rs)
        val stars = when { mistakes == 0 -> 3; mistakes <= 3 -> 2; else -> 1 }

        LaunchedEffect(finished) { if (finished) GameStore.complete(context, Games.SCRAMBLE, level, stars) }
        // Round done → short pause, then the next verse.
        LaunchedEffect(placed, round) {
            if (cur != null && placed == cur.words.size) {
                delay(900)
                if (round + 1 < rs.size) { round++; placed = 0 } else finished = true
            }
        }

        LevelRow(level, Games.LEVELS) { Text("⏱ " + formatSeconds(seconds), fontWeight = FontWeight.SemiBold) }
        Row {
            Text("வசனம் ${(round + 1).coerceAtMost(rs.size)} / ${rs.size}", fontFamily = TamilFont, fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("❌ $mistakes", fontSize = 14.sp, color = if (mistakes > 0) GAME_RED else MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (finished) {
            LevelResult(true, stars, "அருமை! 🎉", "${rs.size} வசனங்கள் · ${formatSeconds(seconds)} · தவறுகள் $mistakes", theme,
                onNext = if (level < Games.LEVELS) ({ level += 1 }) else null, onRetry = { attempt++ })
            return@GameScaffold
        }
        cur ?: return@GameScaffold

        // Reference as a hint
        Surface(shape = RoundedCornerShape(12.dp), color = theme.start.copy(alpha = 0.1f)) {
            Text("📖 ${cur.ref}", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, color = theme.start,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
        }
        // The verse being built
        val done = placed == cur.words.size
        val boxColor by animateColorAsState(if (done) GAME_GREEN.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant, label = "box")
        Box(Modifier.fillMaxWidth().heightIn(min = 120.dp).clip(RoundedCornerShape(18.dp)).background(boxColor)
            .border(1.5.dp, if (done) GAME_GREEN else theme.start.copy(alpha = 0.3f), RoundedCornerShape(18.dp)).padding(14.dp)) {
            if (placed == 0) Text("வார்த்தைகளை வரிசையாகத் தொடுங்கள்…", fontFamily = TamilFont, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                cur.words.take(placed).forEach { w ->
                    Text(w, fontFamily = TamilFont, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                        color = if (done) GAME_GREEN else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        // Jumbled words
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()) {
            chips.filter { it.id !in used }.forEach { chip ->
                val wrong = chip.id == wrongId
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (wrong) GAME_RED.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    modifier = Modifier.then(if (wrong) Modifier.shake(wrongKey) else Modifier)
                        .border(1.5.dp, if (wrong) GAME_RED else theme.start.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = !done) {
                            started = true
                            // Same word may appear twice in a verse — any copy is right.
                            if (chip.word == cur.words[placed]) { used += chip.id; placed++; wrongId = -1 }
                            else { mistakes++; wrongId = chip.id; wrongKey++ }
                        },
                ) {
                    Text(chip.word, fontFamily = TamilFont, fontSize = 17.sp, color = if (wrong) GAME_RED else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                }
            }
        }
    }
}
