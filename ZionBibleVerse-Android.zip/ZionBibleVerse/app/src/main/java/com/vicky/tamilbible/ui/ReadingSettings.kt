package com.vicky.tamilbible.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.ThemeMode
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

/** Text size, theme (and optionally language) — used by the reader sheet and the Settings screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadingSettings(vm: BibleViewModel, showLanguage: Boolean) {
    val lang = vm.lang
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (showLanguage) {
            Text(lang.ui("மொழி", "Language"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            val langs = listOf(Lang.TA to "தமிழ்", Lang.EN to "English", Lang.BOTH to lang.ui("இரண்டும்", "Both"))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                langs.forEachIndexed { i, (l, label) ->
                    SegmentedButton(
                        selected = lang == l,
                        onClick = { vm.updateLang(l) },
                        shape = SegmentedButtonDefaults.itemShape(i, langs.size),
                    ) { Text(label, maxLines = 1, fontFamily = TamilFont) }
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        Text(lang.ui("எழுத்து அளவு", "Text size"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("அ", fontFamily = TamilFont, fontSize = 14.sp)
            Slider(
                value = vm.fontSize,
                onValueChange = vm::updateFontSize,
                valueRange = 14f..30f,
                steps = 7,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            )
            Text("அ", fontFamily = TamilFont, fontSize = 26.sp)
        }
        Text(
            if (lang == Lang.EN) "In the beginning God created the heaven and the earth."
            else "ஆதியிலே தேவன் வானத்தையும் பூமியையும் சிருஷ்டித்தார்.",
            fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
            fontSize = vm.fontSize.sp,
            lineHeight = (vm.fontSize * 1.7f).sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))

        Text(lang.ui("பின்னணி நிறம்", "Background"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        val themes = listOf(
            ThemeMode.LIGHT to lang.ui("வெள்ளை", "White"),
            ThemeMode.DARK to lang.ui("கருப்பு", "Black"),
            ThemeMode.SYSTEM to lang.ui("தானியங்கி", "Auto"),
        )
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            themes.forEachIndexed { i, (mode, label) ->
                SegmentedButton(
                    selected = vm.theme == mode,
                    onClick = { vm.updateTheme(mode) },
                    shape = SegmentedButtonDefaults.itemShape(i, themes.size),
                ) { Text(label, maxLines = 1, fontFamily = TamilFont) }
            }
        }
        Text(
            lang.ui(
                "வசனத்தைத் தொட்டு தேர்வு செய்யுங்கள் — நகலெடுக்கலாம் அல்லது பகிரலாம். அதிகாரம் மாற பக்கவாட்டில் இழுக்கவும்.",
                "Tap verses to select them for copying or sharing. Swipe sideways to change chapter.",
            ),
            fontSize = 13.sp, lineHeight = 20.sp, fontFamily = TamilFont,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
