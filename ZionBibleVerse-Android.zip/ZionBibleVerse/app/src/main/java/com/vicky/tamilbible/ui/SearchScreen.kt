package com.vicky.tamilbible.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.SearchHit
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay

private const val LIMIT = 300

@Composable
fun SearchScreen(
    vm: BibleViewModel,
    onClose: () -> Unit,
    onPick: (bookOrd: Int, chapter: Int, verse: Int?) -> Unit,
) {
    val lang = vm.lang
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SearchHit>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { focus.requestFocus() }

    LaunchedEffect(query, lang) {
        val q = query.trim()
        if (q.length < 2) { results = emptyList(); loading = false; return@LaunchedEffect }
        delay(300) // wait for typing to pause
        loading = true
        results = vm.search(q)
        loading = false
    }

    val ref = remember(query, vm.books) { vm.parseReference(query) }
    val booksByOrd = remember(vm.books) { vm.books.associateBy { it.ord } }

    Column(
        Modifier.fillMaxSize().pageBackground().statusBarsPadding().imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = lang.ui("பின்செல்", "Back"))
            }
            TextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f).focusRequester(focus),
                singleLine = true,
                placeholder = {
                    Text(lang.ui("வார்த்தை அல்லது வசனக் குறிப்பு", "Word or reference, e.g. John 3:16"))
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = lang.ui("அழி", "Clear"))
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = MaterialTheme.colorScheme.primary,
                ),
            )
        }
        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.primary)
        } else {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        }

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                Modifier.widthIn(max = 680.dp).fillMaxHeight(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            ) {
                if (query.isBlank()) {
                    item { SearchHints(lang) }
                }
                if (ref != null) {
                    item(key = "ref") {
                        val label = buildString {
                            append(ref.book.displayName(lang)); append(" "); append(ref.chapter)
                            ref.verse?.let { append(":"); append(it) }
                        }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary)
                                .clickable { onPick(ref.book.ord, ref.chapter, ref.verse) }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    lang.ui("இங்கே செல்", "Go to"),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                                )
                                Text(
                                    label,
                                    fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                        }
                    }
                }
                if (query.trim().length >= 2 && !loading && !(ref != null && results.isEmpty())) {
                    item(key = "count") {
                        Text(
                            when {
                                results.isEmpty() -> lang.ui(
                                    "பொருந்தும் வசனம் இல்லை. வேறு சொல்லை முயற்சிக்கவும் அல்லது மொழியை மாற்றவும்.",
                                    "No verses contain that. Try another word, or switch the reading language."
                                )
                                results.size >= LIMIT -> lang.ui("முதல் $LIMIT வசனங்கள்", "First $LIMIT verses")
                                else -> lang.ui("${results.size} வசனங்கள்", "${results.size} verses")
                            },
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                        )
                    }
                }
                items(results, key = { "${it.book}-${it.chapter}-${it.verse}" }) { hit ->
                    val book = booksByOrd[hit.book] ?: return@items
                    ResultRow(
                        reference = "${book.displayName(lang)} ${hit.chapter}:${hit.verse}",
                        hit = hit,
                        lang = lang,
                        term = query,
                        onClick = { onPick(hit.book, hit.chapter, hit.verse) },
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                }
                item { Box(Modifier.navigationBarsPadding()) }
            }
        }
    }
}

@Composable
private fun SearchHints(lang: Lang) {
    Column(Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
        Text(
            lang.ui("இவ்வாறு தேடலாம்", "Try searching"),
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
        )
        val examples = if (lang == Lang.EN)
            listOf("love", "John 3:16", "Psalms 23", "shepherd")
        else
            listOf("அன்பு", "யோவான் 3:16", "சங்கீதம் 23", "மேய்ப்பர்")
        examples.forEach {
            Text(
                it,
                fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        Text(
            lang.ui(
                "தேடல் தற்போதைய வாசிப்பு மொழியில் நடக்கும்; \"இரண்டும்\" தேர்வில் இரண்டு மொழிகளிலும் தேடும்.",
                "Search uses the current reading language; \"Both\" searches Tamil and English."
            ),
            fontSize = 13.sp,
            lineHeight = 19.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 16.dp),
        )
    }
}

@Composable
private fun ResultRow(reference: String, hit: SearchHit, lang: Lang, term: String, onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp)
    ) {
        Text(
            reference,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.secondary,
        )
        if (lang != Lang.EN) {
            Text(
                highlight(hit.ta, term, accent),
                fontFamily = TamilFont, fontSize = 16.sp, lineHeight = 26.sp,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        if (lang != Lang.TA) {
            Text(
                highlight(hit.en, term, accent),
                fontFamily = EnglishSerif,
                fontSize = if (lang == Lang.BOTH) 14.sp else 16.sp,
                lineHeight = if (lang == Lang.BOTH) 21.sp else 25.sp,
                color = if (lang == Lang.BOTH) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
