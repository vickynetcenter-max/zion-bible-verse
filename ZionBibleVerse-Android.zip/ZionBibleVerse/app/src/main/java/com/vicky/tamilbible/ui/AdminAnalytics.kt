package com.vicky.tamilbible.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.AnalyticsData
import com.vicky.tamilbible.data.Announcement
import com.vicky.tamilbible.ui.theme.TamilFont

private val A_NAVY = Color(0xFF1C2951)
private val A_MAROON = Color(0xFF8C1C2B)
private val A_GREEN = Color(0xFF2E7D32)
private val A_BLUE = Color(0xFF1E88E5)
private val A_ORANGE = Color(0xFFF26A1B)

/** 📊 Analytics: installs, active users, a 14-day chart, app versions and reach of each post. */
@Composable
internal fun AdminAnalytics(stats: AnalyticsData?, announcements: List<Announcement>, loading: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("📊 App பயன்பாடு", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (stats == null) {
            if (loading) CircularProgressIndicator()
            else Text("தகவல் கிடைக்கவில்லை — internet அல்லது script-ஐச் சரிபாருங்கள்", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error)
            return@Column
        }
        // Big numbers
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigStat("📦", "${stats.installs}", "மொத்த install", A_NAVY, Modifier.weight(1f))
            BigStat("🟢", "${stats.today}", "இன்று active", A_GREEN, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigStat("📅", "${stats.week}", "7 நாள் active", A_BLUE, Modifier.weight(1f))
            BigStat("🗓", "${stats.month}", "30 நாள் active", A_MAROON, Modifier.weight(1f))
        }

        // 14-day chart
        Card {
            Text("கடந்த 14 நாட்கள் · தினசரி active பயனர்கள்", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            DailyChart(stats)
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(A_GREEN)); Spacer(Modifier.width(4.dp))
                Text("active", fontSize = 11.sp); Spacer(Modifier.width(12.dp))
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(A_ORANGE)); Spacer(Modifier.width(4.dp))
                Text("புதிய install", fontSize = 11.sp, fontFamily = TamilFont)
            }
        }

        // App versions — who has updated
        if (stats.versions.isNotEmpty()) Card {
            Text("App version வாரியாக", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            val total = stats.versions.values.sum().coerceAtLeast(1)
            stats.versions.entries.sortedByDescending { it.key }.forEach { (v, n) ->
                BarLine("v$v", n, n.toFloat() / total, A_NAVY, "${n * 100 / total}%")
            }
        }

        // Reach of each announcement
        Card {
            Text("📢 அறிவிப்புகளின் reach", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("📩 சேர்ந்தது = அந்த phone-ல் அறிவிப்பு வந்தது · 👁 பார்த்தது = app-ல் திறந்து பார்த்தனர்",
                fontFamily = TamilFont, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            val posts = announcements.filter { !it.isScheduled }.sortedByDescending { it.publishAt }.take(15)
            if (posts.isEmpty()) Text("இன்னும் அறிவிப்புகள் இல்லை", fontFamily = TamilFont, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val base = stats.installs.coerceAtLeast(1)
            posts.forEach { a ->
                val r = stats.reach[a.id]
                val got = r?.received ?: 0; val seen = r?.opened ?: 0
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(a.title.ifBlank { a.message.take(40) }.ifBlank { "📷 படம்" }, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp, maxLines = 1)
                    Text(formatDate(a.publishAt), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    BarLine("📩", got, got.toFloat() / base, A_BLUE, "$got பேர்")
                    BarLine("👁", seen, seen.toFloat() / base, A_GREEN, "$seen பேர்")
                }
            }
            Text("சதவீதம் மொத்த install எண்ணிக்கையை (${stats.installs}) வைத்துக் கணக்கிடப்படுகிறது", fontFamily = TamilFont,
                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("எண்ணிக்கைகள் அநாமதேயமானவை — யார் என்று தெரியாது, எத்தனை பேர் என்று மட்டும்.", fontFamily = TamilFont,
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) { content() }
    }
}

@Composable
private fun BigStat(icon: String, value: String, label: String, color: Color, modifier: Modifier) {
    Surface(shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Box(Modifier.background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.75f)))).padding(14.dp)) {
            Column {
                Text(icon, fontSize = 18.sp)
                Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
                Text(label, color = Color.White.copy(alpha = 0.9f), fontFamily = TamilFont, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun BarLine(label: String, value: Int, fraction: Float, color: Color, right: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, modifier = Modifier.width(52.dp), maxLines = 1)
        Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(color.copy(alpha = 0.12f))) {
            Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(12.dp).clip(RoundedCornerShape(6.dp)).background(color))
        }
        Text(right, fontSize = 12.sp, fontFamily = TamilFont, modifier = Modifier.padding(start = 8.dp).width(64.dp), maxLines = 1)
    }
}

@Composable
private fun DailyChart(stats: AnalyticsData) {
    val measurer = rememberTextMeasurer()
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val days = stats.daily
        if (days.isEmpty()) return@Canvas
        val max = (days.maxOf { maxOf(it.active, it.installs) }).coerceAtLeast(1)
        val bottom = size.height - 22f
        val slot = size.width / days.size
        val bw = slot * 0.36f
        days.forEachIndexed { i, d ->
            val x = i * slot + slot * 0.12f
            val ha = bottom * d.active / max
            val hi = bottom * d.installs / max
            drawRoundRect(A_GREEN, Offset(x, bottom - ha), Size(bw, ha), CornerRadius(5f))
            drawRoundRect(A_ORANGE, Offset(x + bw + 2f, bottom - hi), Size(bw * 0.7f, hi), CornerRadius(5f))
            if (d.active > 0) {
                val t = measurer.measure("${d.active}", TextStyle(fontSize = 9.sp, color = labelColor))
                drawText(t, topLeft = Offset(x + bw / 2 - t.size.width / 2f, (bottom - ha - t.size.height).coerceAtLeast(0f)))
            }
            if (i % 2 == 1 || i == days.size - 1) {
                val label = d.day.takeLast(5).replace('-', '/').let { "${it.substring(3)}/${it.substring(0, 2)}" }
                val t = measurer.measure(label, TextStyle(fontSize = 9.sp, color = labelColor))
                drawText(t, topLeft = Offset(x + bw - t.size.width / 2f, bottom + 6f))
            }
        }
    }
}
