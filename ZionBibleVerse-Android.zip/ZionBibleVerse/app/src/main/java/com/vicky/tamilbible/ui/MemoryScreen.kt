package com.vicky.tamilbible.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.games.MemoryPairs
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private data class MemCard(val id: Int, val pair: Int, val text: String)

/** 🃏 ஜோடி பொருத்து — flip two cards at a time and find each person's pair. */
@Composable
fun MemoryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val theme = GameThemes.MEMORY
    var level by remember { mutableIntStateOf(0) }
    var attempt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { level = GameStore.progress(context, Games.MEMORY).first().unlocked }

    GameScaffold("ஜோடி பொருத்து", theme, onBack) {
        if (level == 0) { CircularProgressIndicator(); return@GameScaffold }
        val pairs = MemoryPairs.pairsFor(level)
        val cards = remember(level, attempt) {
            MemoryPairs.ALL.shuffled().take(pairs).flatMapIndexed { i, p -> listOf(MemCard(i * 2, i, p.a), MemCard(i * 2 + 1, i, p.b)) }.shuffled()
        }
        val open = remember(level, attempt) { mutableStateListOf<Int>() }       // face-up, not yet matched
        val matched = remember(level, attempt) { mutableStateListOf<Int>() }
        var moves by remember(level, attempt) { mutableIntStateOf(0) }
        var started by remember(level, attempt) { mutableStateOf(false) }
        val finished = matched.size == cards.size
        val seconds = rememberGameSeconds(started && !finished, "$level-$attempt")
        val stars = when { moves <= pairs * 1.6 -> 3; moves <= pairs * 2.3 -> 2; else -> 1 }

        LaunchedEffect(finished) { if (finished) GameStore.complete(context, Games.MEMORY, level, stars) }
        // Two cards up: keep them if they match, otherwise flip back.
        LaunchedEffect(open.toList()) {
            if (open.size == 2) {
                val (a, b) = open.map { id -> cards.first { it.id == id } }
                if (a.pair == b.pair) { delay(350); matched += a.id; matched += b.id; open.clear() }
                else { delay(850); open.clear() }
            }
        }

        LevelRow(level, Games.LEVELS) { Text("⏱ " + formatSeconds(seconds), fontWeight = FontWeight.SemiBold) }
        Row {
            Text("$pairs ஜோடிகள் · நகர்வுகள் $moves", fontFamily = TamilFont, fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("✓ ${matched.size / 2}", color = GAME_GREEN, fontWeight = FontWeight.Bold)
        }

        if (finished) {
            LevelResult(true, stars, "எல்லா ஜோடிகளும் கிடைத்தன! 🎉", "நகர்வுகள் $moves · ${formatSeconds(seconds)}", theme,
                onNext = if (level < Games.LEVELS) ({ level += 1 }) else null, onRetry = { attempt++ })
            return@GameScaffold
        }

        val cols = if (cards.size <= 12) 3 else 4
        cards.chunked(cols).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { card ->
                    val up = card.id in open || card.id in matched
                    MemoryCardView(card.text, up, card.id in matched, theme, Modifier.weight(1f).height(if (cols == 3) 96.dp else 84.dp)) {
                        if (!up && open.size < 2) { started = true; open += card.id; if (open.size == 2) moves++ }
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun MemoryCardView(text: String, faceUp: Boolean, matched: Boolean, theme: GameTheme, modifier: Modifier, onClick: () -> Unit) {
    val rot by animateFloatAsState(if (faceUp) 180f else 0f, tween(320), label = "flip")
    Box(
        modifier.graphicsLayer { rotationY = rot; cameraDistance = 14f * density }
            .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
    ) {
        if (rot <= 90f) {
            // Back of the card
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(theme.start, theme.end))), contentAlignment = Alignment.Center) {
                Text("✝", color = Color.White.copy(alpha = 0.85f), fontSize = 28.sp)
            }
        } else {
            Box(
                Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }
                    .background(if (matched) GAME_GREEN.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface)
                    .border(2.dp, if (matched) GAME_GREEN else theme.start.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 17.sp,
                    textAlign = TextAlign.Center, color = if (matched) GAME_GREEN else MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}
