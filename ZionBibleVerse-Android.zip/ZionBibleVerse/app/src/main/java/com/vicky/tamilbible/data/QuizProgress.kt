package com.vicky.tamilbible.data

import android.content.Context

/** Quiz progress on this phone: best score and stars per level, highest unlocked level, prizes opened. */
class QuizProgress(context: Context) {
    private val p = context.getSharedPreferences("quiz", Context.MODE_PRIVATE)
    // Kept separately so resetting scores doesn't bring old questions back.
    private val seenPrefs = context.getSharedPreferences("quiz_seen", Context.MODE_PRIVATE)

    fun seen(): MutableSet<String> = seenPrefs.getStringSet("keys", emptySet())!!.toMutableSet()
    fun saveSeen(keys: Set<String>) = seenPrefs.edit().putStringSet("keys", HashSet(keys)).apply()
    fun best(level: Int) = p.getInt("best_$level", 0)
    fun stars(level: Int) = p.getInt("stars_$level", 0)
    fun unlocked() = p.getInt("unlocked", 1)
    fun prizeOpened(level: Int) = p.getBoolean("prize_$level", false)
    fun total() = (1..QuizEngine.LEVELS).sumOf { best(it) }
    fun totalStars() = (1..QuizEngine.LEVELS).sumOf { stars(it) }

    /** Saves a finished level. Returns (new best?, next level newly unlocked?). */
    fun record(level: Int, score: Int, correct: Int): Pair<Boolean, Boolean> {
        val newBest = score > best(level)
        val e = p.edit()
        if (newBest) e.putInt("best_$level", score)
        val s = QuizEngine.stars(correct)
        if (s > stars(level)) e.putInt("stars_$level", s)
        var unlockedNew = false
        if (correct >= QuizEngine.PASS && level == unlocked() && level < QuizEngine.LEVELS) {
            e.putInt("unlocked", level + 1); unlockedNew = true
        }
        e.apply()
        return newBest to unlockedNew
    }

    fun openPrize(level: Int) = p.edit().putBoolean("prize_$level", true).apply()
    fun reset() = p.edit().clear().apply()
}
