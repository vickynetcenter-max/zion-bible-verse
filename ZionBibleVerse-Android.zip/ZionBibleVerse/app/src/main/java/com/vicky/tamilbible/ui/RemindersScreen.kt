package com.vicky.tamilbible.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.ChurchEvents
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.notify.EventReminders
import com.vicky.tamilbible.ui.theme.TamilFont
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TA_DAY = mapOf(
    DayOfWeek.SUNDAY to "ஞாயிறு", DayOfWeek.MONDAY to "திங்கள்", DayOfWeek.TUESDAY to "செவ்வாய்",
    DayOfWeek.WEDNESDAY to "புதன்", DayOfWeek.THURSDAY to "வியாழன்", DayOfWeek.FRIDAY to "வெள்ளி",
    DayOfWeek.SATURDAY to "சனி",
)
private val WEEK = listOf(DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
    DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY)

/** Church programmes section (weekly services), shown under the calendar when the church has listed any. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChurchProgrammes(lang: Lang) {
    val context = LocalContext.current
    val events = remember { ChurchEvents.load(context) }
    val on = remember { mutableStateMapOf<String, Boolean>().apply { events.forEach { put(it.id, EventReminders.isOn(context, it)) } } }
    if (events.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(lang.ui("சபை நிகழ்ச்சிகள்", "Church programmes"), fontFamily = TamilFont,
            fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
        events.forEach { e ->
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(e.title, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        val days = if (e.days.size == 7) lang.ui("தினமும்", "Daily")
                        else WEEK.filter { it in e.days }.joinToString(", ") {
                            if (lang == Lang.EN) it.name.lowercase().replaceFirstChar { c -> c.uppercase() }.take(3) else TA_DAY[it]!!
                        }
                        Text("$days · ${e.time.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))}",
                            fontFamily = TamilFont, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Switch(checked = on[e.id] == true, onCheckedChange = {
                        on[e.id] = it
                        EventReminders.setOn(context, e, it)
                    })
                }
            }
        }
    }
}
