package com.vicky.tamilbible.data

import kotlin.math.abs
import kotlin.random.Random

/** One multiple-choice question; [answer] is the index of the correct option. */
data class Question(val text: String, val verse: String?, val options: List<String>, val answer: Int, val ref: String?)

/**
 * Builds a fresh, random set of 10 questions for a level. Questions come from the curated
 * [QuizBank] and are generated from the Bible database. Wrong options are chosen to be
 * close to the right one (books from the same section, nearby chapters and verse numbers,
 * words from the same chapter, the verses around the right one), so the quiz stays
 * challenging even for people who know the Bible. Every player and every attempt differs,
 * and a question already asked on this phone is not asked again until its pool runs out.
 */
class QuizEngine(
    private val repo: BibleRepository,
    private val books: List<Book>,
    /** Keys of questions this phone has already been asked; kept across plays so nothing repeats. */
    val seen: MutableSet<String> = mutableSetOf(),
) {
    private val rnd = Random(System.nanoTime())
    private val byOrd = books.associateBy { it.ord }

    companion object {
        const val LEVELS = 20
        const val PER_LEVEL = 10
        const val PASS = 7
        fun seconds(level: Int) = when { level <= 7 -> 30; level <= 14 -> 25; else -> 22 }
        fun stars(correct: Int) = when { correct >= 10 -> 3; correct >= 9 -> 2; correct >= PASS -> 1; else -> 0 }

        /** Sections of the Bible, used to pick convincing wrong books. */
        private val SECTIONS = listOf(1..5, 6..17, 18..22, 23..27, 28..39, 40..43, 44..44, 45..57, 58..65, 66..66)
        fun section(ord: Int) = SECTIONS.indexOfFirst { ord in it }
    }

    private enum class T {
        FACT, BOOK_POSITION, CHAPTERS, FAMOUS_BOOK, FAMOUS_WORD, FAMOUS_CHAPTER, FAMOUS_REF, FAMOUS_NEXT,
        ANY_BOOK, ANY_WORD, ANY_REF, ANY_NEXT,
    }

    private fun plan(level: Int): List<T> = when (level) {
        in 1..3 -> List(3) { T.FACT } + List(3) { T.FAMOUS_BOOK } + List(2) { T.CHAPTERS } + List(2) { T.BOOK_POSITION }
        in 4..6 -> List(2) { T.FACT } + List(2) { T.FAMOUS_BOOK } + List(3) { T.FAMOUS_WORD } + List(3) { T.FAMOUS_CHAPTER }
        in 7..10 -> List(2) { T.FACT } + List(3) { T.FAMOUS_REF } + List(2) { T.FAMOUS_WORD } + List(3) { T.FAMOUS_NEXT }
        in 11..14 -> List(2) { T.FACT } + List(3) { T.ANY_BOOK } + List(2) { T.ANY_WORD } + List(3) { T.FAMOUS_REF }
        in 15..17 -> List(1) { T.FACT } + List(3) { T.ANY_REF } + List(3) { T.ANY_NEXT } + List(3) { T.ANY_WORD }
        else -> List(1) { T.FACT } + List(3) { T.ANY_REF } + List(3) { T.ANY_NEXT } + List(3) { T.ANY_WORD }
    }

    private fun factLevels(level: Int) = when { level <= 5 -> setOf(2, 3); level <= 12 -> setOf(3, 4); else -> setOf(4, 3) }

    suspend fun build(level: Int): List<Question> {
        val lv = factLevels(level)
        // Curated facts not asked before (start over only when every one has been used).
        var factPool = QuizBank.FACTS.filter { it.level in lv && "F:${it.q}" !in seen }
        if (factPool.size < 3) {
            seen.removeAll { it.startsWith("F:") }
            factPool = QuizBank.FACTS.filter { it.level in lv }
        }
        val facts = factPool.shuffled(rnd).toMutableList()
        // Well-known verses not used before.
        var famousPool = (0 until DailyVerse.size).filter { "V:$it" !in seen }
        if (famousPool.size < 10) { seen.removeAll { it.startsWith("V:") }; famousPool = (0 until DailyVerse.size).toList() }
        val famous = famousPool.shuffled(rnd).toMutableList()
        fun nextFamous() = famous.removeFirstOrNull()?.let { seen += "V:$it"; DailyVerse.refAt(it) }
        suspend fun nextAny(): IntArray? {
            repeat(6) {
                val h = repo.randomVerses(1).firstOrNull() ?: return null
                val key = "A:${h.book}:${h.chapter}:${h.verse}"
                if (key !in seen) { seen += key; return intArrayOf(h.book, h.chapter, h.verse) }
            }
            return null
        }
        val out = mutableListOf<Question>()
        for (t in plan(level).shuffled(rnd)) {
            val q = runCatching {
                when (t) {
                    T.FACT -> facts.removeFirstOrNull()?.let { seen += "F:${it.q}"; fact(it) }
                    T.BOOK_POSITION -> bookPosition()
                    T.CHAPTERS -> chapters()
                    T.FAMOUS_BOOK -> nextFamous()?.let { whichBook(it) }
                    T.FAMOUS_WORD -> nextFamous()?.let { fillWord(it) }
                    T.FAMOUS_CHAPTER -> nextFamous()?.let { whichChapter(it) }
                    T.FAMOUS_REF -> nextFamous()?.let { exactRef(it) }
                    T.FAMOUS_NEXT -> nextFamous()?.let { nextVerse(it) }
                    T.ANY_BOOK -> nextAny()?.let { whichBook(it) }
                    T.ANY_WORD -> nextAny()?.let { fillWord(it) }
                    T.ANY_REF -> nextAny()?.let { exactRef(it) }
                    T.ANY_NEXT -> nextAny()?.let { nextVerse(it) }
                }
            }.getOrNull()
            // Fallback if a generator had nothing suitable; never the same question twice in a level.
            val final = q?.takeIf { n -> out.none { it.text == n.text && it.verse == n.verse && it.options == n.options } } ?: chapters()
            out += final
        }
        return out
    }

    // ---- helpers ------------------------------------------------------------------------

    private fun mcq(text: String, verse: String?, correct: String, wrong: List<String>, ref: String?): Question {
        val opts = (listOf(correct) + wrong.filter { it != correct }.distinct().take(3)).shuffled(rnd)
        return Question(text, verse, opts, opts.indexOf(correct), ref)
    }

    private fun fact(f: QuizFact) = mcq(f.q, null, f.options[0], f.options.drop(1), f.ref)

    /** Books from the same section first, then neighbouring sections — hard to tell apart. */
    private fun nearBooks(b: Book): List<Book> {
        val sec = section(b.ord)
        val same = books.filter { it.ord != b.ord && section(it.ord) == sec }.shuffled(rnd)
        val near = books.filter { it.ord != b.ord && abs(section(it.ord) - sec) == 1 }.shuffled(rnd)
        return same + near
    }

    private fun closeNumbers(n: Int, min: Int, max: Int, spread: Int = 3): List<String> =
        ((n - spread)..(n + spread)).filter { it in min..max && it != n }.shuffled(rnd).take(3).map { it.toString() }

    /** A book not yet used for this kind of question ([tag]); starts over when all are used. */
    private fun freshBook(tag: String, filter: (Book) -> Boolean = { true }): Book {
        var pool = books.filter { filter(it) && "$tag:${it.ord}" !in seen }
        if (pool.isEmpty()) { seen.removeAll { it.startsWith("$tag:") }; pool = books.filter(filter) }
        return pool.random(rnd).also { seen += "$tag:${it.ord}" }
    }

    private fun bookPosition(): Question {
        val b = freshBook("P")
        return mcq("“${b.ta}” வேதாகமத்தில் எத்தனையாவது புத்தகம்?", null, b.ord.toString(), closeNumbers(b.ord, 1, 66), null)
    }

    private fun chapters(): Question {
        val b = freshBook("C") { it.chapters >= 5 }
        return mcq("“${b.ta}” புத்தகத்தில் எத்தனை அதிகாரங்கள் உள்ளன?", null, b.chapters.toString(),
            closeNumbers(b.chapters, 1, 150, 3), b.ta)
    }

    private suspend fun whichBook(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        return mcq("இந்த வசனம் எந்தப் புத்தகத்தில் உள்ளது?", v.ta, book.ta, nearBooks(book).map { it.ta },
            "${book.ta} ${r[1]}:${r[2]}")
    }

    private suspend fun whichChapter(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        if (book.chapters < 4) return whichBook(r)
        return mcq("இந்த வசனம் “${book.ta}” புத்தகத்தின் எந்த அதிகாரத்தில் உள்ளது?", v.ta, r[1].toString(),
            closeNumbers(r[1], 1, book.chapters, 4), "${book.ta} ${r[1]}:${r[2]}")
    }

    /** Exact reference, with near-miss options: next verse, next chapter, a sister book. */
    private suspend fun exactRef(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        val right = "${book.ta} ${r[1]}:${r[2]}"
        val cands = mutableListOf<String>()
        suspend fun add(b: Int, c: Int, vv: Int) {
            if (c < 1 || vv < 1) return
            repo.verseWithBook(b, c, vv)?.let { cands += "${it.first.ta} $c:$vv" }
        }
        add(r[0], r[1], r[2] + 1); add(r[0], r[1], r[2] - 1)
        add(r[0], r[1] + 1, r[2]); add(r[0], r[1] - 1, r[2])
        nearBooks(book).take(4).forEach { add(it.ord, r[1], r[2]) }
        if (cands.size < 3) return whichChapter(r)
        return mcq("இந்த வசனத்தின் சரியான இடம் எது?", v.ta, right, cands.shuffled(rnd), right)
    }

    /** Which verse comes right after this one? Wrong options are other verses of the same chapter. */
    private suspend fun nextVerse(r: IntArray): Question? {
        val chapter = repo.chapter(r[0], r[1])
        val cur = chapter.firstOrNull { it.num == r[2] } ?: return null
        val next = chapter.firstOrNull { it.num == r[2] + 1 } ?: return exactRef(r)
        val others = chapter.filter { it.num != cur.num && it.num != next.num }.shuffled(rnd).map { it.ta }
        if (others.size < 3) return exactRef(r)
        val book = byOrd[r[0]]?.ta ?: ""
        return mcq("இந்த வசனத்துக்கு அடுத்து வரும் வசனம் எது?", cur.ta, next.ta, others, "$book ${r[1]}:${r[2] + 1}")
    }

    private fun clean(w: String) = w.trim { !it.isLetter() && it.code !in 0x0B80..0x0BFF }

    /** Missing word; wrong options are real words of similar length from the same chapter. */
    private suspend fun fillWord(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        val words = v.ta.split(" ").filter { it.isNotBlank() }
        val candidates = words.indices.filter { clean(words[it]).length >= 4 }
        if (candidates.isEmpty()) return whichBook(r)
        val i = candidates.random(rnd)
        val answer = clean(words[i])
        val blanked = words.mapIndexed { j, w -> if (j == i) w.replace(answer, "______") else w }.joinToString(" ")
        var pool = repo.chapter(r[0], r[1]).filter { it.num != r[2] }.flatMap { it.ta.split(" ") }.map(::clean)
            .filter { it.length >= 3 && it != answer && abs(it.length - answer.length) <= 2 }.distinct().shuffled(rnd)
        if (pool.size < 3) {
            pool = pool + repo.randomVerses(6).flatMap { it.ta.split(" ") }.map(::clean)
                .filter { it.length >= 3 && it != answer && abs(it.length - answer.length) <= 3 }.distinct()
        }
        if (pool.size < 3) return whichBook(r)
        return mcq("விடுபட்ட வார்த்தை எது?", blanked, answer, pool, "${book.ta} ${r[1]}:${r[2]}")
    }
}
