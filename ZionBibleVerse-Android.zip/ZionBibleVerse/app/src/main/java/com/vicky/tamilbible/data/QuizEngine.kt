package com.vicky.tamilbible.data

import kotlin.random.Random

/** One multiple-choice question; [answer] is the index of the correct option. */
data class Question(val text: String, val verse: String?, val options: List<String>, val answer: Int, val ref: String?)

/**
 * Builds a fresh, random set of 10 questions for a level. Questions come from the curated
 * [QuizBank] and are also generated straight from the Bible database (which book, which
 * chapter, fill the missing word, book order, chapter counts), so every player — and every
 * attempt — gets a different quiz. Difficulty rises with the level.
 */
class QuizEngine(private val repo: BibleRepository, private val books: List<Book>) {
    private val rnd = Random(System.nanoTime())
    private val byOrd = books.associateBy { it.ord }

    companion object {
        const val LEVELS = 15
        const val PER_LEVEL = 10
        const val PASS = 7
        fun seconds(level: Int) = when { level <= 5 -> 30; level <= 10 -> 25; else -> 20 }
        fun stars(correct: Int) = when { correct >= 10 -> 3; correct >= 9 -> 2; correct >= PASS -> 1; else -> 0 }
    }

    private enum class T { FACT, NEXT_BOOK, TESTAMENT, CHAPTERS, FAMOUS_BOOK, FAMOUS_WORD, FAMOUS_CHAPTER, ANY_BOOK, ANY_WORD }

    /** Which question types make up each level (10 slots). */
    private fun plan(level: Int): List<T> = when (level) {
        1 -> List(5) { T.FACT } + List(3) { T.TESTAMENT } + List(2) { T.NEXT_BOOK }
        2 -> List(4) { T.FACT } + List(3) { T.NEXT_BOOK } + List(3) { T.TESTAMENT }
        3 -> List(4) { T.FACT } + List(3) { T.NEXT_BOOK } + List(3) { T.CHAPTERS }
        4 -> List(3) { T.FACT } + List(4) { T.FAMOUS_BOOK } + List(3) { T.CHAPTERS }
        5 -> List(3) { T.FACT } + List(5) { T.FAMOUS_BOOK } + List(2) { T.NEXT_BOOK }
        6 -> List(3) { T.FACT } + List(4) { T.FAMOUS_BOOK } + List(3) { T.FAMOUS_WORD }
        7 -> List(2) { T.FACT } + List(5) { T.FAMOUS_WORD } + List(3) { T.FAMOUS_BOOK }
        8 -> List(2) { T.FACT } + List(4) { T.FAMOUS_WORD } + List(4) { T.FAMOUS_CHAPTER }
        9 -> List(2) { T.FACT } + List(3) { T.FAMOUS_WORD } + List(5) { T.FAMOUS_CHAPTER }
        10 -> List(2) { T.FACT } + List(4) { T.FAMOUS_CHAPTER } + List(4) { T.ANY_BOOK }
        11 -> List(2) { T.FACT } + List(4) { T.ANY_BOOK } + List(4) { T.FAMOUS_WORD }
        12 -> List(1) { T.FACT } + List(5) { T.ANY_BOOK } + List(4) { T.ANY_WORD }
        13 -> List(1) { T.FACT } + List(4) { T.ANY_BOOK } + List(5) { T.ANY_WORD }
        14 -> List(5) { T.ANY_BOOK } + List(3) { T.ANY_WORD } + List(2) { T.FAMOUS_CHAPTER }
        else -> List(4) { T.ANY_BOOK } + List(4) { T.ANY_WORD } + List(2) { T.FAMOUS_CHAPTER }
    }

    private fun factLevel(level: Int) = when { level <= 3 -> 1; level <= 8 -> 2; else -> 3 }

    suspend fun build(level: Int): List<Question> {
        val facts = QuizBank.FACTS.filter { it.level == factLevel(level) }.shuffled(rnd).toMutableList()
        val famous = (0 until DailyVerse.size).shuffled(rnd).toMutableList()
        val out = mutableListOf<Question>()
        for (t in plan(level).shuffled(rnd)) {
            val q = runCatching {
                when (t) {
                    T.FACT -> facts.removeFirstOrNull()?.let { fact(it) }
                    T.NEXT_BOOK -> nextBook()
                    T.TESTAMENT -> testament()
                    T.CHAPTERS -> chapters()
                    T.FAMOUS_BOOK -> famous.removeFirstOrNull()?.let { whichBook(DailyVerse.refAt(it)) }
                    T.FAMOUS_WORD -> famous.removeFirstOrNull()?.let { fillWord(DailyVerse.refAt(it)) }
                    T.FAMOUS_CHAPTER -> famous.removeFirstOrNull()?.let { whichChapter(DailyVerse.refAt(it)) }
                    T.ANY_BOOK -> repo.randomVerses(1).firstOrNull()?.let { whichBook(intArrayOf(it.book, it.chapter, it.verse)) }
                    T.ANY_WORD -> repo.randomVerses(1).firstOrNull()?.let { fillWord(intArrayOf(it.book, it.chapter, it.verse)) }
                }
            }.getOrNull()
            out += q ?: nextBook()   // fall back to a simple question if a generator had nothing to use
        }
        return out
    }

    // ---- helpers ------------------------------------------------------------------------

    private fun mcq(text: String, verse: String?, correct: String, wrong: List<String>, ref: String?): Question {
        val opts = (listOf(correct) + wrong.filter { it != correct }.distinct().take(3)).shuffled(rnd)
        return Question(text, verse, opts, opts.indexOf(correct), ref)
    }

    private fun fact(f: QuizFact) = mcq(f.q, null, f.options[0], f.options.drop(1), f.ref)

    private fun nextBook(): Question {
        val b = books.filter { it.ord < 66 }.random(rnd)
        val next = byOrd.getValue(b.ord + 1)
        val wrong = books.filter { it.ord != next.ord && it.ord != b.ord && kotlin.math.abs(it.ord - b.ord) <= 6 }
            .shuffled(rnd).map { it.ta }
        return mcq("“${b.ta}” புத்தகத்துக்கு அடுத்து வரும் புத்தகம் எது?", null, next.ta, wrong, null)
    }

    private fun testament(): Question {
        val b = books.random(rnd)
        val ot = "பழைய ஏற்பாடு"; val nt = "புதிய ஏற்பாடு"
        val correct = if (b.testament == "OT") ot else nt
        val opts = listOf(ot, nt)
        return Question("“${b.ta}” எந்த ஏற்பாட்டில் உள்ளது?", null, opts, opts.indexOf(correct), null)
    }

    private fun chapters(): Question {
        val b = books.filter { it.chapters >= 4 }.random(rnd)
        val c = b.chapters
        val wrong = ((c - 6)..(c + 6)).filter { it >= 1 && it != c }.shuffled(rnd).take(3).map { it.toString() }
        return mcq("“${b.ta}” புத்தகத்தில் எத்தனை அதிகாரங்கள் உள்ளன?", null, c.toString(), wrong, b.ta)
    }

    private suspend fun whichBook(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        val wrong = books.filter { it.testament == book.testament && it.ord != book.ord }.shuffled(rnd).map { it.ta }
        return mcq("இந்த வசனம் எந்தப் புத்தகத்தில் உள்ளது?", v.ta, book.ta, wrong, "${book.ta} ${r[1]}:${r[2]}")
    }

    private suspend fun whichChapter(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        if (book.chapters < 4) return whichBook(r)
        val wrong = (1..book.chapters).filter { it != r[1] }.shuffled(rnd).take(3).map { it.toString() }
        return mcq("இந்த வசனம் “${book.ta}” புத்தகத்தின் எந்த அதிகாரத்தில் உள்ளது?", v.ta, r[1].toString(), wrong,
            "${book.ta} ${r[1]}:${r[2]}")
    }

    private fun clean(w: String) = w.trim { !it.isLetter() && it.code !in 0x0B80..0x0BFF }

    private suspend fun fillWord(r: IntArray): Question? {
        val (book, v) = repo.verseWithBook(r[0], r[1], r[2]) ?: return null
        val words = v.ta.split(" ").filter { it.isNotBlank() }
        val candidates = words.indices.filter { clean(words[it]).length >= 4 }
        if (candidates.isEmpty()) return whichBook(r)
        val i = candidates.random(rnd)
        val answer = clean(words[i])
        val blanked = words.mapIndexed { j, w -> if (j == i) w.replace(answer, "______") else w }.joinToString(" ")
        // Wrong options: words of similar length from other random verses.
        val pool = repo.randomVerses(6).flatMap { it.ta.split(" ") }.map(::clean)
            .filter { it.length >= 3 && it != answer && kotlin.math.abs(it.length - answer.length) <= 3 }
            .distinct().shuffled(rnd)
        if (pool.size < 3) return whichBook(r)
        return mcq("விடுபட்ட வார்த்தை எது?", blanked, answer, pool, "${book.ta} ${r[1]}:${r[2]}")
    }
}
