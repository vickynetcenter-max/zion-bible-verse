package com.vicky.tamilbible

import android.content.Intent
import android.graphics.Color
import com.vicky.tamilbible.notify.DailyVerseNotifier
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.vicky.tamilbible.ui.BibleApp
import com.vicky.tamilbible.ui.theme.BibleTheme
import com.vicky.tamilbible.ui.theme.isDark

class MainActivity : ComponentActivity() {

    private val vm: BibleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        DailyVerseNotifier.createChannel(this)
        DailyVerseNotifier.schedule(this)
        com.vicky.tamilbible.notify.EventReminders.schedule(this)
        if (savedInstanceState == null) handleOpen(intent)
        setContent {
            val dark = isDark(vm.theme)
            LaunchedEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
                else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            BibleTheme(dark) {
                BibleApp(vm)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleOpen(intent)
    }

    /** Notification taps carry the verse to open. */
    private fun handleOpen(intent: Intent?) {
        val book = intent?.getIntExtra(DailyVerseNotifier.EXTRA_BOOK, 0) ?: 0
        if (book <= 0) return
        vm.requestOpen(
            book,
            intent!!.getIntExtra(DailyVerseNotifier.EXTRA_CHAPTER, 1),
            intent.getIntExtra(DailyVerseNotifier.EXTRA_VERSE, 1),
        )
    }
}
