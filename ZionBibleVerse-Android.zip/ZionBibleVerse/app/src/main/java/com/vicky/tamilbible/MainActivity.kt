package com.vicky.tamilbible

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.vicky.tamilbible.ui.BibleApp
import com.vicky.tamilbible.ui.theme.BibleTheme
import com.vicky.tamilbible.ui.theme.isDark

class MainActivity : ComponentActivity() {

    private val vm: BibleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isDark(vm.theme)
            LaunchedEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
                else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            BibleTheme(dark) {
                BibleApp(vm)
            }
        }
    }
}
