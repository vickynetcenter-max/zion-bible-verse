package com.vicky.tamilbible.data

import android.content.Context
import java.time.DayOfWeek
import java.time.LocalTime

/** A recurring church programme, e.g. Sunday worship at 08:00. */
data class ChurchEvent(val id: String, val title: String, val days: Set<DayOfWeek>, val time: LocalTime)

/** Reads assets/church_events.txt ("title | SUN WED | 19:00" per line; "//" = comment). */
object ChurchEvents {
    private val DAY = mapOf(
        "SUN" to DayOfWeek.SUNDAY, "MON" to DayOfWeek.MONDAY, "TUE" to DayOfWeek.TUESDAY,
        "WED" to DayOfWeek.WEDNESDAY, "THU" to DayOfWeek.THURSDAY, "FRI" to DayOfWeek.FRIDAY,
        "SAT" to DayOfWeek.SATURDAY,
    )

    fun load(context: Context): List<ChurchEvent> {
        val lines: List<String> = runCatching {
            context.assets.open("church_events.txt").bufferedReader().readLines()
        }.getOrDefault(emptyList())
        return lines.mapNotNull { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("//")) return@mapNotNull null
            val parts = line.split("|").map { it.trim() }
            if (parts.size < 3) return@mapNotNull null
            val days = if (parts[1].equals("DAILY", true)) DayOfWeek.values().toSet()
            else parts[1].uppercase().split(Regex("[\\s,]+")).mapNotNull { DAY[it.take(3)] }.toSet()
            val time = runCatching { LocalTime.parse(parts[2].padStart(5, '0')) }.getOrNull()
            if (parts[0].isEmpty() || days.isEmpty() || time == null) null
            else ChurchEvent("${parts[0]}|${parts[1]}|${parts[2]}", parts[0], days, time)
        }
    }
}
