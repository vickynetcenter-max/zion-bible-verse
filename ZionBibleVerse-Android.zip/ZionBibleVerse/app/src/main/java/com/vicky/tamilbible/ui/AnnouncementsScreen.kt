package com.vicky.tamilbible.ui

import androidx.compose.runtime.setValue

import androidx.compose.runtime.getValue

import androidx.compose.ui.graphics.asImageBitmap

import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.clickable

import androidx.compose.foundation.background

import androidx.compose.ui.draw.clip

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** 📢 அறிவிப்புகள்: announcements posted by the church admin, newest first. */
@Composable
fun AnnouncementsScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val lang = vm.lang
    LaunchedEffect(Unit) { vm.refreshRemote(); vm.markNewsRead() }
    LaunchedEffect(vm.announcements) { vm.markNewsRead() }
    ScreenScaffold(lang.ui("அறிவிப்புகள்", "Announcements"), lang, onBack) {
        if (vm.announcements.isEmpty()) {
            Spacer(Modifier.height(48.dp))
            Text(
                lang.ui("இன்னும் அறிவிப்புகள் இல்லை", "No announcements yet"),
                fontFamily = TamilFont, fontSize = 16.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(),
            )
            return@ScreenScaffold
        }
        vm.announcements.forEach { a ->
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(formatDate(a.id), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    if (a.image.isNotBlank()) AnnouncementPicture(a.image)
                    if (a.title.isNotBlank()) Text(a.title, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    if (a.message.isNotBlank()) Text(a.message, fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                }
            }
        }
    }
}

internal fun formatDate(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a", Locale.ENGLISH))

/** Picture of an announcement (downloaded once, then cached). Tap to see it full screen. */
@Composable
private fun AnnouncementPicture(id: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, id) {
        value = com.vicky.tamilbible.data.AnnouncementImages.load(context, id)
    }
    var full by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val b = bmp
    if (b == null) {
        androidx.compose.foundation.layout.Box(
            Modifier.fillMaxWidth().height(180.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) { androidx.compose.material3.CircularProgressIndicator(Modifier.size(28.dp)) }
        return
    }
    val img = b.asImageBitmap()
    androidx.compose.foundation.Image(
        img, contentDescription = null,
        contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { full = true },
    )
    if (full) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { full = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black).clickable { full = false },
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(img, null, contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

