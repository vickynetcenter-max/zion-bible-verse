package com.vicky.tamilbible.ui

import androidx.compose.ui.text.withLink
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.setValue

import androidx.compose.runtime.getValue

import androidx.compose.ui.graphics.asImageBitmap

import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.clickable

import androidx.compose.foundation.background

import androidx.compose.ui.draw.clip

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** 📢 அறிவிப்புகள்: announcements posted by the church admin, newest first. */
@Composable
fun AnnouncementsScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val lang = vm.lang
    val context = androidx.compose.ui.platform.LocalContext.current
    var hidden by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(com.vicky.tamilbible.data.RemoteCache.hidden(context)) }
    var confirmAll by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.refreshRemote(); vm.markNewsRead() }
    LaunchedEffect(vm.announcements) {
        vm.markNewsRead()
        // Opening the list clears the announcement notifications from the status bar.
        com.vicky.tamilbible.notify.ChurchSync.cancel(context, vm.announcements.map { it.id })
    }
    // Newest first; each post disappears 24 hours after it went out.
    val shown = vm.liveAnnouncements.filter { it.id !in hidden }
    fun hide(ids: List<Long>) {
        com.vicky.tamilbible.data.RemoteCache.hide(context, ids)
        com.vicky.tamilbible.notify.ChurchSync.cancel(context, ids)
        hidden = hidden + ids
    }
    ScreenScaffold(lang.ui("அறிவிப்புகள்", "Announcements"), lang, onBack, actions = {
        if (shown.isNotEmpty()) androidx.compose.material3.TextButton(onClick = { confirmAll = true }) {
            Text(lang.ui("எல்லாம் அழி", "Clear all"), fontFamily = TamilFont)
        }
    }) {
        if (vm.refreshing) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
        if (shown.isEmpty()) {
            Spacer(Modifier.height(48.dp))
            Text(
                lang.ui("அறிவிப்புகள் எதுவும் இல்லை", "No announcements"),
                fontFamily = TamilFont, fontSize = 16.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(),
            )
            return@ScreenScaffold
        }
        Text(lang.ui("ஒவ்வொரு அறிவிப்பும் 24 மணி நேரம் மட்டும் காட்டப்படும்", "Each announcement is shown for 24 hours"),
            fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        shown.forEach { a ->
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatDate(a.publishAt), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        // ✕ clears this announcement on this phone
                        androidx.compose.material3.IconButton(onClick = { hide(listOf(a.id)) }) {
                            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Filled.Close,
                                contentDescription = lang.ui("அழி", "Clear"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Column(Modifier.padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        when (a.images.size) {
                            0 -> {}
                            1 -> AnnouncementPicture(a.images[0])
                            else -> AnnouncementSlider(a.images)
                        }
                        if (a.title.isNotBlank()) Text(a.title, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (a.message.isNotBlank()) Text(linkified(a.message, MaterialTheme.colorScheme.primary),
                            fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                        if (a.link.isNotBlank()) AnnouncementLink(a.link, a.youtubeId, a.isShorts, lang)
                    }
                }
            }
        }
    }
    if (confirmAll) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text(lang.ui("எல்லா அறிவிப்புகளையும் அழிக்கவா?", "Clear all announcements?"), fontFamily = TamilFont) },
            text = { Text(lang.ui("இந்த phone-ல் மட்டும் மறையும்.", "They are hidden on this phone only."), fontFamily = TamilFont) },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmAll = false; hide(shown.map { it.id }) }) { Text(lang.ui("அழி", "Clear"), fontFamily = TamilFont) } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmAll = false }) { Text(lang.ui("வேண்டாம்", "Cancel"), fontFamily = TamilFont) } },
        )
    }
}

internal fun formatDate(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a", Locale.ENGLISH))

/** Picture of an announcement (downloaded once, then cached). Tap to see it full screen. */
@Composable
private fun AnnouncementPicture(id: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, id) {
        value = com.vicky.tamilbible.data.AnnouncementImages.load(context, id)
    }
    var full by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val b = bmp
    if (b == null) {
        androidx.compose.foundation.layout.Box(
            Modifier.fillMaxWidth().height(180.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) { androidx.compose.material3.CircularProgressIndicator(Modifier.size(28.dp)) }
        return
    }
    val img = b.asImageBitmap()
    androidx.compose.foundation.Image(
        img, contentDescription = null,
        contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { full = true },
    )
    if (full) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { full = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black).clickable { full = false },
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(img, null, contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/** Makes web links inside a message tappable. */
internal fun linkified(text: String, color: androidx.compose.ui.graphics.Color): androidx.compose.ui.text.AnnotatedString =
    androidx.compose.ui.text.buildAnnotatedString {
        val re = Regex("""(https?://|www\.)[^\s]+""")
        var last = 0
        re.findAll(text).forEach { m ->
            append(text.substring(last, m.range.first))
            val url = m.value.trimEnd('.', ',', ')', '!', '?').let { if (it.startsWith("http")) it else "https://$it" }
            withLink(androidx.compose.ui.text.LinkAnnotation.Url(url,
                androidx.compose.ui.text.TextLinkStyles(androidx.compose.ui.text.SpanStyle(color = color,
                    textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)))) { append(m.value) }
            last = m.range.last + 1
        }
        append(text.substring(last))
    }

/** YouTube video / Shorts card (thumbnail + ▶) or a plain "open link" button. Opens in the YouTube app / browser. */
@Composable
internal fun AnnouncementLink(link: String, youtubeId: String?, shorts: Boolean, lang: com.vicky.tamilbible.data.Lang) {
    val context = androidx.compose.ui.platform.LocalContext.current
    if (youtubeId == null) {
        androidx.compose.material3.OutlinedButton(onClick = { openUrl(context, link) }, modifier = Modifier.fillMaxWidth()) {
            Text("🔗 " + lang.ui("திற", "Open") + " · " + link.removePrefix("https://").removePrefix("http://").take(40),
                maxLines = 1, fontFamily = TamilFont)
        }
        return
    }
    val thumb by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, youtubeId) {
        value = com.vicky.tamilbible.data.AnnouncementImages.youtubeThumb(context, youtubeId)
    }
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(androidx.compose.ui.graphics.Color.Black)
            .clickable { openUrl(context, link) },
        contentAlignment = Alignment.Center,
    ) {
        val t = thumb
        if (t != null) androidx.compose.foundation.Image(t.asImageBitmap(), null,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(if (shorts) 260.dp else 190.dp))
        else androidx.compose.foundation.layout.Spacer(Modifier.fillMaxWidth().height(if (shorts) 260.dp else 190.dp))
        // ▶ play button
        androidx.compose.foundation.layout.Box(
            Modifier.size(60.dp).clip(androidx.compose.foundation.shape.CircleShape).background(androidx.compose.ui.graphics.Color(0xE6E53935)),
            contentAlignment = Alignment.Center,
        ) { Text("▶", color = androidx.compose.ui.graphics.Color.White, fontSize = 26.sp) }
        androidx.compose.material3.Surface(
            shape = RoundedCornerShape(8.dp), color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.65f),
            contentColor = androidx.compose.ui.graphics.Color.White,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
        ) {
            Text((if (shorts) "▶ Shorts · " else "▶ YouTube · ") + lang.ui("பார்க்க தொடவும்", "Tap to watch"),
                fontFamily = TamilFont, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
    }
}

/** Several pictures: swipe sideways, dots + "2 / 5" counter. Tap = full-screen slider. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
internal fun AnnouncementSlider(ids: List<String>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val pager = androidx.compose.foundation.pager.rememberPagerState { ids.size }
    var fullAt by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        androidx.compose.foundation.layout.Box {
            androidx.compose.foundation.pager.HorizontalPager(
                state = pager, pageSpacing = 8.dp,
                modifier = Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(12.dp)),
            ) { page ->
                SliderImage(ids[page], androidx.compose.ui.layout.ContentScale.Crop,
                    Modifier.fillMaxSize().clickable { fullAt = page })
            }
            androidx.compose.material3.Surface(
                shape = RoundedCornerShape(10.dp), color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f),
                contentColor = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
            ) { Text("${pager.currentPage + 1} / ${ids.size}", fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)) }
        }
        Dots(ids.size, pager.currentPage)
    }
    val start = fullAt
    if (start != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { fullAt = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            val full = androidx.compose.foundation.pager.rememberPagerState(initialPage = start) { ids.size }
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
                androidx.compose.foundation.pager.HorizontalPager(state = full, modifier = Modifier.fillMaxSize()) { page ->
                    SliderImage(ids[page], androidx.compose.ui.layout.ContentScale.Fit, Modifier.fillMaxSize().clickable { fullAt = null })
                }
                androidx.compose.foundation.layout.Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)) {
                    Dots(ids.size, full.currentPage, androidx.compose.ui.graphics.Color.White)
                }
                Text("${full.currentPage + 1} / ${ids.size}", color = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 40.dp))
            }
        }
    }
}

@Composable
private fun SliderImage(id: String, scale: androidx.compose.ui.layout.ContentScale, modifier: Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, id) {
        value = com.vicky.tamilbible.data.AnnouncementImages.load(context, id)
    }
    val b = bmp
    androidx.compose.foundation.layout.Box(modifier.background(androidx.compose.ui.graphics.Color(0xFF20232B)), contentAlignment = Alignment.Center) {
        if (b == null) androidx.compose.material3.CircularProgressIndicator(Modifier.size(28.dp), color = androidx.compose.ui.graphics.Color.White)
        else androidx.compose.foundation.Image(b.asImageBitmap(), null, contentScale = scale, modifier = Modifier.fillMaxSize())
    }
}

@Composable
internal fun Dots(count: Int, current: Int, active: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary) {
    androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            androidx.compose.foundation.layout.Box(
                Modifier.padding(horizontal = 3.dp).size(if (i == current) 9.dp else 7.dp).clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (i == current) active else active.copy(alpha = 0.3f))
            )
        }
    }
}
