package com.vicky.tamilbible.ui

import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.setValue

import androidx.compose.runtime.getValue

import androidx.compose.ui.graphics.asImageBitmap

import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.clickable

import androidx.compose.foundation.background

import androidx.compose.ui.draw.clip

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** 📢 அறிவிப்புகள்: announcements posted by the church admin, newest first. */
@Composable
fun AnnouncementsScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val lang = vm.lang
    val context = androidx.compose.ui.platform.LocalContext.current
    var hidden by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(com.vicky.tamilbible.data.RemoteCache.hidden(context)) }
    var confirmAll by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.refreshRemote(); vm.markNewsRead() }
    LaunchedEffect(vm.announcements) {
        vm.markNewsRead()
        // Opening the list clears the announcement notifications from the status bar.
        com.vicky.tamilbible.notify.ChurchSync.cancel(context, vm.announcements.map { it.id })
    }
    // Newest first; each post disappears 24 hours after it went out.
    val shown = vm.liveAnnouncements.filter { it.id !in hidden }
    fun hide(ids: List<Long>) {
        com.vicky.tamilbible.data.RemoteCache.hide(context, ids)
        com.vicky.tamilbible.notify.ChurchSync.cancel(context, ids)
        hidden = hidden + ids
    }
    ScreenScaffold(lang.ui("அறிவிப்புகள்", "Announcements"), lang, onBack, actions = {
        if (shown.isNotEmpty()) androidx.compose.material3.TextButton(onClick = { confirmAll = true }) {
            Text(lang.ui("எல்லாம் அழி", "Clear all"), fontFamily = TamilFont)
        }
    }) {
        if (shown.isEmpty()) {
            Spacer(Modifier.height(48.dp))
            Text(
                lang.ui("அறிவிப்புகள் எதுவும் இல்லை", "No announcements"),
                fontFamily = TamilFont, fontSize = 16.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(),
            )
            return@ScreenScaffold
        }
        Text(lang.ui("ஒவ்வொரு அறிவிப்பும் 24 மணி நேரம் மட்டும் காட்டப்படும்", "Each announcement is shown for 24 hours"),
            fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        shown.forEach { a ->
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatDate(a.publishAt), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        // ✕ clears this announcement on this phone
                        androidx.compose.material3.IconButton(onClick = { hide(listOf(a.id)) }) {
                            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Filled.Close,
                                contentDescription = lang.ui("அழி", "Clear"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Column(Modifier.padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (a.image.isNotBlank()) AnnouncementPicture(a.image)
                        if (a.title.isNotBlank()) Text(a.title, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (a.message.isNotBlank()) Text(a.message, fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                    }
                }
            }
        }
    }
    if (confirmAll) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text(lang.ui("எல்லா அறிவிப்புகளையும் அழிக்கவா?", "Clear all announcements?"), fontFamily = TamilFont) },
            text = { Text(lang.ui("இந்த phone-ல் மட்டும் மறையும்.", "They are hidden on this phone only."), fontFamily = TamilFont) },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmAll = false; hide(shown.map { it.id }) }) { Text(lang.ui("அழி", "Clear"), fontFamily = TamilFont) } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmAll = false }) { Text(lang.ui("வேண்டாம்", "Cancel"), fontFamily = TamilFont) } },
        )
    }
}

internal fun formatDate(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a", Locale.ENGLISH))

/** Picture of an announcement (downloaded once, then cached). Tap to see it full screen. */
@Composable
private fun AnnouncementPicture(id: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, id) {
        value = com.vicky.tamilbible.data.AnnouncementImages.load(context, id)
    }
    var full by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val b = bmp
    if (b == null) {
        androidx.compose.foundation.layout.Box(
            Modifier.fillMaxWidth().height(180.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) { androidx.compose.material3.CircularProgressIndicator(Modifier.size(28.dp)) }
        return
    }
    val img = b.asImageBitmap()
    androidx.compose.foundation.Image(
        img, contentDescription = null,
        contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { full = true },
    )
    if (full) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { full = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black).clickable { full = false },
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(img, null, contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

