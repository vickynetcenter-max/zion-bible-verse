package com.vicky.tamilbible.ui

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.Church
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

private data class Tile(val ta: String, val en: String, val icon: Painter, val onClick: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    vm: BibleViewModel,
    lastPage: Int,
    onTestament: (String) -> Unit,
    onContinue: () -> Unit,
    onPraise: () -> Unit,
    onSettings: () -> Unit,
    onSocial: () -> Unit,
) {
    val lang = vm.lang
    val context = LocalContext.current
    var confirmExit by remember { mutableStateOf(false) }

    val tiles = listOf(
        Tile("பழைய ஏற்பாடு", "Old Testament", painterResource(R.drawable.ic_book_ot)) { onTestament("OT") },
        Tile("புதிய ஏற்பாடு", "New Testament", painterResource(R.drawable.ic_book_nt)) { onTestament("NT") },
        Tile("ஸ்தோத்திர பலி", "Praise Offering", rememberVectorPainter(Icons.Filled.Favorite), onPraise),
        Tile("அமைப்பு", "Settings", rememberVectorPainter(Icons.Filled.Settings), onSettings),
        Tile("சோசியல் மீடியா", "Social Media", rememberVectorPainter(Icons.Filled.Share), onSocial),
        Tile("வெளியேறு", "Exit", rememberVectorPainter(Icons.AutoMirrored.Filled.ExitToApp)) { confirmExit = true },
    )

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        // Header
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            ZionEmblem(size = 56.dp)
            Spacer(Modifier.size(12.dp))
            Column {
                Text("Zion Bible Verse", fontWeight = FontWeight.Bold, fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onBackground)
                Text(Church.NAME_TA, fontFamily = TamilFont, fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary)
                Text(Church.PLACE_TA, fontFamily = TamilFont, fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Continue reading
        val (book, chapter) = vm.refOf(lastPage)
        Surface(
            onClick = onContinue,
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(lang.ui("தொடர்ந்து வாசிக்க", "Continue reading"), fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                    Text(
                        "${book.displayName(lang)} $chapter",
                        fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                        fontWeight = FontWeight.SemiBold, fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onPrimary)
            }
        }

        Spacer(Modifier.height(16.dp))

        // Six tiles, two per row
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t -> DashTile(t, lang, Modifier.weight(1f)) }
            }
        }

        // 24/7 prayer help
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 20.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(lang.ui("24/7 ஜெப உதவி", "24/7 Prayer help"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Church.PRAYER_PHONES.forEach { phone ->
                        OutlinedButton(
                            onClick = { dial(context, phone) },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        ) {
                            Icon(Icons.Filled.Call, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(6.dp))
                            Text(phone, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                    }
                }
                Text(Church.PASTOR_TA, fontFamily = TamilFont, fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text(lang.ui("வெளியேற வேண்டுமா?", "Exit the app?"), fontFamily = TamilFont) },
            confirmButton = {
                TextButton(onClick = { (context as? Activity)?.finish() }) { Text(lang.ui("ஆம்", "Yes")) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) { Text(lang.ui("இல்லை", "No")) }
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DashTile(t: Tile, lang: Lang, modifier: Modifier) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.height(118.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = t.onClick),
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(t.icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (lang == Lang.EN) t.en else t.ta,
                fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp, textAlign = TextAlign.Center,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (lang != Lang.EN) {
                Text(t.en, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}
