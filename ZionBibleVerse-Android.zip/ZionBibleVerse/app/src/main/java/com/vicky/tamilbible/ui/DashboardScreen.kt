package com.vicky.tamilbible.ui

import android.Manifest
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import com.vicky.tamilbible.ui.theme.ZionNavy
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Verse
import com.vicky.tamilbible.notify.DailyVerseNotifier
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.Church
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

private data class Tile(val ta: String, val en: String, val icon: Painter, val onClick: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    vm: BibleViewModel,
    lastPage: Int,
    onTestament: (String) -> Unit,
    onContinue: () -> Unit,
    onOpenVerse: (book: Int, chapter: Int, verse: Int) -> Unit,
    onPraise: () -> Unit,
    onSettings: () -> Unit,
    onSocial: () -> Unit,
) {
    val lang: Lang = vm.lang
    val context = LocalContext.current
    var confirmExit by remember { mutableStateOf(false) }

    // Today's verse belongs to today only: reload when the app comes back to the
    // foreground and again right after midnight if the dashboard stays open.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.loadTodayVerse() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            vm.loadTodayVerse()
            val midnight = LocalDate.now().plusDays(1).atStartOfDay()
            delay(Duration.between(LocalDateTime.now(), midnight).toMillis() + 1_000)
        }
    }

    // Android 13+: ask once for permission to show the daily-verse notification.
    val askNotify = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        DailyVerseNotifier.schedule(context)
    }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33 && !prefs.getBoolean("asked_notify", false) &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.edit().putBoolean("asked_notify", true).apply()
            askNotify.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val tiles = listOf(
        Tile("பழைய ஏற்பாடு", "Old Testament", painterResource(R.drawable.ic_book_ot)) { onTestament("OT") },
        Tile("புதிய ஏற்பாடு", "New Testament", painterResource(R.drawable.ic_book_nt)) { onTestament("NT") },
        Tile("ஸ்தோத்திர பலி", "Praise Offering", rememberVectorPainter(Icons.Filled.Favorite), onPraise),
        Tile("அமைப்பு", "Settings", rememberVectorPainter(Icons.Filled.Settings), onSettings),
        Tile("சோசியல் மீடியா", "Social Media", rememberVectorPainter(Icons.Filled.Share), onSocial),
        Tile("வெளியேறு", "Exit", rememberVectorPainter(Icons.AutoMirrored.Filled.ExitToApp)) { confirmExit = true },
    )

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        // Header
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            ZionEmblem(size = 56.dp)
            Spacer(Modifier.size(12.dp))
            Column {
                Text("Zion Bible Verse", fontWeight = FontWeight.Bold, fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onBackground)
                Text(Church.NAME_TA, fontFamily = TamilFont, fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary)
                Text(Church.PLACE_TA, fontFamily = TamilFont, fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        vm.todayVerse?.let { t ->
            val b = t.book; val v = t.verse; val ch = t.chapter
            TodayVerseSection(b, ch, v, lang,
                onRead = { onOpenVerse(b.ord, ch, v.num) },
                onShare = {
                    val text = when (lang) {
                        Lang.TA -> "${v.ta}\n— ${b.ta} $ch:${v.num}"
                        Lang.EN -> "${v.en}\n— ${b.en} $ch:${v.num}"
                        Lang.BOTH -> "${v.ta}\n${v.en}\n— ${b.ta} / ${b.en} $ch:${v.num}"
                    }
                    context.startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
                },
            )
            Spacer(Modifier.height(16.dp))
        }

        // Continue reading
        val (book, chapter) = vm.refOf(lastPage)
        Surface(
            onClick = onContinue,
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(lang.ui("தொடர்ந்து வாசிக்க", "Continue reading"), fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                    Text(
                        "${book.displayName(lang)} $chapter",
                        fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                        fontWeight = FontWeight.SemiBold, fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onPrimary)
            }
        }

        Spacer(Modifier.height(16.dp))

        // Six tiles, two per row
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t -> DashTile(t, lang, Modifier.weight(1f)) }
            }
        }

        // 24/7 prayer help
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 20.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(lang.ui("24/7 ஜெப உதவி", "24/7 Prayer help"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Church.PRAYER_PHONES.forEach { phone ->
                        OutlinedButton(
                            onClick = { dial(context, phone) },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        ) {
                            Icon(Icons.Filled.Call, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(6.dp))
                            Text(phone, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                    }
                }
                Text(Church.PASTOR_TA, fontFamily = TamilFont, fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text(lang.ui("வெளியேற வேண்டுமா?", "Exit the app?"), fontFamily = TamilFont) },
            confirmButton = {
                TextButton(onClick = { (context as? Activity)?.finish() }) { Text(lang.ui("ஆம்", "Yes")) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) { Text(lang.ui("இல்லை", "No")) }
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DashTile(t: Tile, lang: Lang, modifier: Modifier) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.height(118.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = t.onClick),
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(t.icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (lang == Lang.EN) t.en else t.ta,
                fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp, textAlign = TextAlign.Center,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (lang != Lang.EN) {
                Text(t.en, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

/** Lets a child ignore the parent's horizontal padding and span the full screen width. */
private fun Modifier.fullBleed(side: Dp) = layout { measurable, constraints ->
    val extra = (side * 2).roundToPx()
    val p = measurable.measure(constraints.copy(
        minWidth = constraints.maxWidth + extra, maxWidth = constraints.maxWidth + extra))
    layout(constraints.maxWidth, p.height) { p.place(-side.roundToPx(), 0) }
}

/**
 * "இன்றைய வார்த்தை": the verse in large bold type with its reference on the right,
 * followed by a full-width bar that folds the verse away (remembered across launches).
 */
@Composable
private fun TodayVerseSection(b: Book, ch: Int, v: Verse, lang: Lang, onRead: () -> Unit, onShare: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var expanded by remember { mutableStateOf(prefs.getBoolean("today_expanded", true)) }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val ink = if (dark) MaterialTheme.colorScheme.onBackground else ZionNavy

    Column(Modifier.fullBleed(16.dp)) {
        AnimatedVisibility(visible = expanded, enter = expandVertically(), exit = shrinkVertically()) {
            Column(
                Modifier.fillMaxWidth().clickable(onClick = onRead)
                    .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
            ) {
                if (lang != Lang.EN) {
                    Text(
                        buildAnnotatedString {
                            withStyle(SpanStyle(fontSize = 15.sp)) { append("${v.num} ") }
                            append(v.ta)
                        },
                        fontFamily = TamilFont, fontWeight = FontWeight.Bold,
                        fontSize = 21.sp, lineHeight = 32.sp, color = ink,
                    )
                }
                if (lang != Lang.TA) {
                    Text(
                        if (lang == Lang.EN) "${v.num} ${v.en}" else v.en,
                        fontFamily = EnglishSerif,
                        fontWeight = if (lang == Lang.EN) FontWeight.Bold else FontWeight.Normal,
                        fontSize = if (lang == Lang.EN) 20.sp else 16.sp, lineHeight = 28.sp,
                        color = if (lang == Lang.EN) ink else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = if (lang == Lang.BOTH) 6.dp else 0.dp),
                    )
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onShare) {
                        Icon(Icons.Filled.Share, lang.ui("பகிர்", "Share"), Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${b.displayName(lang)} $ch:${v.num}",
                        fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                        fontWeight = FontWeight.Bold, fontSize = 20.sp, color = ink,
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth()
                .background(if (dark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF8FAAD0))
                .clickable {
                    expanded = !expanded
                    prefs.edit().putBoolean("today_expanded", expanded).apply()
                }
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(Modifier.size(48.dp, 1.dp))
            Text(
                lang.ui("இன்றைய வார்த்தை", "Today's Word"),
                fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 22.sp,
                color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
            )
            Icon(
                if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = lang.ui(if (expanded) "மறை" else "காட்டு", if (expanded) "Hide" else "Show"),
                tint = Color.White,
                modifier = Modifier.size(48.dp).padding(end = 12.dp),
            )
        }
    }
}
