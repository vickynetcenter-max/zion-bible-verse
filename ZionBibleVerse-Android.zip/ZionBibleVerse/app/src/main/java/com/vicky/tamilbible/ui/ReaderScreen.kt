package com.vicky.tamilbible.ui

import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.ThemeMode
import com.vicky.tamilbible.data.Verse
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    vm: BibleViewModel,
    pagerState: PagerState,
    onOpenBooks: () -> Unit,
    onOpenSearch: () -> Unit,
    onHome: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val lang = vm.lang
    val currentPage = pagerState.currentPage
    val (book, chapter) = vm.refOf(currentPage)

    var selected by remember { mutableStateOf(emptySet<Int>()) }
    var showSettings by remember { mutableStateOf(false) }

    // Remember position and drop verse selection whenever the chapter changes.
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect {
            selected = emptySet()
            vm.savePage(it)
        }
    }

    // Jumps coming from the book list or search.
    val jump = vm.jump
    LaunchedEffect(jump) {
        if (jump != null) {
            pagerState.scrollToPage(jump.page)
            if (jump.verse == null) vm.consumeJump(jump)
        }
    }

    val currentVerses by produceState(emptyList<Verse>(), currentPage) {
        value = vm.versesFor(currentPage)
    }

    Scaffold(
        modifier = Modifier.pageBackground(),
        containerColor = Color.Transparent,
        topBar = {
            ReaderTopBar(
                book = book, chapter = chapter, lang = lang,
                onTitle = onOpenBooks, onSearch = onOpenSearch, onHome = onHome,
                onSettings = { showSettings = true },
            )
        },
        bottomBar = {
            if (selected.isEmpty()) {
                ReaderBottomBar(
                    lang = lang,
                    canPrev = currentPage > 0,
                    canNext = currentPage < vm.totalPages - 1,
                    onPrev = { scope.launch { pagerState.animateScrollToPage(currentPage - 1) } },
                    onNext = { scope.launch { pagerState.animateScrollToPage(currentPage + 1) } },
                    onLang = vm::updateLang,
                )
            } else {
                val context = LocalContext.current
                val clipboard = LocalClipboardManager.current
                val picked = currentVerses.filter { it.num in selected }
                val text = shareText(book, chapter, picked, lang)
                SelectionBar(
                    count = selected.size,
                    lang = lang,
                    onCopy = {
                        clipboard.setText(AnnotatedString(text))
                        selected = emptySet()
                    },
                    onShare = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, null))
                        selected = emptySet()
                    },
                    onClear = { selected = emptySet() },
                )
            }
        },
    ) { inner ->
        HorizontalPager(
            state = pagerState,
            key = { it },
            beyondViewportPageCount = 1,
            modifier = Modifier.fillMaxSize().padding(inner),
        ) { page ->
            ChapterPage(
                vm = vm,
                page = page,
                selected = if (page == currentPage) selected else emptySet(),
                onToggle = { n -> selected = if (n in selected) selected - n else selected + n },
            )
        }
    }

    if (showSettings) {
        ModalBottomSheet(
            onDismissRequest = { showSettings = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            SettingsSheet(vm)
        }
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun ReaderTopBar(
    book: Book, chapter: Int, lang: Lang,
    onTitle: () -> Unit, onSearch: () -> Unit, onSettings: () -> Unit, onHome: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(60.dp).padding(start = 4.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onHome) {
                    Icon(Icons.Filled.Home, contentDescription = lang.ui("முகப்பு", "Home"))
                }
                Row(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onTitle)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f, fill = false)) {
                        Text(
                            "${book.displayName(lang)} $chapter",
                            fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 19.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        if (lang == Lang.BOTH) {
                            Text(
                                "${book.en} $chapter",
                                fontSize = 12.sp,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Icon(
                        Icons.Filled.ArrowDropDown,
                        contentDescription = lang.ui("புத்தகம் தேர்வு", "Choose book"),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
                IconButton(onClick = onSearch) {
                    Icon(Icons.Filled.Search, contentDescription = lang.ui("தேடல்", "Search"))
                }
                IconButton(onClick = onSettings) {
                    Text(
                        "Aa",
                        fontFamily = EnglishSerif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderBottomBar(
    lang: Lang, canPrev: Boolean, canNext: Boolean,
    onPrev: () -> Unit, onNext: () -> Unit, onLang: (Lang) -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
        Column {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onPrev, enabled = canPrev) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = lang.ui("முந்தைய அதிகாரம்", "Previous chapter"),
                    )
                }
                val options = listOf(
                    Lang.TA to "தமிழ்",
                    Lang.EN to "English",
                    Lang.BOTH to lang.ui("இரண்டும்", "Both"),
                )
                SingleChoiceSegmentedButtonRow(Modifier.weight(1f)) {
                    options.forEachIndexed { i, (value, label) ->
                        SegmentedButton(
                            selected = lang == value,
                            onClick = { onLang(value) },
                            shape = SegmentedButtonDefaults.itemShape(i, options.size),
                            icon = {},
                            colors = SegmentedButtonDefaults.colors(
                                activeContainerColor = MaterialTheme.colorScheme.primary,
                                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                                activeBorderColor = MaterialTheme.colorScheme.primary,
                                inactiveContainerColor = Color.Transparent,
                                inactiveBorderColor = MaterialTheme.colorScheme.outline,
                            ),
                        ) {
                            Text(label, fontSize = 13.sp, maxLines = 1, softWrap = false)
                        }
                    }
                }
                IconButton(onClick = onNext, enabled = canNext) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = lang.ui("அடுத்த அதிகாரம்", "Next chapter"),
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectionBar(
    count: Int, lang: Lang,
    onCopy: () -> Unit, onShare: () -> Unit, onClear: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClear) {
                Icon(Icons.Filled.Close, contentDescription = lang.ui("தேர்வை நீக்கு", "Clear selection"))
            }
            Text(
                lang.ui("$count வசனம் தேர்வு", if (count == 1) "1 verse selected" else "$count verses selected"),
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
            )
            TextButton(onClick = onCopy) {
                Text(lang.ui("நகலெடு", "Copy"), color = MaterialTheme.colorScheme.onPrimary)
            }
            TextButton(onClick = onShare) {
                Text(lang.ui("பகிர்", "Share"), color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun ChapterPage(
    vm: BibleViewModel,
    page: Int,
    selected: Set<Int>,
    onToggle: (Int) -> Unit,
) {
    val (book, chapter) = vm.refOf(page)
    val verses by produceState<List<Verse>?>(null, page) { value = vm.versesFor(page) }
    val listState = rememberLazyListState()
    var flashVerse by remember { mutableStateOf<Int?>(null) }

    val jump = vm.jump
    LaunchedEffect(jump, verses) {
        val list = verses
        if (jump != null && jump.page == page && jump.verse != null && list != null) {
            val index = list.indexOfFirst { it.num == jump.verse }.coerceAtLeast(0) + 1 // +1 for header
            listState.scrollToItem(index)
            flashVerse = jump.verse
            vm.consumeJump(jump)
        }
    }
    LaunchedEffect(flashVerse) {
        if (flashVerse != null) { delay(2400); flashVerse = null }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        val list = verses ?: return@Box
        LazyColumn(
            state = listState,
            modifier = Modifier.widthIn(max = 680.dp).fillMaxHeight(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 48.dp),
        ) {
            item(key = "header") { ChapterHeader(book, chapter, vm.lang) }
            items(list, key = { it.num }) { v ->
                VerseItem(
                    verse = v,
                    lang = vm.lang,
                    fontSize = vm.fontSize,
                    selected = v.num in selected,
                    flash = v.num == flashVerse,
                    onClick = { onToggle(v.num) },
                )
            }
        }
    }
}

@Composable
private fun ChapterHeader(book: Book, chapter: Int, lang: Lang) {
    Column(Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, bottom = 22.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "$chapter",
                fontFamily = EnglishSerif,
                fontWeight = FontWeight.Normal,
                fontSize = 68.sp,
                lineHeight = 68.sp,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.padding(bottom = 8.dp)) {
                Text(
                    book.displayName(lang),
                    fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp,
                    lineHeight = 30.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                book.secondaryName(lang)?.let {
                    Text(
                        it,
                        fontFamily = if (lang == Lang.EN) TamilFont else EnglishSerif,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.width(44.dp).height(2.dp).background(MaterialTheme.colorScheme.secondary)
        )
    }
}

@Composable
private fun VerseItem(
    verse: Verse, lang: Lang, fontSize: Float,
    selected: Boolean, flash: Boolean, onClick: () -> Unit,
) {
    val bg by animateColorAsState(
        when {
            selected -> MaterialTheme.colorScheme.primaryContainer
            flash -> MaterialTheme.colorScheme.secondaryContainer
            else -> Color.Transparent
        },
        label = "verseBg",
    )
    // Verse numbers in the church red, bold and inline so they read clearly.
    val numColor = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onBackground

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 5.dp)
    ) {
        when (lang) {
            Lang.TA -> Text(
                numbered(verse.num, verse.ta, numColor, fontSize),
                fontFamily = TamilFont, fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.75f).sp, color = ink,
            )
            Lang.EN -> Text(
                numbered(verse.num, verse.en, numColor, fontSize),
                fontFamily = EnglishSerif, fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.6f).sp, color = ink,
            )
            Lang.BOTH -> {
                Text(
                    numbered(verse.num, verse.ta, numColor, fontSize),
                    fontFamily = TamilFont, fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.72f).sp, color = ink,
                )
                Text(
                    verse.en,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                    fontFamily = EnglishSerif, fontSize = (fontSize * 0.84f).sp,
                    lineHeight = (fontSize * 0.84f * 1.55f).sp, color = muted,
                )
            }
        }
    }
}

private fun numbered(num: Int, text: String, numColor: Color, fontSize: Float): AnnotatedString =
    buildAnnotatedString {
        withStyle(
            SpanStyle(
                color = numColor,
                fontFamily = TamilFont,
                fontWeight = FontWeight.Bold,
                fontSize = (fontSize * 0.82f).sp,
            )
        ) { append(num.toString()) }
        append("\u2002")
        append(text)
    }

private fun shareText(book: Book, chapter: Int, verses: List<Verse>, lang: Lang): String {
    if (verses.isEmpty()) return ""
    val range = verseRange(verses.map { it.num })
    return buildString {
        when (lang) {
            Lang.TA -> {
                verses.forEach { append("${it.num} ${it.ta}\n") }
                append("— ${book.ta} $chapter:$range")
            }
            Lang.EN -> {
                verses.forEach { append("${it.num} ${it.en}\n") }
                append("— ${book.en} $chapter:$range (KJV)")
            }
            Lang.BOTH -> {
                verses.forEach { append("${it.num} ${it.ta}\n${it.en}\n\n") }
                append("— ${book.ta} / ${book.en} $chapter:$range")
            }
        }
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun SettingsSheet(vm: BibleViewModel) {
    Column(Modifier.padding(bottom = 16.dp)) { ReadingSettings(vm, showLanguage = false) }
}
