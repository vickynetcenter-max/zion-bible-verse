package com.vicky.tamilbible.ui
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.border
import com.vicky.tamilbible.data.HighlightColors
import com.vicky.tamilbible.R
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Edit
import androidx.compose.foundation.layout.size
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility

import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.ThemeMode
import com.vicky.tamilbible.data.Verse
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    vm: BibleViewModel,
    pagerState: PagerState,
    onOpenBooks: () -> Unit,
    onOpenSearch: () -> Unit,
    onHome: () -> Unit,
    onAddNote: (ref: String, text: String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val lang = vm.lang
    val currentPage = pagerState.currentPage
    val (book, chapter) = vm.refOf(currentPage)

    var selected by remember { mutableStateOf(emptySet<Int>()) }
    var showSettings by remember { mutableStateOf(false) }

    // Remember position and drop verse selection whenever the chapter changes.
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect {
            selected = emptySet()
            vm.savePage(it)
        }
    }

    // Jumps coming from the book list or search.
    val jump = vm.jump
    LaunchedEffect(jump) {
        if (jump != null) {
            pagerState.scrollToPage(jump.page)
            if (jump.verse == null) vm.consumeJump(jump)
        }
    }

    val currentVerses by produceState(emptyList<Verse>(), currentPage) {
        value = vm.versesFor(currentPage)
    }

    Scaffold(
        modifier = Modifier.pageBackground(),
        containerColor = Color.Transparent,
        topBar = {
            Column {
                ReaderTopBar(
                    book = book, chapter = chapter, lang = lang,
                    onTitle = onOpenBooks, onSearch = onOpenSearch, onHome = onHome,
                    onSettings = { showSettings = true },
                )
                ChapterStrip(book, chapter) { n -> vm.goTo(book.ord, n) }
            }
        },
        bottomBar = {
            ReaderBottomBar(
                lang = lang,
                canPrev = currentPage > 0,
                canNext = currentPage < vm.totalPages - 1,
                onPrev = { scope.launch { pagerState.animateScrollToPage(currentPage - 1) } },
                onNext = { scope.launch { pagerState.animateScrollToPage(currentPage + 1) } },
                onLang = vm::updateLang,
            )
        },
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(inner)) {
            HorizontalPager(
                state = pagerState,
                key = { it },
                beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxSize(),
            ) { page ->
                ChapterPage(
                    vm = vm,
                    page = page,
                    selected = if (page == currentPage) selected else emptySet(),
                    onToggle = { n -> selected = if (n in selected) selected - n else selected + n },
                )
            }

            // Small action panel on the right: appears only while verses are selected — slides
            // down from the top, and goes back up when ✕ is tapped (or the selection is cleared).
            val context = LocalContext.current
            val clipboard = LocalClipboardManager.current
            var lastCount by remember { mutableStateOf(0) }
            if (selected.isNotEmpty()) lastCount = selected.size
            AnimatedVisibility(
                visible = selected.isNotEmpty(),
                enter = slideInVertically(tween(300)) { -it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(260)) { -it } + fadeOut(tween(200)),
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp),
            ) {
                val picked = currentVerses.filter { it.num in selected }
                val text = shareText(book, chapter, picked, lang)
                SelectionPanel(
                    count = lastCount,
                    lang = lang,
                    allBookmarked = selected.isNotEmpty() && selected.all { vm.markOf(book.ord, chapter, it)?.bookmark == true },
                    onHighlight = { color ->
                        vm.setHighlight(book.ord, chapter, selected, color)
                        selected = emptySet()
                    },
                    onBookmark = {
                        vm.toggleBookmark(book.ord, chapter, selected)
                        selected = emptySet()
                    },
                    onNote = {
                        val ref = "${book.displayName(lang)} $chapter:${verseRange(picked.map { it.num })}"
                        val body = picked.joinToString("\n") { "${it.num} ${if (lang == Lang.EN) it.en else it.ta}" }
                        selected = emptySet()
                        onAddNote(ref, body)
                    },
                    onCopy = {
                        clipboard.setText(AnnotatedString(text))
                        selected = emptySet()
                    },
                    onShare = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, null))
                        selected = emptySet()
                    },
                    onClose = { selected = emptySet() },
                )
            }
        }
    }

    if (showSettings) {
        ModalBottomSheet(
            onDismissRequest = { showSettings = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            SettingsSheet(vm)
        }
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun ReaderTopBar(
    book: Book, chapter: Int, lang: Lang,
    onTitle: () -> Unit, onSearch: () -> Unit, onSettings: () -> Unit, onHome: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(60.dp).padding(start = 4.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onHome) {
                    Icon(Icons.Filled.Home, contentDescription = lang.ui("முகப்பு", "Home"))
                }
                Row(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onTitle)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f, fill = false)) {
                        Text(
                            "${book.displayName(lang)} $chapter",
                            fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 19.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        if (lang == Lang.BOTH) {
                            Text(
                                "${book.en} $chapter",
                                fontSize = 12.sp,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Icon(
                        Icons.Filled.ArrowDropDown,
                        contentDescription = lang.ui("புத்தகம் தேர்வு", "Choose book"),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
                IconButton(onClick = onSearch) {
                    Icon(Icons.Filled.Search, contentDescription = lang.ui("தேடல்", "Search"))
                }
                IconButton(onClick = onSettings) {
                    Text(
                        "Aa",
                        fontFamily = EnglishSerif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderBottomBar(
    lang: Lang, canPrev: Boolean, canNext: Boolean,
    onPrev: () -> Unit, onNext: () -> Unit, onLang: (Lang) -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
        Column {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onPrev, enabled = canPrev) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = lang.ui("முந்தைய அதிகாரம்", "Previous chapter"),
                    )
                }
                val options = listOf(
                    Lang.TA to "தமிழ்",
                    Lang.EN to "English",
                    Lang.BOTH to lang.ui("இரண்டும்", "Both"),
                )
                SingleChoiceSegmentedButtonRow(Modifier.weight(1f)) {
                    options.forEachIndexed { i, (value, label) ->
                        SegmentedButton(
                            selected = lang == value,
                            onClick = { onLang(value) },
                            shape = SegmentedButtonDefaults.itemShape(i, options.size),
                            icon = {},
                            colors = SegmentedButtonDefaults.colors(
                                activeContainerColor = MaterialTheme.colorScheme.primary,
                                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                                activeBorderColor = MaterialTheme.colorScheme.primary,
                                inactiveContainerColor = Color.Transparent,
                                inactiveBorderColor = MaterialTheme.colorScheme.outline,
                            ),
                        ) {
                            Text(label, fontSize = 13.sp, maxLines = 1, softWrap = false)
                        }
                    }
                }
                IconButton(onClick = onNext, enabled = canNext) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = lang.ui("அடுத்த அதிகாரம்", "Next chapter"),
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectionPanel(
    count: Int, lang: Lang, allBookmarked: Boolean,
    onHighlight: (Int?) -> Unit, onBookmark: () -> Unit,
    onNote: () -> Unit, onCopy: () -> Unit, onShare: () -> Unit, onClose: () -> Unit,
) {
    var showColors by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.Top) {
        // Colour palette slides out to the left of the pill.
        AnimatedVisibility(
            visible = showColors,
            enter = fadeIn(tween(150)) + androidx.compose.animation.expandHorizontally(expandFrom = Alignment.End),
            exit = fadeOut(tween(120)) + androidx.compose.animation.shrinkHorizontally(shrinkTowards = Alignment.End),
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp,
                modifier = Modifier.padding(end = 8.dp, top = 96.dp),
            ) {
                Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HighlightColors.ARGB.indices.forEach { i ->
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(Color(HighlightColors.ARGB[i]))
                                .border(1.dp, Color.Black.copy(alpha = 0.12f), CircleShape)
                                .clickable { showColors = false; onHighlight(i) },
                        )
                    }
                    // Remove highlight
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            .clickable { showColors = false; onHighlight(null) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Close, "Remove colour", Modifier.size(18.dp)) }
                }
            }
        }
        // Narrow vertical pill: count on top, the actions, ✕ last.
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shadowElevation = 8.dp,
            modifier = Modifier.width(64.dp),
        ) {
            Column(
                Modifier.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onPrimary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Text("selected", fontSize = 9.sp)
                HorizontalDivider(Modifier.width(36.dp).padding(vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.3f))
                PanelAction("Colour", painterResource(R.drawable.ic_highlight)) { showColors = !showColors }
                PanelAction(
                    if (allBookmarked) "Unmark" else "Bookmark",
                    painterResource(if (allBookmarked) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border),
                    onBookmark,
                )
                PanelAction("Note", rememberVectorPainter(Icons.Filled.Edit), onNote)
                PanelAction("Copy", rememberVectorPainter(Icons.Filled.Done), onCopy)
                PanelAction("Share", rememberVectorPainter(Icons.Filled.Share), onShare)
                HorizontalDivider(Modifier.width(36.dp).padding(vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.3f))
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun PanelAction(label: String, icon: androidx.compose.ui.graphics.painter.Painter, onClick: () -> Unit) {
    Column(
        Modifier.width(56.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(20.dp))
        Text(label, fontSize = 10.sp, maxLines = 1)
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun ChapterPage(
    vm: BibleViewModel,
    page: Int,
    selected: Set<Int>,
    onToggle: (Int) -> Unit,
) {
    val (book, chapter) = vm.refOf(page)
    val verses by produceState<List<Verse>?>(null, page, vm.textVersion) { value = vm.versesFor(page) }
    val listState = rememberLazyListState()
    var flashVerse by remember { mutableStateOf<Int?>(null) }

    val jump = vm.jump
    LaunchedEffect(jump, verses) {
        val list = verses
        if (jump != null && jump.page == page && jump.verse != null && list != null) {
            val index = list.indexOfFirst { it.num == jump.verse }.coerceAtLeast(0) + 1 // +1 for header
            listState.scrollToItem(index)
            flashVerse = jump.verse
            vm.consumeJump(jump)
        }
    }
    LaunchedEffect(flashVerse) {
        if (flashVerse != null) { delay(2400); flashVerse = null }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        val list = verses ?: return@Box
        LazyColumn(
            state = listState,
            modifier = Modifier.widthIn(max = 680.dp).fillMaxHeight(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 48.dp),
        ) {
            item(key = "header") { ChapterHeader(book, chapter, vm.lang) }
            items(list, key = { it.num }) { v ->
                val mark = vm.markOf(book.ord, chapter, v.num)
                VerseItem(
                    verse = v,
                    lang = vm.lang,
                    fontSize = vm.fontSize,
                    selected = v.num in selected,
                    flash = v.num == flashVerse,
                    highlight = mark?.color,
                    bookmarked = mark?.bookmark == true,
                    onClick = { onToggle(v.num) },
                )
            }
        }
    }
}

@Composable
private fun ChapterHeader(book: Book, chapter: Int, lang: Lang) {
    Column(Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, bottom = 22.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "$chapter",
                fontFamily = EnglishSerif,
                fontWeight = FontWeight.Normal,
                fontSize = 68.sp,
                lineHeight = 68.sp,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.padding(bottom = 8.dp)) {
                Text(
                    book.displayName(lang),
                    fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp,
                    lineHeight = 30.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                book.secondaryName(lang)?.let {
                    Text(
                        it,
                        fontFamily = if (lang == Lang.EN) TamilFont else EnglishSerif,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.width(44.dp).height(2.dp).background(MaterialTheme.colorScheme.secondary)
        )
    }
}

@Composable
private fun VerseItem(
    verse: Verse, lang: Lang, fontSize: Float,
    selected: Boolean, flash: Boolean, highlight: Int?, bookmarked: Boolean, onClick: () -> Unit,
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bg by animateColorAsState(
        when {
            selected -> MaterialTheme.colorScheme.primaryContainer
            flash -> MaterialTheme.colorScheme.secondaryContainer
            highlight != null -> highlightColor(highlight, dark)
            else -> Color.Transparent
        },
        label = "verseBg",
    )
    // Verse numbers in the church red, bold and inline so they read clearly.
    val numColor = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onBackground

    Box(Modifier.fillMaxWidth()) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(start = 6.dp, top = 5.dp, bottom = 5.dp, end = if (bookmarked) 24.dp else 6.dp)
    ) {
        when (lang) {
            Lang.TA -> Text(
                numbered(verse.num, verse.ta, numColor, fontSize),
                fontFamily = TamilFont, fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.75f).sp, color = ink,
            )
            Lang.EN -> Text(
                numbered(verse.num, verse.en, numColor, fontSize),
                fontFamily = EnglishSerif, fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.6f).sp, color = ink,
            )
            Lang.BOTH -> {
                Text(
                    numbered(verse.num, verse.ta, numColor, fontSize),
                    fontFamily = TamilFont, fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.72f).sp, color = ink,
                )
                Text(
                    verse.en,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                    fontFamily = EnglishSerif, fontSize = (fontSize * 0.84f).sp,
                    lineHeight = (fontSize * 0.84f * 1.55f).sp, color = muted,
                )
            }
        }
    }
    if (bookmarked) {
        Icon(
            painterResource(R.drawable.ic_bookmark), contentDescription = "Bookmark",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 2.dp).size(18.dp),
        )
    }
    }
}

private fun numbered(num: Int, text: String, numColor: Color, fontSize: Float): AnnotatedString =
    buildAnnotatedString {
        withStyle(
            SpanStyle(
                color = numColor,
                fontFamily = TamilFont,
                fontWeight = FontWeight.Bold,
                fontSize = (fontSize * 0.82f).sp,
            )
        ) { append(num.toString()) }
        append("\u2002")
        append(text)
    }

private fun shareText(book: Book, chapter: Int, verses: List<Verse>, lang: Lang): String {
    if (verses.isEmpty()) return ""
    val range = verseRange(verses.map { it.num })
    return buildString {
        when (lang) {
            Lang.TA -> {
                verses.forEach { append("${it.num} ${it.ta}\n") }
                append("— ${book.ta} $chapter:$range")
            }
            Lang.EN -> {
                verses.forEach { append("${it.num} ${it.en}\n") }
                append("— ${book.en} $chapter:$range (KJV)")
            }
            Lang.BOTH -> {
                verses.forEach { append("${it.num} ${it.ta}\n${it.en}\n\n") }
                append("— ${book.ta} / ${book.en} $chapter:$range")
            }
        }
    }
}

// ---------------------------------------------------------------------------------------

@Composable
private fun SettingsSheet(vm: BibleViewModel) {
    Column(Modifier.padding(bottom = 16.dp)) { ReadingSettings(vm, showLanguage = false) }
}
