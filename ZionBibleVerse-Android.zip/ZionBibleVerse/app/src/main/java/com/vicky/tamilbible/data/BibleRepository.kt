package com.vicky.tamilbible.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads the pre-built bible.db shipped in assets.
 * The file is copied to the app's database folder on first launch
 * (and again whenever DB_VERSION is bumped).
 */
class BibleRepository(private val context: Context) {

    private val db: SQLiteDatabase by lazy { openDb() }

    init {
        // Admin corrections saved from the last sync, so they show even offline.
        if (!correctionsLoaded) { Corrections.load(RemoteCache.load(context).corrections); correctionsLoaded = true }
    }

    private fun openDb(): SQLiteDatabase {
        val file = context.getDatabasePath(DB_NAME)
        val prefs = context.getSharedPreferences("db_meta", Context.MODE_PRIVATE)
        if (!file.exists() || prefs.getInt("version", 0) != DB_VERSION) {
            file.parentFile?.mkdirs()
            context.assets.open(DB_NAME).use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            prefs.edit().putInt("version", DB_VERSION).apply()
        }
        return SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
    }

    /** A search/random hit with any admin correction applied. */
    private fun hit(b: Int, c: Int, v: Int, ta: String, en: String) =
        SearchHit(b, c, v, Corrections.ta(b, c, v, ta), Corrections.en(b, c, v, en))

    suspend fun books(): List<Book> = withContext(Dispatchers.IO) {
        db.rawQuery(
            "SELECT ord, code, ta, en, testament, chapters FROM books ORDER BY ord", null
        ).use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(Book(c.getInt(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5)))
                }
            }
        }
    }

    suspend fun chapter(book: Int, chapter: Int): List<Verse> = withContext(Dispatchers.IO) {
        db.rawQuery(
            "SELECT verse, ta, en FROM verses WHERE book = ? AND chapter = ? ORDER BY verse",
            arrayOf(book.toString(), chapter.toString())
        ).use { c ->
            buildList {
                while (c.moveToNext()) add(Verse(c.getInt(0), Corrections.ta(book, chapter, c.getInt(0), c.getString(1)), Corrections.en(book, chapter, c.getInt(0), c.getString(2))))
            }
        }
    }

    /** [n] random verses from the whole Bible (for the quiz). */
    suspend fun randomVerses(n: Int): List<SearchHit> = withContext(Dispatchers.IO) {
        db.rawQuery("SELECT book, chapter, verse, ta, en FROM verses ORDER BY RANDOM() LIMIT ?", arrayOf(n.toString())).use { c ->
            buildList { while (c.moveToNext()) add(hit(c.getInt(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4))) }
        }
    }

    /** One verse together with its book, e.g. for the verse of the day. */
    suspend fun verseWithBook(book: Int, chapter: Int, verse: Int): Pair<Book, Verse>? =
        withContext(Dispatchers.IO) {
            db.rawQuery(
                "SELECT b.ord, b.code, b.ta, b.en, b.testament, b.chapters, v.verse, v.ta, v.en " +
                    "FROM verses v JOIN books b ON b.ord = v.book " +
                    "WHERE v.book = ? AND v.chapter = ? AND v.verse = ?",
                arrayOf(book.toString(), chapter.toString(), verse.toString())
            ).use { c ->
                if (!c.moveToFirst()) null
                else Book(c.getInt(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5)) to
                    Verse(c.getInt(6), Corrections.ta(book, chapter, verse, c.getString(7)), Corrections.en(book, chapter, verse, c.getString(8)))
            }
        }

    /** [testament] "OT"/"NT" or null for all; [book] a book ord or null for all books. */
    suspend fun search(query: String, lang: Lang, testament: String? = null, book: Int? = null, limit: Int = 300): List<SearchHit> =
        withContext(Dispatchers.IO) {
            val escaped = query.trim()
                .replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            val like = "%$escaped%"
            val where = when (lang) {
                Lang.TA -> "ta LIKE ? ESCAPE '\\'"
                Lang.EN -> "en LIKE ? ESCAPE '\\'"
                Lang.BOTH -> "(ta LIKE ? ESCAPE '\\' OR en LIKE ? ESCAPE '\\')"
            }
            var args = if (lang == Lang.BOTH) arrayOf(like, like) else arrayOf(like)
            var scope = ""
            if (book != null) { scope = " AND book = ?"; args += book.toString() }
            else if (testament == "OT") scope = " AND book <= 39"
            else if (testament == "NT") scope = " AND book >= 40"
            db.rawQuery(
                "SELECT book, chapter, verse, ta, en FROM verses WHERE $where$scope " +
                    "ORDER BY book, chapter, verse LIMIT $limit",
                args
            ).use { c ->
                buildList {
                    while (c.moveToNext()) {
                        add(hit(c.getInt(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4)))
                    }
                }
            }
        }

    companion object {
        const val DB_NAME = "bible.db"
        const val DB_VERSION = 1
        @Volatile private var correctionsLoaded = false
    }
}
