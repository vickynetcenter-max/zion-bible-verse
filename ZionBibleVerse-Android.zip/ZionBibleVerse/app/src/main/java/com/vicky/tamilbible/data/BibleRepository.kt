package com.vicky.tamilbible.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads the pre-built bible.db shipped in assets.
 * The file is copied to the app's database folder on first launch
 * (and again whenever DB_VERSION is bumped).
 */
class BibleRepository(private val context: Context) {

    private val db: SQLiteDatabase by lazy { openDb() }

    private fun openDb(): SQLiteDatabase {
        val file = context.getDatabasePath(DB_NAME)
        val prefs = context.getSharedPreferences("db_meta", Context.MODE_PRIVATE)
        if (!file.exists() || prefs.getInt("version", 0) != DB_VERSION) {
            file.parentFile?.mkdirs()
            context.assets.open(DB_NAME).use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            prefs.edit().putInt("version", DB_VERSION).apply()
        }
        return SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
    }

    suspend fun books(): List<Book> = withContext(Dispatchers.IO) {
        db.rawQuery(
            "SELECT ord, code, ta, en, testament, chapters FROM books ORDER BY ord", null
        ).use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(Book(c.getInt(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5)))
                }
            }
        }
    }

    suspend fun chapter(book: Int, chapter: Int): List<Verse> = withContext(Dispatchers.IO) {
        db.rawQuery(
            "SELECT verse, ta, en FROM verses WHERE book = ? AND chapter = ? ORDER BY verse",
            arrayOf(book.toString(), chapter.toString())
        ).use { c ->
            buildList {
                while (c.moveToNext()) add(Verse(c.getInt(0), c.getString(1), c.getString(2)))
            }
        }
    }

    suspend fun search(query: String, lang: Lang, limit: Int = 300): List<SearchHit> =
        withContext(Dispatchers.IO) {
            val escaped = query.trim()
                .replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            val like = "%$escaped%"
            val where = when (lang) {
                Lang.TA -> "ta LIKE ? ESCAPE '\\'"
                Lang.EN -> "en LIKE ? ESCAPE '\\'"
                Lang.BOTH -> "(ta LIKE ? ESCAPE '\\' OR en LIKE ? ESCAPE '\\')"
            }
            val args = if (lang == Lang.BOTH) arrayOf(like, like) else arrayOf(like)
            db.rawQuery(
                "SELECT book, chapter, verse, ta, en FROM verses WHERE $where " +
                    "ORDER BY book, chapter, verse LIMIT $limit",
                args
            ).use { c ->
                buildList {
                    while (c.moveToNext()) {
                        add(SearchHit(c.getInt(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4)))
                    }
                }
            }
        }

    companion object {
        const val DB_NAME = "bible.db"
        const val DB_VERSION = 1
    }
}
