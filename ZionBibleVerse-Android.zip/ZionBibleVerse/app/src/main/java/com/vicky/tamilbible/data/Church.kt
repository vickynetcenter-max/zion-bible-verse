package com.vicky.tamilbible.data

/** Zion Cathedral details shown on the dashboard, social and settings screens. */
object Church {
    const val NAME_TA = "சீயோன் பேராலயம்"
    const val NAME_EN = "Zion Cathedral"
    const val PLACE_TA = "ஜெகநாதபுரம், நாகப்பட்டினம்"
    const val PLACE_EN = "Jeganathapuram, Nagapattinam"
    const val PASTOR_TA = "Rev. Dr. ஆர்தர் செல்லராஜா"
    const val PASTOR_EN = "Rev. Dr. Arthur Sellaraja"
    val PRAYER_PHONES = listOf("7373839093", "7373835943")

    const val INSTAGRAM_HANDLE = "zioncathedral_off"
    const val INSTAGRAM_URL = "https://www.instagram.com/zioncathedral_off"
    const val FACEBOOK_HANDLE = "zioncathedral_in"
    const val FACEBOOK_URL = "https://www.facebook.com/zioncathedral_in"
    const val YOUTUBE_NAME = "Zion Cathedral"
    // TODO: replace with the exact channel link (e.g. https://www.youtube.com/@handle) once known.
    const val YOUTUBE_URL = "https://www.youtube.com/results?search_query=Zion+Cathedral+Nagapattinam"
}
