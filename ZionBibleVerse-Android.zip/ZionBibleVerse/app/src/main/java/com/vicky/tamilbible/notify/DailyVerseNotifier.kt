package com.vicky.tamilbible.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.MainActivity
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.DailyVerse
import com.vicky.tamilbible.data.Lang
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import kotlin.random.Random

/**
 * "இன்றைய தேவ வார்த்தை" notification: the day's promise verse, repeated up to [MAX_PER_DAY]
 * times a day at random times between [START_HOUR]:00 and [END_HOUR]:00. Every one is the
 * same notification (same title, same verse, same id), and the verse changes at midnight.
 * Times come from the date plus a per-install seed, so they stay stable when rescheduled
 * but differ from phone to phone.
 */
object DailyVerseNotifier {
    const val MAX_PER_DAY = 15
    private const val START_HOUR = 6
    private const val END_HOUR = 22
    private const val CHANNEL_ID = "daily_verse"
    private const val NOTIFICATION_ID = 7001
    const val ACTION_SHOW = "com.vicky.zionbibleverse.SHOW_DAILY_VERSE"
    private const val EXTRA_DAY = "day"
    private const val EXTRA_SLOT = "slot"

    const val EXTRA_BOOK = "open_book"
    const val EXTRA_CHAPTER = "open_chapter"
    const val EXTRA_VERSE = "open_verse"

    private fun prefs(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = prefs(c).getBoolean("notify_on", true)
    fun perDay(c: Context) = prefs(c).getInt("notify_count", MAX_PER_DAY).coerceIn(1, MAX_PER_DAY)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("notify_on", on).apply(); schedule(c)
    }

    fun setPerDay(c: Context, n: Int) {
        prefs(c).edit().putInt("notify_count", n.coerceIn(1, MAX_PER_DAY)).apply(); schedule(c)
    }

    private fun seed(c: Context): Long {
        val p = prefs(c)
        if (!p.contains("notify_seed")) p.edit().putLong("notify_seed", Random.nextLong()).apply()
        return p.getLong("notify_seed", 0L)
    }

    /** Random time (epoch millis) for each slot of [day]: one per equal share of the window. */
    private fun slotTimes(c: Context, day: LocalDate): List<Long> {
        val n = perDay(c)
        val rnd = Random(seed(c) xor (day.toEpochDay() * 1_000_003L))
        val windowSec = (END_HOUR - START_HOUR) * 3600
        val share = windowSec / n
        val start = day.atTime(START_HOUR, 0).atZone(ZoneId.systemDefault()).toEpochSecond()
        return List(n) { i -> (start + i * share + rnd.nextInt((share * 0.8).toInt().coerceAtLeast(1))) * 1000 }
    }

    private fun alarmIntent(c: Context, day: LocalDate? = null, slot: Int = 0): PendingIntent {
        val i = Intent(c, DailyVerseReceiver::class.java).setAction(ACTION_SHOW)
        if (day != null) i.putExtra(EXTRA_DAY, day.toEpochDay()).putExtra(EXTRA_SLOT, slot)
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Arms the next upcoming slot (today or tomorrow), or cancels when turned off. Safe to call often. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmIntent(c))
        if (!isEnabled(c)) return
        val now = System.currentTimeMillis()
        val today = LocalDate.now()
        for (day in listOf(today, today.plusDays(1))) {
            slotTimes(c, day).forEachIndexed { slot, at ->
                if (at > now) {
                    // Inexact but Doze-friendly; needs no exact-alarm permission.
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(c, day, slot))
                    return
                }
            }
        }
    }

    fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "இன்றைய தேவ வார்த்தை", NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = "Promise verses through the day" }
        )
    }

    suspend fun show(c: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val day = if (intent.hasExtra(EXTRA_DAY)) LocalDate.ofEpochDay(intent.getLongExtra(EXTRA_DAY, 0)) else LocalDate.now()
        // A late alarm from yesterday should not show yesterday's verse.
        if (day != LocalDate.now()) return

        val ref = DailyVerse.refFor(day)
        val (book, verse) = BibleRepository(c).verseWithBook(ref[0], ref[1], ref[2]) ?: return
        val lang = runCatching { Lang.valueOf(prefs(c).getString("lang", "TA")!!) }.getOrDefault(Lang.TA)
        val body = when (lang) {
            Lang.TA -> verse.ta
            Lang.EN -> verse.en
            Lang.BOTH -> "${verse.ta}\n\n${verse.en}"
        }
        val refText = if (lang == Lang.EN) "${book.en} ${ref[1]}:${ref[2]}" else "${book.ta} ${ref[1]}:${ref[2]}"
        val title = if (lang == Lang.EN) "Today's Word" else "இன்றைய தேவ வார்த்தை"

        val open = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_BOOK, ref[0]).putExtra(EXTRA_CHAPTER, ref[1]).putExtra(EXTRA_VERSE, ref[2]),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        createChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setSubText(refText)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n— $refText"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        // Same id: each new verse replaces the previous one instead of piling up.
        NotificationManagerCompat.from(c).notify(NOTIFICATION_ID, n)
    }
}

/** Shows the verse for the fired slot, then arms the next one; also re-arms after reboot/update/clock changes. */
class DailyVerseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action == DailyVerseNotifier.ACTION_SHOW) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    DailyVerseNotifier.show(app, intent)
                } finally {
                    DailyVerseNotifier.schedule(app)
                    pending.finish()
                }
            }
        } else {
            DailyVerseNotifier.schedule(app)
        }
    }
}
