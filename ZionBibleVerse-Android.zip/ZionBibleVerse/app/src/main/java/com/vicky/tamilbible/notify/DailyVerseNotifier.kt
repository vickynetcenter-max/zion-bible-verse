package com.vicky.tamilbible.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.MainActivity
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.DailyVerse
import com.vicky.tamilbible.data.Lang
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Daily "இன்றைய தேவ வார்த்தை" notification: scheduling, channel and posting. */
object DailyVerseNotifier {
    private const val CHANNEL_ID = "daily_verse"
    private const val NOTIFICATION_ID = 7001
    const val ACTION_SHOW = "com.vicky.zionbibleverse.SHOW_DAILY_VERSE"

    const val EXTRA_BOOK = "open_book"
    const val EXTRA_CHAPTER = "open_chapter"
    const val EXTRA_VERSE = "open_verse"

    private fun prefs(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = prefs(c).getBoolean("notify_on", true)
    fun hour(c: Context) = prefs(c).getInt("notify_hour", 6)
    fun minute(c: Context) = prefs(c).getInt("notify_min", 0)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("notify_on", on).apply()
        schedule(c)
    }

    fun setTime(c: Context, hour: Int, minute: Int) {
        prefs(c).edit().putInt("notify_hour", hour).putInt("notify_min", minute).apply()
        schedule(c)
    }

    private fun alarmIntent(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 0,
        Intent(c, DailyVerseReceiver::class.java).setAction(ACTION_SHOW),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    /** (Re)arms the next alarm, or cancels it when turned off. Safe to call often. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        val pi = alarmIntent(c)
        am.cancel(pi)
        if (!isEnabled(c)) return
        val now = LocalDateTime.now()
        var next = LocalDateTime.of(LocalDate.now(), LocalTime.of(hour(c), minute(c)))
        if (!next.isAfter(now)) next = next.plusDays(1)
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        // Inexact but Doze-friendly; needs no exact-alarm permission.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "இன்றைய தேவ வார்த்தை", NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = "Daily Bible verse" }
        )
    }

    suspend fun show(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val ref = DailyVerse.refFor()
        val (book, verse) = BibleRepository(c).verseWithBook(ref[0], ref[1], ref[2]) ?: return
        val lang = runCatching { Lang.valueOf(prefs(c).getString("lang", "TA")!!) }.getOrDefault(Lang.TA)
        val body = when (lang) {
            Lang.TA -> verse.ta
            Lang.EN -> verse.en
            Lang.BOTH -> "${verse.ta}\n\n${verse.en}"
        }
        val refText = when (lang) {
            Lang.EN -> "${book.en} ${ref[1]}:${ref[2]}"
            else -> "${book.ta} ${ref[1]}:${ref[2]}"
        }
        val title = if (lang == Lang.EN) "Today's Word" else "இன்றைய தேவ வார்த்தை"

        val open = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_BOOK, ref[0]).putExtra(EXTRA_CHAPTER, ref[1]).putExtra(EXTRA_VERSE, ref[2]),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        createChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setSubText(refText)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n— $refText"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(c).notify(NOTIFICATION_ID, n)
    }
}

/** Fires the daily notification and re-arms after reboot, app update or clock changes. */
class DailyVerseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action == DailyVerseNotifier.ACTION_SHOW) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    DailyVerseNotifier.show(app)
                } finally {
                    DailyVerseNotifier.schedule(app)
                    pending.finish()
                }
            }
        } else {
            DailyVerseNotifier.schedule(app)
        }
    }
}
