package com.vicky.tamilbible.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.MainActivity
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.DailyVerse
import com.vicky.tamilbible.data.Lang
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/**
 * "இன்றைய தேவ வார்த்தை" notification: the day's promise verse, 5 times a day at fixed times —
 * 6 AM, 10 AM, 12 noon, 4 PM and 8 PM ([TIMES]). Every one is the same notification (same
 * title, same verse, same id), and the verse changes at midnight.
 */
object DailyVerseNotifier {
    /** Fixed notification times (hour, minute). */
    private val TIMES = listOf(6 to 0, 10 to 0, 12 to 0, 16 to 0, 20 to 0)
    val PER_DAY get() = TIMES.size
    // New channel id: channel sound/importance can't be changed after creation, so the old
    // (silent on some phones) "daily_verse" channel is deleted and replaced by this one.
    private const val CHANNEL_ID = "daily_verse_sound"
    private const val OLD_CHANNEL_ID = "daily_verse"
    private const val NOTIFICATION_ID = 7001
    const val ACTION_SHOW = "com.vicky.zionbibleverse.SHOW_DAILY_VERSE"
    private const val EXTRA_DAY = "day"
    private const val EXTRA_SLOT = "slot"

    const val EXTRA_BOOK = "open_book"
    const val EXTRA_CHAPTER = "open_chapter"
    const val EXTRA_VERSE = "open_verse"

    private fun prefs(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    /** Always on, 5 a day at fixed times — no user controls by design. */
    fun perDay(@Suppress("UNUSED_PARAMETER") c: Context) = PER_DAY


    /** Notification times (epoch millis) for [day]. */
    private fun slotTimes(@Suppress("UNUSED_PARAMETER") c: Context, day: LocalDate): List<Long> =
        TIMES.map { (h, m) -> day.atTime(h, m).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }

    private fun alarmIntent(c: Context, day: LocalDate? = null, slot: Int = 0): PendingIntent {
        val i = Intent(c, DailyVerseReceiver::class.java).setAction(ACTION_SHOW)
        if (day != null) i.putExtra(EXTRA_DAY, day.toEpochDay()).putExtra(EXTRA_SLOT, slot)
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Arms the next upcoming slot (today or tomorrow), or cancels when turned off. Safe to call often. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmIntent(c))
        val now = System.currentTimeMillis()
        val today = LocalDate.now()
        for (day in listOf(today, today.plusDays(1))) {
            slotTimes(c, day).forEachIndexed { slot, at ->
                if (at > now) {
                    // Inexact but Doze-friendly; needs no exact-alarm permission.
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(c, day, slot))
                    return
                }
            }
        }
    }

    fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.deleteNotificationChannel(OLD_CHANNEL_ID)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "இன்றைய தேவ வார்த்தை", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Today's promise verse"
                setSound(sound, attrs)
                enableVibration(true)
                enableLights(true)
            }
        )
    }

    suspend fun show(c: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val day = if (intent.hasExtra(EXTRA_DAY)) LocalDate.ofEpochDay(intent.getLongExtra(EXTRA_DAY, 0)) else LocalDate.now()
        // A late alarm from yesterday should not show yesterday's verse.
        if (day != LocalDate.now()) return

        val ref = DailyVerse.refFor(c, day)
        val (book, verse) = BibleRepository(c).verseWithBook(ref[0], ref[1], ref[2]) ?: return
        val lang = runCatching { Lang.valueOf(prefs(c).getString("lang", "TA")!!) }.getOrDefault(Lang.TA)
        val body = when (lang) {
            Lang.TA -> verse.ta
            Lang.EN -> verse.en
            Lang.BOTH -> "${verse.ta}\n\n${verse.en}"
        }
        val refText = if (lang == Lang.EN) "${book.en} ${ref[1]}:${ref[2]}" else "${book.ta} ${ref[1]}:${ref[2]}"
        val title = if (lang == Lang.EN) "Today's Word" else "இன்றைய தேவ வார்த்தை"

        val open = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_BOOK, ref[0]).putExtra(EXTRA_CHAPTER, ref[1]).putExtra(EXTRA_VERSE, ref[2]),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        createChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setSubText(refText)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n— $refText"))
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setOnlyAlertOnce(false)
            .setAutoCancel(true)
            .build()
        // Same id: each new verse replaces the previous one instead of piling up.
        NotificationManagerCompat.from(c).notify(NOTIFICATION_ID, n)
    }
}

/** Shows the verse for the fired slot, then arms the next one; also re-arms after reboot/update/clock changes. */
class DailyVerseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action == DailyVerseNotifier.ACTION_SHOW) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    DailyVerseNotifier.show(app, intent)
                } finally {
                    DailyVerseNotifier.schedule(app)
                    pending.finish()
                }
            }
        } else if (intent.action == EventReminders.ACTION_EVENT) {
            EventReminders.show(app, intent)
            EventReminders.schedule(app)
        } else {
            DailyVerseNotifier.schedule(app)
            EventReminders.schedule(app)
        }
    }
}
