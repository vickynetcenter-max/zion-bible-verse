package com.vicky.tamilbible.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont

private data class Song(val number: Int, val title: String, val youtube: String?, val lyrics: String)

/**
 * Reads assets/songs.txt: each song starts with "## <number>. <title>", an optional
 * "youtube: <link>" line, then the lyrics. Lines starting with "//" are comments.
 */
private fun loadSongs(context: Context): List<Song> {
    val lines: List<String> = runCatching { context.assets.open("songs.txt").bufferedReader().readLines() }.getOrDefault(emptyList())
    val songs = mutableListOf<Song>()
    var title: String? = null; var num = 0; var yt: String? = null
    val buf = StringBuilder()
    fun flush() {
        title?.let { songs += Song(num, it, yt, buf.toString().trim()) }
        buf.clear(); yt = null
    }
    for (raw in lines) {
        val line = raw.trimEnd()
        if (line.trimStart().startsWith("//")) continue
        if (line.startsWith("## ")) {
            flush()
            val head = line.removePrefix("## ").trim()
            val m = Regex("""^(\d+)\s*[.)]\s*(.*)$""").find(head)
            num = m?.groupValues?.get(1)?.toIntOrNull() ?: (songs.size + 1)
            title = m?.groupValues?.get(2)?.ifBlank { null } ?: head
        } else if (title != null && buf.isEmpty() && line.lowercase().startsWith("youtube:")) {
            yt = line.substringAfter(":").trim().ifBlank { null }
        } else if (title != null) {
            buf.append(line).append('\n')
        }
    }
    flush()
    return songs
}

@Composable
fun SongsScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val lang = vm.lang
    val context = LocalContext.current
    val songs = remember { loadSongs(context) }
    var filter by rememberSaveable { mutableStateOf("") }
    var openNum by rememberSaveable { mutableStateOf<Int?>(null) }
    val open = songs.firstOrNull { it.number == openNum }

    BackHandler(enabled = open != null) { openNum = null }

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (open != null) openNum = null else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("பின்செல்", "Back"))
            }
            Text(
                open?.let { "${it.number}. ${it.title}" } ?: lang.ui("பாடல்கள்", "Songs"),
                fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        when {
            open != null -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                open.youtube?.let { url ->
                    Button(
                        onClick = { openUrl(context, url) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935), contentColor = Color.White),
                    ) {
                        Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(lang.ui("YouTube-ல் கேட்க", "Listen on YouTube"), fontFamily = TamilFont)
                    }
                }
                Text(
                    open.lyrics,
                    fontFamily = TamilFont, fontSize = (vm.fontSize + 1).sp, lineHeight = ((vm.fontSize + 1) * 1.7f).sp,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }

            songs.isEmpty() -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    lang.ui("பாடல்கள் விரைவில் சேர்க்கப்படும்", "Songs will be added soon"),
                    fontFamily = TamilFont, fontSize = 16.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            else -> {
                OutlinedTextField(
                    value = filter, onValueChange = { filter = it }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    placeholder = { Text(lang.ui("பாடலைத் தேடு (பெயர் அல்லது எண்)", "Search song (title or number)"), fontFamily = TamilFont) },
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                )
                val q = filter.trim()
                val shown = if (q.isEmpty()) songs else songs.filter {
                    it.number.toString() == q || it.title.contains(q, true) || it.lyrics.contains(q, true)
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(shown, key = { it.number }) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { openNum = s.number }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${s.number}.", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 10.dp))
                            Text(s.title, fontFamily = TamilFont, fontSize = 16.sp, modifier = Modifier.weight(1f),
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (s.youtube != null) Icon(Icons.Filled.PlayArrow, null, tint = Color(0xFFE53935))
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }
    }
}
