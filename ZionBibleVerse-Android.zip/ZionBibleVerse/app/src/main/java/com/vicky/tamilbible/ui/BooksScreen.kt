package com.vicky.tamilbible.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Book
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.ui.theme.EnglishSerif
import com.vicky.tamilbible.ui.theme.TamilFont

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BooksScreen(
    vm: BibleViewModel,
    currentBookOrd: Int,
    initialTestament: String,
    onClose: () -> Unit,
    onPick: (bookOrd: Int, chapter: Int) -> Unit,
) {
    val lang = vm.lang
    val books = vm.books
    var testament by rememberSaveable { mutableStateOf(initialTestament) }
    var filter by rememberSaveable { mutableStateOf("") }
    var openBookOrd by rememberSaveable { mutableStateOf<Int?>(null) }
    val openBook = openBookOrd?.let { o -> books.firstOrNull { it.ord == o } }

    BackHandler(enabled = openBook != null) { openBookOrd = null }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()
    ) {
        // Header
        Row(
            Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { if (openBook != null) openBookOrd = null else onClose() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = lang.ui("பின்செல்", "Back"))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    openBook?.displayName(lang) ?: lang.ui("புத்தகங்கள்", "Books"),
                    fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 19.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (openBook != null) {
                    Text(
                        lang.ui("அதிகாரத்தைத் தேர்ந்தெடுக்கவும்", "Choose a chapter"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        if (openBook != null) {
            ChapterGrid(openBook, lang) { ch -> onPick(openBook.ord, ch) }
            return@Column
        }

        // Testament switch + filter
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (filter.isBlank()) {
                val tabs = listOf(
                    "OT" to lang.ui("பழைய ஏற்பாடு", "Old Testament"),
                    "NT" to lang.ui("புதிய ஏற்பாடு", "New Testament"),
                )
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    tabs.forEachIndexed { i, (key, label) ->
                        SegmentedButton(
                            selected = testament == key,
                            onClick = { testament = key },
                            shape = SegmentedButtonDefaults.itemShape(i, tabs.size),
                            icon = {},
                            colors = SegmentedButtonDefaults.colors(
                                activeContainerColor = MaterialTheme.colorScheme.primary,
                                activeContentColor = MaterialTheme.colorScheme.onPrimary,
                                activeBorderColor = MaterialTheme.colorScheme.primary,
                                inactiveContainerColor = Color.Transparent,
                                inactiveBorderColor = MaterialTheme.colorScheme.outline,
                            ),
                        ) { Text(label, fontSize = 14.sp, maxLines = 1) }
                    }
                }
            }
            OutlinedTextField(
                value = filter,
                onValueChange = { filter = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text(lang.ui("புத்தகத்தின் பெயர்", "Book name")) },
                trailingIcon = {
                    if (filter.isNotEmpty()) {
                        IconButton(onClick = { filter = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = lang.ui("அழி", "Clear"))
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            )
        }

        val q = filter.trim().lowercase()
        val shown = if (q.isEmpty()) books.filter { it.testament == testament }
        else books.filter { it.ta.contains(q) || it.en.lowercase().contains(q) || it.code.lowercase() == q }

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            if (shown.isEmpty()) {
                Text(
                    lang.ui("இந்தப் பெயரில் புத்தகம் இல்லை. வேறு எழுத்துகளை முயற்சிக்கவும்.",
                        "No book matches that name. Try fewer letters."),
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            LazyColumn(
                Modifier.widthIn(max = 680.dp).fillMaxHeight(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
            ) {
                items(shown, key = { it.ord }) { book ->
                    BookRow(book, lang, isCurrent = book.ord == currentBookOrd) { openBookOrd = book.ord }
                }
                item { Box(Modifier.navigationBarsPadding()) }
            }
        }
    }
}

@Composable
private fun BookRow(book: Book, lang: Lang, isCurrent: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isCurrent) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "${book.ord}",
            modifier = Modifier.width(34.dp),
            fontFamily = EnglishSerif,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.secondary,
        )
        Column(Modifier.weight(1f)) {
            Text(
                book.displayName(lang),
                fontFamily = if (lang == Lang.EN) EnglishSerif else TamilFont,
                fontSize = 17.sp,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onBackground,
            )
            book.secondaryName(lang)?.let {
                Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            "${book.chapters}",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ChapterGrid(book: Book, lang: Lang, onPick: (Int) -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(58.dp),
            modifier = Modifier.widthIn(max = 680.dp).fillMaxHeight(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items((1..book.chapters).toList(), key = { it }) { ch ->
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                        .clickable { onPick(ch) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$ch",
                        fontFamily = EnglishSerif,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
        }
    }
}
