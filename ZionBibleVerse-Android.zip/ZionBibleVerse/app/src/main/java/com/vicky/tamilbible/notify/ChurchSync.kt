package com.vicky.tamilbible.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vicky.tamilbible.MainActivity
import com.vicky.tamilbible.R
import com.vicky.tamilbible.data.ChurchApi
import com.vicky.tamilbible.data.RemoteCache
import com.vicky.tamilbible.data.RemoteData

/**
 * Downloads announcements + verse corrections from the church sheet, saves them on the phone
 * and shows a notification for each new announcement. Runs when the app opens and at the
 * five daily-verse times (6, 10, 12, 4, 8), so a new post reaches everyone within a few hours.
 */
object ChurchSync {
    private const val CHANNEL_ID = "church_news"
    const val EXTRA_OPEN_NEWS = "open_news"

    suspend fun sync(c: Context): RemoteData? {
        val data = ChurchApi.fetch() ?: return null
        RemoteCache.save(c, data)
        val newest = data.announcements.maxOfOrNull { it.id } ?: 0L
        val seen = RemoteCache.lastSeen(c)
        if (seen < 0) {
            // First sync on this phone: don't flood it with old posts.
            RemoteCache.setLastSeen(c, newest); RemoteCache.setLastRead(c, newest)
        } else {
            data.announcements.filter { it.id > seen }.sortedBy { it.id }.forEach {
                val pic = com.vicky.tamilbible.data.AnnouncementImages.load(c, it.image, 1024)
                notify(c, it.id, it.title, it.message, pic)
            }
            if (newest > seen) RemoteCache.setLastSeen(c, newest)
        }
        return data
    }

    private fun notify(c: Context, id: Long, title: String, message: String, picture: android.graphics.Bitmap? = null) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "சபை அறிவிப்புகள்", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Announcements from Zion Cathedral"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(true)
            }
        )
        val open = PendingIntent.getActivity(
            c, 4, Intent(c, MainActivity::class.java).putExtra(EXTRA_OPEN_NEWS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(c, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF26A1B.toInt())
            .setContentTitle(title.ifBlank { "சீயோன் பேராலயம்" })
            .setContentText(message.ifBlank { "📷 புதிய படம்" })
            .setSubText("📢 அறிவிப்பு")
            .setStyle(
                if (picture != null) NotificationCompat.BigPictureStyle().bigPicture(picture).setSummaryText(message)
                else NotificationCompat.BigTextStyle().bigText(message)
            )
            .apply { if (picture != null) setLargeIcon(picture) }
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(c).notify((8000 + id % 100000).toInt(), n)
    }
}
