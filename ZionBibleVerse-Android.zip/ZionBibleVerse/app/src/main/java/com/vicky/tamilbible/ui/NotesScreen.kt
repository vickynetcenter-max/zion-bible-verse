package com.vicky.tamilbible.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.data.Note
import com.vicky.tamilbible.data.NotesStore
import com.vicky.tamilbible.ui.theme.TamilFont
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * குறிப்புகள்: the reader's own notes — sermon notes, thoughts, or notes made from
 * selected verses in the reader (those carry the verse reference). Stored on the phone only.
 */
@Composable
fun NotesScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val lang = vm.lang
    val context = LocalContext.current
    val store = remember { NotesStore(context) }
    var notes by remember { mutableStateOf(store.all()) }
    // A draft from the reader ("குறிப்பு" on selected verses) opens straight in the editor.
    var editing by remember {
        mutableStateOf(vm.noteDraft?.let { d ->
            vm.noteDraft = null
            Note(System.currentTimeMillis(), "", d.second + "\n\n", d.first, System.currentTimeMillis())
        })
    }

    val current = editing
    if (current != null) {
        NoteEditor(
            note = current, lang = lang,
            onDone = { saved ->
                if (saved.title.isNotBlank() || saved.body.isNotBlank()) store.upsert(saved)
                notes = store.all(); editing = null
            },
            onDelete = { store.delete(current.id); notes = store.all(); editing = null },
        )
        return
    }

    Box(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("பின்செல்", "Back")) }
                Text(lang.ui("குறிப்புகள்", "Notes"), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            if (notes.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        lang.ui(
                            "இன்னும் குறிப்புகள் இல்லை.\n+ தொட்டு பிரசங்கக் குறிப்பு எழுதலாம்.\nவாசிக்கும்போது வசனங்களைத் தொட்டுத் தேர்வு செய்து \"குறிப்பு\" என்றும் சேர்க்கலாம்.",
                            "No notes yet.\nTap + to write one, or select verses in the reader and tap \"Note\".",
                        ),
                        fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 24.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(notes, key = { it.id }) { n ->
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().clickable { editing = n }) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                n.ref?.let {
                                    Text(it, fontFamily = TamilFont, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary)
                                }
                                Text(n.title.ifBlank { n.body.lineSequence().firstOrNull { l -> l.isNotBlank() } ?: "" },
                                    fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (n.title.isNotBlank() && n.body.isNotBlank()) {
                                    Text(n.body, fontFamily = TamilFont, fontSize = 14.sp, maxLines = 2,
                                        overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(SimpleDateFormat("dd MMM yyyy, h:mm a", Locale.ENGLISH).format(Date(n.updated)),
                                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { editing = Note(System.currentTimeMillis(), "", "", null, System.currentTimeMillis()) },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text(lang.ui("புதிய குறிப்பு", "New note"), fontFamily = TamilFont) },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
        )
    }
}

@Composable
private fun NoteEditor(note: Note, lang: Lang, onDone: (Note) -> Unit, onDelete: () -> Unit) {
    var title by remember { mutableStateOf(note.title) }
    var body by remember { mutableStateOf(note.body) }
    var confirmDelete by remember { mutableStateOf(false) }
    // Back (arrow or gesture) saves.
    val save = { onDone(note.copy(title = title.trim(), body = body.trimEnd(), updated = System.currentTimeMillis())) }
    BackHandler(onBack = save)

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = save) { Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("சேமி", "Save")) }
            Text(note.ref ?: lang.ui("குறிப்பு", "Note"), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, lang.ui("நீக்கு", "Delete")) }
            TextButton(onClick = save) { Text(lang.ui("சேமி", "Save"), fontFamily = TamilFont) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Column(Modifier.fillMaxSize().padding(12.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = title, onValueChange = { title = it }, singleLine = true,
                label = { Text(lang.ui("தலைப்பு", "Title"), fontFamily = TamilFont) },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = body, onValueChange = { body = it },
                label = { Text(lang.ui("குறிப்பு எழுதுங்கள்", "Write your note"), fontFamily = TamilFont) },
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = TamilFont, lineHeight = 26.sp),
                modifier = Modifier.fillMaxWidth().weight(1f),
            )
            Spacer(Modifier.height(4.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(lang.ui("இந்தக் குறிப்பை நீக்கவா?", "Delete this note?"), fontFamily = TamilFont) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(lang.ui("நீக்கு", "Delete"), fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(lang.ui("வேண்டாம்", "Cancel"), fontFamily = TamilFont) } },
        )
    }
}
