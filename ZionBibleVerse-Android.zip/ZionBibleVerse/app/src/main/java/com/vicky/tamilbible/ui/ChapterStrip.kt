package com.vicky.tamilbible.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.Book

private val ITEM = 40.dp
private val GAP = 6.dp

/**
 * Row of the current book's chapter numbers under the reader's top bar. The current chapter
 * is filled in red and kept in the middle; swipe the row sideways and tap a number to jump.
 */
@Composable
fun ChapterStrip(book: Book, chapter: Int, onPick: (Int) -> Unit) {
    val state = rememberLazyListState()
    val chapters = remember(book.ord) { (1..book.chapters).toList() }
    BoxWithConstraints(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background)) {
        // How many circles fit on screen, so the current one can be centred.
        val perScreen = (maxWidth / (ITEM + GAP)).toInt().coerceAtLeast(1)
        LaunchedEffect(book.ord, chapter) {
            state.animateScrollToItem((chapter - 1 - perScreen / 2).coerceAtLeast(0))
        }
        LazyRow(
            state = state,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(GAP),
        ) {
            items(chapters, key = { it }) { n ->
                val current = n == chapter
                Box(
                    Modifier.size(ITEM).clip(CircleShape)
                        .background(if (current) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .border(1.dp, if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { if (!current) onPick(n) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$n",
                        fontSize = 14.sp,
                        fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                        color = if (current) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
}
