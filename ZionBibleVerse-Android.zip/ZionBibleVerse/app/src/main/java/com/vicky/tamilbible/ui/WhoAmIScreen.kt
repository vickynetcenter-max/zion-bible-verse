package com.vicky.tamilbible.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.games.WhoPeople
import com.vicky.tamilbible.games.WhoPerson
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private data class WhoRound(val person: WhoPerson, val options: List<String>)

/** 🕵️ யார் இவர்? — guess the Bible person; fewer clues = more points (3 / 2 / 1). */
@Composable
fun WhoAmIScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val theme = GameThemes.WHO
    var level by remember { mutableIntStateOf(0) }
    var attempt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { level = GameStore.progress(context, Games.WHO).first().unlocked }

    GameScaffold("யார் இவர்?", theme, onBack) {
        if (level == 0) { CircularProgressIndicator(); return@GameScaffold }
        val rounds = remember(level, attempt) {
            val pool = WhoPeople.poolFor(level)
            pool.shuffled().take(WhoPeople.PER_LEVEL).map { p ->
                WhoRound(p, (pool.filter { it.name != p.name }.shuffled().take(3).map { it.name } + p.name).shuffled())
            }
        }
        var round by remember(rounds) { mutableIntStateOf(0) }
        var clues by remember(rounds, round) { mutableIntStateOf(1) }
        val wrong = remember(rounds, round) { mutableStateListOf<String>() }
        var answered by remember(rounds, round) { mutableStateOf<Boolean?>(null) }   // true = right, false = out of clues
        var score by remember(rounds) { mutableIntStateOf(0) }
        var correct by remember(rounds) { mutableIntStateOf(0) }
        var finished by remember(rounds) { mutableStateOf(false) }
        val maxScore = rounds.size * 3
        val stars = when { score >= 13 -> 3; score >= 9 -> 2; score >= 5 -> 1; else -> 0 }

        LaunchedEffect(finished) { if (finished && stars > 0) GameStore.complete(context, Games.WHO, level, stars) }
        LaunchedEffect(answered) {
            if (answered != null) {
                delay(1300)
                if (round + 1 < rounds.size) round++ else finished = true
            }
        }

        LevelRow(level, Games.LEVELS) { Text("🏆 $score / $maxScore", fontWeight = FontWeight.Bold, color = theme.start) }
        Text("நபர் ${(round + 1).coerceAtMost(rounds.size)} / ${rounds.size} · குறைந்த குறிப்பில் சொன்னால் அதிக மதிப்பெண்",
            fontFamily = TamilFont, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (finished) {
            val passed = stars > 0
            LevelResult(passed, stars, if (passed) "சரியாகக் கண்டுபிடித்தீர்கள்! 🎉" else "இன்னும் ஒரு முறை முயலுங்கள்",
                "சரியானவை $correct / ${rounds.size} · மதிப்பெண் $score / $maxScore" + if (!passed) "\nஅடுத்த நிலைக்கு 5 மதிப்பெண் தேவை" else "",
                theme, onNext = if (passed && level < Games.LEVELS) ({ level += 1 }) else null, onRetry = { attempt++ })
            return@GameScaffold
        }
        val r = rounds[round]

        // Clue cards — revealed one by one
        r.person.clues.forEachIndexed { i, clue ->
            AnimatedVisibility(visible = i < clues, enter = fadeIn() + expandVertically()) {
                Surface(shape = RoundedCornerShape(16.dp), color = theme.start.copy(alpha = 0.08f), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        NumberBadge(i + 1, theme.start)
                        Spacer(Modifier.size(12.dp))
                        Text("“$clue”", fontFamily = TamilFont, fontSize = 16.sp, lineHeight = 23.sp)
                    }
                }
            }
        }
        if (answered == null && clues < 3) {
            Text("இன்னும் ${3 - clues} குறிப்பு உண்டு · இப்போது சொன்னால் ${4 - clues} மதிப்பெண்", fontFamily = TamilFont,
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        r.options.forEach { name ->
            val isAnswer = name == r.person.name
            val bg = when {
                answered != null && isAnswer -> GAME_GREEN
                name in wrong -> GAME_RED.copy(alpha = 0.12f)
                else -> MaterialTheme.colorScheme.surface
            }
            val fg = when {
                answered != null && isAnswer -> Color.White
                name in wrong -> GAME_RED
                else -> MaterialTheme.colorScheme.onSurface
            }
            Surface(
                shape = RoundedCornerShape(16.dp), color = bg, contentColor = fg, shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth().border(1.5.dp, if (name in wrong) GAME_RED else theme.start.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(enabled = answered == null && name !in wrong) {
                        if (isAnswer) { score += 4 - clues; correct++; answered = true }
                        else {
                            wrong += name
                            if (clues < 3) clues++ else answered = false
                        }
                    },
            ) {
                Text(name, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 17.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
            }
        }
        answered?.let {
            Text(if (it) "✓ சரி! +${4 - clues}" else "சரியான பதில்: ${r.person.name}", fontFamily = TamilFont, fontWeight = FontWeight.Bold,
                color = if (it) GAME_GREEN else GAME_RED, fontSize = 16.sp)
        }
    }
}
