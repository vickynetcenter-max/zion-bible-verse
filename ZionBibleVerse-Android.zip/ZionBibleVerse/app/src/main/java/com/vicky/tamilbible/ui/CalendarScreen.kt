package com.vicky.tamilbible.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.Booking
import com.vicky.tamilbible.data.BookingsStore
import com.vicky.tamilbible.data.Lang
import com.vicky.tamilbible.notify.EventReminders
import com.vicky.tamilbible.ui.theme.TamilFont
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TA_MONTH = listOf("ஜனவரி", "பிப்ரவரி", "மார்ச்", "ஏப்ரல்", "மே", "ஜூன்", "ஜூலை",
    "ஆகஸ்ட்", "செப்டம்பர்", "அக்டோபர்", "நவம்பர்", "டிசம்பர்")
private val TA_WEEK = listOf("ஞா", "தி", "செ", "பு", "வி", "வெ", "ச")
private val EN_WEEK = listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")
private val FREE = Color(0xFF2E7D32)

private fun LocalDate.label(lang: Lang) =
    if (lang == Lang.EN) format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH))
    else "$dayOfMonth ${TA_MONTH[monthValue - 1]} $year"

private fun LocalTime.label() = format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))

/**
 * நினைவூட்டல்: the user's own booking calendar (on this phone only). Booked dates are marked in
 * red; adding a booking on a date that already has one warns so another date can be chosen.
 * Reminders fire the evening before and on the day. Church programmes are listed underneath.
 */
@Composable
fun CalendarScreen(lang: Lang, onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { BookingsStore(context) }
    var bookings by remember { mutableStateOf(store.all()) }
    var month by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var selected by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    var editing by remember { mutableStateOf<Booking?>(null) }
    val ym = YearMonth.parse(month)
    val sel = LocalDate.parse(selected)
    val booked = remember(bookings) { bookings.groupBy { it.date } }

    fun refresh() { bookings = store.all(); EventReminders.schedule(context) }

    val b = editing
    if (b != null) {
        BookingEditor(
            initial = b, lang = lang, store = store,
            onDone = { saved -> if (saved != null) { store.upsert(saved); selected = saved.date.toString(); month = YearMonth.from(saved.date).toString() }; editing = null; refresh() },
            onDelete = { store.delete(b.id); editing = null; refresh() },
        )
        return
    }

    Box(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("பின்செல்", "Back")) }
                Text(lang.ui("நினைவூட்டல்", "Reminders"), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp)
                    .navigationBarsPadding().padding(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Month header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = ym.minusMonths(1).toString() }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null) }
                    Text(
                        if (lang == Lang.EN) ym.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))
                        else "${TA_MONTH[ym.monthValue - 1]} ${ym.year}",
                        fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { month = ym.plusMonths(1).toString() }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) }
                }
                MonthGrid(ym, sel, booked.keys, lang) { d -> selected = d.toString() }

                // Legend
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                    Text(lang.ui("முன்பதிவு உள்ளது", "Booked"), fontFamily = TamilFont, fontSize = 12.sp)
                    Box(Modifier.size(12.dp).clip(CircleShape).border(1.5.dp, MaterialTheme.colorScheme.onBackground, CircleShape))
                    Text(lang.ui("இன்று", "Today"), fontFamily = TamilFont, fontSize = 12.sp)
                }

                // Selected date
                val onDay = booked[sel].orEmpty()
                Text(sel.label(lang), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                if (onDay.isEmpty()) {
                    Text(lang.ui("✓ இந்தத் தேதி காலியாக உள்ளது", "✓ This date is free"), fontFamily = TamilFont,
                        fontSize = 14.sp, color = FREE)
                } else onDay.forEach { b ->
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth().clickable { editing = b }) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(b.title, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                val sub = listOfNotNull(b.time?.label(), b.note.takeIf { it.isNotBlank() }).joinToString(" · ")
                                if (sub.isNotEmpty()) Text(sub, fontFamily = TamilFont, fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (b.remind) Text("🔔", fontSize = 14.sp)
                        }
                    }
                }

                // Upcoming list
                val upcoming = bookings.filter { !it.date.isBefore(LocalDate.now()) }
                if (upcoming.isNotEmpty()) {
                    Text(lang.ui("வரவிருக்கும் முன்பதிவுகள்", "Upcoming"), fontFamily = TamilFont,
                        fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                    upcoming.take(10).forEach { b ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .clickable { selected = b.date.toString(); month = YearMonth.from(b.date).toString() }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(b.date.label(lang), fontFamily = TamilFont, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(0.45f))
                            Text(b.title, fontFamily = TamilFont, fontSize = 14.sp, modifier = Modifier.weight(0.55f), maxLines = 1)
                        }
                    }
                }

                ChurchProgrammes(lang)
            }
        }
        ExtendedFloatingActionButton(
            onClick = { editing = Booking(System.currentTimeMillis(), sel, null, "", "", true) },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text(lang.ui("முன்பதிவு", "Book"), fontFamily = TamilFont) },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
        )
    }
}

@Composable
private fun MonthGrid(ym: YearMonth, selected: LocalDate, booked: Set<LocalDate>, lang: Lang, onPick: (LocalDate) -> Unit) {
    val today = LocalDate.now()
    val lead = ym.atDay(1).dayOfWeek.value % 7          // Sunday first
    val cells = List(lead) { null } + (1..ym.lengthOfMonth()).map { ym.atDay(it) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row {
            (if (lang == Lang.EN) EN_WEEK else TA_WEEK).forEachIndexed { i, d ->
                Text(d, fontFamily = TamilFont, fontSize = 12.sp, textAlign = TextAlign.Center,
                    color = if (i == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f))
            }
        }
        cells.chunked(7).forEach { week ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { d ->
                    Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                        if (d != null) {
                            val isBooked = d in booked
                            val isSel = d == selected
                            Box(
                                Modifier.size(38.dp).clip(CircleShape)
                                    .background(
                                        when {
                                            isBooked -> MaterialTheme.colorScheme.primary
                                            isSel -> MaterialTheme.colorScheme.primaryContainer
                                            else -> Color.Transparent
                                        }
                                    )
                                    .then(if (d == today) Modifier.border(1.5.dp, MaterialTheme.colorScheme.onBackground, CircleShape) else Modifier)
                                    .then(if (isSel && isBooked) Modifier.border(3.dp, MaterialTheme.colorScheme.primaryContainer, CircleShape) else Modifier)
                                    .clickable { onPick(d) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("${d.dayOfMonth}", fontSize = 14.sp,
                                    fontWeight = if (isBooked || isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isBooked) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground)
                            }
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun BookingEditor(initial: Booking, lang: Lang, store: BookingsStore, onDone: (Booking?) -> Unit, onDelete: () -> Unit) {
    val context = LocalContext.current
    val isNew = store.all().none { it.id == initial.id }
    var title by remember { mutableStateOf(initial.title) }
    var note by remember { mutableStateOf(initial.note) }
    var date by remember { mutableStateOf(initial.date) }
    var time by remember { mutableStateOf(initial.time) }
    var remind by remember { mutableStateOf(initial.remind) }
    var conflict by remember { mutableStateOf<List<Booking>>(emptyList()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val clash = store.on(date, exceptId = initial.id)

    fun pickDate() {
        DatePickerDialog(context, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
            date.year, date.monthValue - 1, date.dayOfMonth).show()
    }
    fun build() = initial.copy(date = date, time = time, title = title.trim(), note = note.trim(), remind = remind)

    BackHandler { onDone(null) }

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onDone(null) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, lang.ui("ரத்து", "Cancel")) }
            Text(if (isNew) lang.ui("புதிய முன்பதிவு", "New booking") else lang.ui("முன்பதிவு", "Booking"),
                fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            if (!isNew) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, lang.ui("நீக்கு", "Delete")) }
            TextButton(enabled = title.isNotBlank(), onClick = {
                if (clash.isNotEmpty()) conflict = clash else onDone(build())
            }) { Text(lang.ui("சேமி", "Save"), fontFamily = TamilFont) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it }, singleLine = true,
                label = { Text(lang.ui("என்ன நிகழ்ச்சி? (எ.கா. திருமணம்)", "What is it? (e.g. Wedding)"), fontFamily = TamilFont) },
                modifier = Modifier.fillMaxWidth(),
            )
            // Date + availability
            OutlinedButton(onClick = ::pickDate, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.DateRange, null)
                Spacer(Modifier.size(8.dp))
                Text(date.label(lang), fontFamily = TamilFont, modifier = Modifier.weight(1f))
                Text(lang.ui("மாற்று", "Change"), fontFamily = TamilFont, fontSize = 13.sp)
            }
            if (clash.isEmpty()) {
                Text(lang.ui("✓ இந்தத் தேதி காலியாக உள்ளது", "✓ This date is free"), fontFamily = TamilFont, fontSize = 14.sp, color = FREE)
            } else {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(lang.ui("⚠ இந்தத் தேதியில் ஏற்கனவே முன்பதிவு உள்ளது:", "⚠ Already booked on this date:"),
                            fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer)
                        clash.forEach {
                            Text("• ${it.title}" + (it.time?.let { t -> " · ${t.label()}" } ?: ""), fontFamily = TamilFont,
                                fontSize = 14.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                        TextButton(onClick = ::pickDate) { Text(lang.ui("வேறு தேதி தேர்வு செய்", "Pick another date"), fontFamily = TamilFont) }
                    }
                }
            }
            // Time (optional)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = {
                    val t = time ?: LocalTime.of(10, 0)
                    TimePickerDialog(context, { _, h, m -> time = LocalTime.of(h, m) }, t.hour, t.minute, false).show()
                }, modifier = Modifier.weight(1f)) {
                    Text(time?.label() ?: lang.ui("நேரம் (விருப்பம்)", "Time (optional)"), fontFamily = TamilFont)
                }
                if (time != null) TextButton(onClick = { time = null }) { Text(lang.ui("நீக்கு", "Clear"), fontFamily = TamilFont) }
            }
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { Text(lang.ui("குறிப்பு (யாருக்கு, எங்கே...)", "Note (who, where…)"), fontFamily = TamilFont) },
                modifier = Modifier.fillMaxWidth(), minLines = 2,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(lang.ui("நினைவூட்டு", "Remind me"), fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text(lang.ui("முந்தைய நாள் இரவு 8 மணிக்கும் அன்றும்", "The evening before and on the day"),
                        fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = remind, onCheckedChange = { remind = it })
            }
        }
    }

    if (conflict.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { conflict = emptyList() },
            title = { Text(lang.ui("இந்தத் தேதி முன்பதிவு ஆகிவிட்டது", "This date is already booked"), fontFamily = TamilFont) },
            text = {
                Text(
                    lang.ui("${date.label(lang)} அன்று \"${conflict.first().title}\" ஏற்கனவே உள்ளது. வேறு தேதியைத் தேர்வு செய்யுங்கள்.",
                        "\"${conflict.first().title}\" is already on ${date.label(lang)}. Please choose another date."),
                    fontFamily = TamilFont,
                )
            },
            confirmButton = { TextButton(onClick = { conflict = emptyList(); pickDate() }) { Text(lang.ui("வேறு தேதி", "Another date"), fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { conflict = emptyList(); onDone(build()) }) { Text(lang.ui("இருந்தாலும் சேமி", "Save anyway"), fontFamily = TamilFont) } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(lang.ui("இந்த முன்பதிவை நீக்கவா?", "Delete this booking?"), fontFamily = TamilFont) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(lang.ui("நீக்கு", "Delete"), fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(lang.ui("வேண்டாம்", "Cancel"), fontFamily = TamilFont) } },
        )
    }
}
