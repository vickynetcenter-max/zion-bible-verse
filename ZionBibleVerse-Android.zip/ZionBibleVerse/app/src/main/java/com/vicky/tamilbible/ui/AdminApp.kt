package com.vicky.tamilbible.ui

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.foundation.clickable

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.asImageBitmap

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.ChurchApi
import com.vicky.tamilbible.data.RemoteData
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.launch

private val GREEN = Color(0xFF2E7D32)

private fun adminPrefs(c: Context) = c.getSharedPreferences("admin", Context.MODE_PRIVATE)

/**
 * Zion Admin app: post announcements and verse corrections to the church sheet.
 * The password is checked by the Apps Script (it is never stored in the app's code).
 */
@Composable
fun AdminApp(vm: BibleViewModel) {
    val context = LocalContext.current
    var password by remember { mutableStateOf<String?>(adminPrefs(context).getString("pw", null)) }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        val pw = password
        if (pw == null) AdminLogin { ok -> adminPrefs(context).edit().putString("pw", ok).apply(); password = ok }
        else AdminHome(vm, pw) { adminPrefs(context).edit().remove("pw").apply(); password = null }
    }
}

@Composable
private fun AdminLogin(onLoggedIn: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        ZionEmblem(size = 96.dp)
        Spacer(Modifier.height(12.dp))
        Text("Zion Admin", fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Text("சீயோன் பேராலயம்", fontFamily = TamilFont, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        if (!ChurchApi.configured) {
            Text("Server link not set in this build yet.", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(
            value = pw, onValueChange = { pw = it; error = null }, singleLine = true,
            label = { Text("Admin password") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = pw.isNotBlank() && !busy,
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(pw, "login")
                    busy = false
                    if (err == null) onLoggedIn(pw) else error = if (err == "wrong password") "தவறான password" else err
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("Login", fontSize = 16.sp) }
    }
}

private val NAVY = Color(0xFF1C2951)
private val MAROON = Color(0xFF8C1C2B)

/** Admin home: gradient header with counts, the current tab, and a bottom navigation bar. */
@Composable
private fun AdminHome(vm: BibleViewModel, password: String, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf<RemoteData?>(null) }
    var stats by remember { mutableStateOf<com.vicky.tamilbible.data.AnalyticsData?>(null) }
    var statsLoading by remember { mutableStateOf(true) }
    fun refresh() {
        scope.launch { ChurchApi.list(password)?.let { data = it } }
        scope.launch { statsLoading = true; ChurchApi.stats(password)?.let { stats = it }; statsLoading = false }
    }
    LaunchedEffect(Unit) { refresh(); vm.checkUpdate() }
    val d = data
    val live = d?.announcements?.count { it.isLive } ?: 0
    val scheduled = d?.announcements?.count { it.isScheduled } ?: 0

    Column(Modifier.fillMaxSize()) {
        // Header
        Box(
            Modifier.fillMaxWidth()
                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(NAVY, MAROON)))
                .padding(start = 18.dp, end = 6.dp, top = 14.dp, bottom = 16.dp),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White),
                        contentAlignment = Alignment.Center) { ZionEmblem(size = 44.dp) }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Zion Admin", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
                        Text("சீயோன் பேராலயம் · நிர்வாகம்", fontFamily = TamilFont, fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f))
                    }
                    IconButton(onClick = { refresh() }) { Icon(Icons.Filled.Refresh, "Refresh", tint = Color.White) }
                    IconButton(onClick = onLogout) { Icon(Icons.AutoMirrored.Filled.ExitToApp, "Logout", tint = Color.White) }
                }
                vm.update?.let { u ->
                    val ctx = LocalContext.current
                    Surface(shape = RoundedCornerShape(10.dp), color = Color.White, contentColor = MAROON,
                        modifier = Modifier.padding(top = 10.dp).clickable { openUrl(ctx, u.apkUrl) }) {
                        Text("🆕 Zion Admin ${u.versionName} — தொட்டு update செய்", fontFamily = TamilFont, fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("🟢", "$live", "நேரலை", Modifier.weight(1f))
                    StatChip("⏰", "$scheduled", "திட்டம்", Modifier.weight(1f))
                    StatChip("✏️", "${d?.corrections?.size ?: 0}", "வசனம்", Modifier.weight(1f))
                    StatChip("🙏", "${d?.praise?.size ?: 0}", "ஸ்தோத்.", Modifier.weight(1f))
                }
            }
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> AdminAnalytics(stats, data?.announcements.orEmpty(), statsLoading)
                1 -> AnnounceForm(password) { refresh() }
                2 -> CorrectionForm(vm, password)
                3 -> PraiseForm(password)
                else -> PostedList(vm, password, data, stats) { refresh() }
            }
        }
        NavigationBar {
            listOf("📊" to "Dashboard", "📢" to "அறிவிப்பு", "✏️" to "வசனம்", "🙏" to "ஸ்தோத்திரம்", "📋" to "பட்டியல்").forEachIndexed { i, (ic, label) ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = { Text(ic, fontSize = 20.sp) },
                    label = { Text(label, fontFamily = TamilFont, fontSize = 10.sp, maxLines = 1) },
                )
            }
        }
    }
}

@Composable
private fun StatChip(icon: String, value: String, label: String, modifier: Modifier) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.16f), contentColor = Color.White, modifier = modifier) {
        Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$icon $value", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(label, fontFamily = TamilFont, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
private fun Status(msg: String?, ok: Boolean) {
    msg?.let {
        Surface(shape = RoundedCornerShape(12.dp), color = if (ok) GREEN.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer) {
            Text(it, fontFamily = TamilFont, color = if (ok) GREEN else MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.fillMaxWidth().padding(12.dp))
        }
    }
}

/**
 * Reads a picked photo, applies its rotation, shrinks it to at most 1280px and returns
 * (preview bitmap, base64 JPEG) — usually 150–300 KB, quick to send on mobile data.
 */
private fun preparePicture(context: Context, uri: android.net.Uri): Pair<android.graphics.Bitmap, String>? = runCatching {
    val max = 1280
    val bmp: android.graphics.Bitmap = if (android.os.Build.VERSION.SDK_INT >= 28) {
        val src = android.graphics.ImageDecoder.createSource(context.contentResolver, uri)
        android.graphics.ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val sz: android.util.Size = info.getSize()
            val w = sz.width; val h = sz.height
            val scale = minOf(1f, max.toFloat() / maxOf(w, h))
            dec.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
            dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } else {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2
        context.contentResolver.openInputStream(uri)!!.use {
            android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })!!
        }
    }
    val out = java.io.ByteArrayOutputStream()
    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
    bmp to android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
}.getOrNull()

private val TA_DOW = mapOf(1 to "திங்கள்", 2 to "செவ்வாய்", 3 to "புதன்", 4 to "வியாழன்", 5 to "வெள்ளி", 6 to "சனி", 7 to "ஞாயிறு")

private fun whenLabel(ms: Long): String {
    val t = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneId.systemDefault())
    return "${TA_DOW[t.dayOfWeek.value]}, " + t.format(java.time.format.DateTimeFormatter.ofPattern("d MMM · h:mm a", java.util.Locale.ENGLISH))
}

@Composable
private fun AnnounceForm(password: String, onSent: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // Up to 10 pictures (shown to members as a slider). Each: (preview, base64 JPEG).
    val pictures = remember { androidx.compose.runtime.mutableStateListOf<Pair<android.graphics.Bitmap, String>>() }
    var preparing by remember { mutableStateOf(false) }
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris ->
        if (uris.isNotEmpty()) {
            preparing = true
            scope.launch {
                val room = 10 - pictures.size
                val ready = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                    uris.take(room).mapNotNull { preparePicture(context, it) }
                }
                pictures.addAll(ready); preparing = false
            }
        }
    }
    val picture: Pair<android.graphics.Bitmap, String>? = pictures.firstOrNull()
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var later by remember { mutableStateOf(false) }
    // Default schedule: tomorrow 6 AM.
    var at by remember { mutableStateOf(java.time.LocalDate.now().plusDays(1).atTime(6, 0)) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val atMs = at.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
    val now = System.currentTimeMillis()
    val scheduleOk = !later || (atMs > now + 60_000 && atMs <= now + 7L * 24 * 60 * 60 * 1000)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("எல்லா பயனர்களுக்கும் அறிவிப்பு", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedTextField(title, { title = it }, label = { Text("தலைப்பு", fontFamily = TamilFont) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(message, { message = it }, label = { Text("செய்தி", fontFamily = TamilFont) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp))

        // 🔗 Optional link — YouTube video / Shorts (shows as a playable card) or any web page.
        OutlinedTextField(link, { link = it.trim() }, singleLine = true,
            label = { Text("🔗 Link (YouTube / Shorts / website) — விருப்பம்", fontFamily = TamilFont) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
        if (link.isNotBlank()) {
            val yt = com.vicky.tamilbible.data.youtubeIdOf(link)
            Text(if (yt != null) (if (link.contains("/shorts/")) "✓ YouTube Shorts" else "✓ YouTube வீடியோ") + " — thumbnail-உடன் காட்டப்படும்"
                 else "🔗 சாதாரண link-ஆக காட்டப்படும்", fontFamily = TamilFont, fontSize = 12.sp,
                color = if (yt != null) GREEN else MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // 📷 Optional pictures (up to 10 → slider for members)
        val pic: Pair<android.graphics.Bitmap, String>? = picture
        if (pictures.isNotEmpty()) {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pictures.size) { i ->
                    Box {
                        androidx.compose.foundation.Image(
                            pictures[i].first.asImageBitmap(), null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)),
                        )
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = Color.Black.copy(alpha = 0.6f), contentColor = Color.White,
                            modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).clickable { pictures.removeAt(i) }) {
                            Text("✕", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp))
                        }
                        if (i == 0) Surface(shape = RoundedCornerShape(6.dp), color = MAROON, contentColor = Color.White,
                            modifier = Modifier.align(Alignment.BottomStart).padding(4.dp)) {
                            Text("முதல்", fontSize = 9.sp, fontFamily = TamilFont, modifier = Modifier.padding(horizontal = 5.dp))
                        }
                    }
                }
            }
            Text("${pictures.size} படம் · மொத்தம் சுமார் ${pictures.sumOf { it.second.length } * 3 / 4 / 1024} KB" +
                if (pictures.size > 1) " · மக்களுக்கு slider ஆகத் தெரியும்" else "",
                fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (preparing) Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.size(8.dp))
            Text("படங்கள் தயாராகின்றன…", fontFamily = TamilFont, fontSize = 13.sp)
        }
        if (pictures.size < 10) OutlinedButton(onClick = {
            pick.launch(androidx.activity.result.PickVisualMediaRequest(
                androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (pictures.isEmpty()) "📷 படங்கள் சேர் (10 வரை, விருப்பம்)" else "➕ மேலும் படங்கள் (${10 - pictures.size} இன்னும்)", fontFamily = TamilFont)
        }

        // ⏰ When
        Text("எப்போது அனுப்ப வேண்டும்?", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.FilterChip(selected = !later, onClick = { later = false },
                label = { Text("⚡ இப்போதே", fontFamily = TamilFont) })
            androidx.compose.material3.FilterChip(selected = later, onClick = { later = true },
                label = { Text("⏰ பின்னர் (7 நாட்களுக்குள்)", fontFamily = TamilFont) })
        }
        if (later) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    val dlg = android.app.DatePickerDialog(context, { _, y, m, dd -> at = java.time.LocalDate.of(y, m + 1, dd).atTime(at.toLocalTime()) },
                        at.year, at.monthValue - 1, at.dayOfMonth)
                    dlg.datePicker.minDate = now
                    dlg.datePicker.maxDate = now + 7L * 24 * 60 * 60 * 1000
                    dlg.show()
                }) { Text("📅 " + at.format(java.time.format.DateTimeFormatter.ofPattern("d MMM", java.util.Locale.ENGLISH))) }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    android.app.TimePickerDialog(context, { _, h, mi -> at = at.withHour(h).withMinute(mi) }, at.hour, at.minute, false).show()
                }) { Text("🕒 " + at.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a", java.util.Locale.ENGLISH))) }
            }
            Text(if (scheduleOk) "⏰ ${whenLabel(atMs)} அன்று எல்லோருக்கும் அனுப்பப்படும்" else "⚠️ இப்போதிலிருந்து 7 நாட்களுக்குள் ஒரு நேரத்தைத் தேர்வு செய்யுங்கள்",
                fontFamily = TamilFont, fontSize = 13.sp, color = if (scheduleOk) GREEN else MaterialTheme.colorScheme.error)
        }

        // Preview — how members will see it
        if (title.isNotBlank() || message.isNotBlank() || pic != null || link.isNotBlank()) {
            Text("மக்களுக்கு இப்படித் தெரியும்:", fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("📢 சீயோன் பேராலயம் · ${if (later) whenLabel(atMs) else "இப்போது"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontFamily = TamilFont)
                    if (title.isNotBlank()) Text(title, fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (message.isNotBlank()) Text(message, fontFamily = TamilFont, fontSize = 14.sp, lineHeight = 21.sp, maxLines = 4)
                    if (pictures.size == 1) androidx.compose.foundation.Image(pictures[0].first.asImageBitmap(), null,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(10.dp)))
                    if (pictures.size > 1) {
                        val pv = androidx.compose.foundation.pager.rememberPagerState { pictures.size }
                        androidx.compose.foundation.pager.HorizontalPager(pv, pageSpacing = 6.dp,
                            modifier = Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(10.dp))) { pg ->
                            androidx.compose.foundation.Image(pictures[pg].first.asImageBitmap(), null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                        Dots(pictures.size, pv.currentPage)
                    }
                    if (link.isNotBlank()) AnnouncementLink(link, com.vicky.tamilbible.data.youtubeIdOf(link), link.contains("/shorts/"),
                        com.vicky.tamilbible.data.Lang.TA)
                }
            }
        }

        Button(enabled = (title.isNotBlank() || message.isNotBlank() || picture != null || link.isNotBlank()) && scheduleOk && !busy, onClick = { confirm = true },
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MAROON),
            modifier = Modifier.fillMaxWidth().height(52.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
            else Text(if (later) "⏰ திட்டமிடு" else "📢 இப்போதே அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp)
        }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(if (later) "திட்டமிடவா?" else "எல்லோருக்கும் அனுப்பவா?", fontFamily = TamilFont) },
            text = { Text((if (later) "⏰ ${whenLabel(atMs)}\n\n" else "") + "$title\n\n$message" + if (pictures.isNotEmpty()) "\n\n📷 ${pictures.size} படம்" else "", fontFamily = TamilFont) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false; busy = true
                    scope.launch {
                        val res = ChurchApi.postJson(password, "announce", mapOf("title" to title.trim(), "message" to message.trim(),
                            "images" to org.json.JSONArray(pictures.map { it.second }), "link" to link.ifBlank { null }, "publishAt" to if (later) atMs else null))
                        busy = false
                        status = when {
                            res == null -> "✗ Internet / server கிடைக்கவில்லை" to false
                            !res.optBoolean("ok") -> "✗ ${res.optString("error")}" to false
                            later -> "⏰ திட்டமிடப்பட்டது — ${whenLabel(atMs)}" to true
                            res.optString("push") == "200" -> "✓ எல்லோருக்கும் உடனே அனுப்பப்பட்டது (push ✓)" to true
                            else -> ("⚠️ சேமிக்கப்பட்டது, ஆனால் push போகவில்லை — app திறக்கும்போது மட்டும் சேரும்.\n" +
                                "காரணம்: ${res.optString("push")}") to false
                        }
                        if (res?.optBoolean("ok") == true) { title = ""; message = ""; link = ""; pictures.clear(); onSent() }
                    }
                }) { Text(if (later) "திட்டமிடு" else "அனுப்பு", fontFamily = TamilFont) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("வேண்டாம்", fontFamily = TamilFont) } },
        )
    }
}

@Composable
private fun CorrectionForm(vm: BibleViewModel, password: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { BibleRepository(context) }
    var bookOrd by remember { mutableIntStateOf(43) }
    var chapter by remember { mutableStateOf("") }
    var verse by remember { mutableStateOf("") }
    var ta by remember { mutableStateOf("") }
    var en by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val book = vm.books.firstOrNull { it.ord == bookOrd }

    // Show the verse as it is now, to copy and fix.
    LaunchedEffect(bookOrd, chapter, verse) {
        val c = chapter.toIntOrNull(); val v = verse.toIntOrNull()
        current = if (c != null && v != null) repo.verseWithBook(bookOrd, c, v)?.second?.ta else null
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("தவறான வசனத்தைத் திருத்து", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(book?.ta ?: "புத்தகம்", fontFamily = TamilFont, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.ArrowDropDown, null)
            }
            DropdownMenu(open, { open = false }, modifier = Modifier.heightIn(max = 380.dp)) {
                vm.books.forEach { b -> DropdownMenuItem(text = { Text("${b.ord}. ${b.ta}", fontFamily = TamilFont) }, onClick = { bookOrd = b.ord; open = false }) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(chapter, { chapter = it.filter(Char::isDigit).take(3) }, label = { Text("அதிகாரம்", fontFamily = TamilFont) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
            OutlinedTextField(verse, { verse = it.filter(Char::isDigit).take(3) }, label = { Text("வசனம்", fontFamily = TamilFont) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
        }
        current?.let { cur ->
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("இப்போது app-ல் உள்ளது:", fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(cur, fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                    TextButton(onClick = { ta = cur }) { Text("இதை copy செய்து திருத்து", fontFamily = TamilFont) }
                }
            }
        }
        OutlinedTextField(ta, { ta = it }, label = { Text("சரியான தமிழ் வசனம்", fontFamily = TamilFont) }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
        OutlinedTextField(en, { en = it }, label = { Text("English (தவறு இருந்தால் மட்டும்)", fontFamily = TamilFont) }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = !busy && chapter.isNotBlank() && verse.isNotBlank() && (ta.isNotBlank() || en.isNotBlank()) && current != null,
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(password, "correct", mapOf("book" to bookOrd, "chapter" to chapter.toInt(), "verse" to verse.toInt(),
                        "ta" to ta.trim(), "en" to en.trim()))
                    busy = false
                    status = if (err == null) { ta = ""; en = ""; "✓ திருத்தம் சேமிக்கப்பட்டது — எல்லோருக்கும் app திறக்கும்போது மாறும்" to true } else "✗ $err" to false
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("திருத்தத்தை அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp) }
        if (chapter.isNotBlank() && verse.isNotBlank() && current == null) {
            Text("இந்த வசனம் இல்லை — எண்களைச் சரிபாருங்கள்", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
}

@Composable
private fun PraiseForm(password: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lines = remember { praiseLines(context) }
    val fixed = remember { com.vicky.tamilbible.data.RemoteCache.load(context).praise.associate { it.n to it.text } }
    var number by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val n = number.toIntOrNull()
    val current: String? = n?.let { fixed[it] ?: lines.getOrNull(it - 1) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ஸ்தோத்திர பலி வரியைத் திருத்து (1 – ${lines.size})", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        OutlinedTextField(number, { number = it.filter(Char::isDigit).take(4); status = null }, label = { Text("எண்", fontFamily = TamilFont) },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        if (current != null) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("இப்போது app-ல் உள்ளது:", fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$n. $current", fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                    TextButton(onClick = { text = current }) { Text("இதை copy செய்து திருத்து", fontFamily = TamilFont) }
                }
            }
        } else if (number.isNotBlank()) {
            Text("இந்த எண் இல்லை", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        OutlinedTextField(text, { text = it }, label = { Text("சரியான வரி", fontFamily = TamilFont) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
        Button(
            enabled = !busy && current != null && text.isNotBlank(),
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(password, "praise", mapOf("n" to n, "text" to text.trim()))
                    busy = false
                    status = if (err == null) { text = ""; "✓ சேமிக்கப்பட்டது — எல்லோருக்கும் app திறக்கும்போது மாறும்" to true } else "✗ $err" to false
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("திருத்தத்தை அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp) }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
}

@Composable
private fun PostedList(vm: BibleViewModel, password: String, data: RemoteData?, stats: com.vicky.tamilbible.data.AnalyticsData?, onChanged: () -> Unit) {
    val scope = rememberCoroutineScope()
    var del by remember { mutableStateOf<Triple<String, Long, String>?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val d = data
        if (d == null) { CircularProgressIndicator(); return@Column }
        val now = System.currentTimeMillis()
        Text("📢 அறிவிப்புகள் (${d.announcements.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        d.announcements.sortedByDescending { it.publishAt }.forEach { a ->
            val tag = when {
                a.isScheduled -> "⏰ திட்டம்: ${whenLabel(a.publishAt)}"
                a.isLive -> "🟢 நேரலை · இன்னும் ${((a.publishAt + com.vicky.tamilbible.data.ANNOUNCEMENT_LIFETIME - now) / 3_600_000) + 1} மணி நேரம்"
                else -> "⌛ முடிந்தது · ${whenLabel(a.publishAt)}"
            }
            val rc = stats?.reach?.get(a.id)
            val reachLine = if (rc != null && !a.isScheduled) "  ·  📩 ${rc.received}  👁 ${rc.opened}" else ""
            Item(tag + reachLine, a.title.ifBlank { if (a.image.isNotBlank()) "📷 படம்" else "" }, a.message) {
                del = Triple("announcement", a.id, a.title.ifBlank { a.message })
            }
        }
        Text("🙏 ஸ்தோத்திரத் திருத்தங்கள் (${d.praise.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        d.praise.sortedByDescending { it.id }.forEach { p ->
            Item("ஸ்தோத்திரம் ${p.n}", p.text, "") { del = Triple("praise", p.id, "ஸ்தோத்திரம் ${p.n}") }
        }
        Text("✏️ வசனத் திருத்தங்கள் (${d.corrections.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        d.corrections.sortedByDescending { it.id }.forEach { c ->
            val name = vm.books.firstOrNull { it.ord == c.book }?.ta ?: c.book.toString()
            Item("$name ${c.chapter}:${c.verse}", c.ta, c.en) { del = Triple("correction", c.id, "$name ${c.chapter}:${c.verse}") }
        }
    }
    val d0: Triple<String, Long, String>? = del
    d0?.let { t ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("நீக்கவா?", fontFamily = TamilFont) },
            text = { Text(t.third, fontFamily = TamilFont) },
            confirmButton = { TextButton(onClick = { del = null; scope.launch { ChurchApi.post(password, "delete", mapOf("type" to t.first, "id" to t.second)); onChanged() } }) { Text("நீக்கு", fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("வேண்டாம்", fontFamily = TamilFont) } },
        )
    }
}

@Composable
private fun Item(head: String, line1: String, line2: String, onDelete: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(head, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontFamily = TamilFont)
                if (line1.isNotBlank()) Text(line1, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 3)
                if (line2.isNotBlank()) Text(line2, fontFamily = TamilFont, fontSize = 13.sp, maxLines = 3)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}

