package com.vicky.tamilbible.ui

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.asImageBitmap

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.data.BibleRepository
import com.vicky.tamilbible.data.ChurchApi
import com.vicky.tamilbible.data.RemoteData
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.launch

private val GREEN = Color(0xFF2E7D32)

private fun adminPrefs(c: Context) = c.getSharedPreferences("admin", Context.MODE_PRIVATE)

/**
 * Zion Admin app: post announcements and verse corrections to the church sheet.
 * The password is checked by the Apps Script (it is never stored in the app's code).
 */
@Composable
fun AdminApp(vm: BibleViewModel) {
    val context = LocalContext.current
    var password by remember { mutableStateOf<String?>(adminPrefs(context).getString("pw", null)) }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        val pw = password
        if (pw == null) AdminLogin { ok -> adminPrefs(context).edit().putString("pw", ok).apply(); password = ok }
        else AdminHome(vm, pw) { adminPrefs(context).edit().remove("pw").apply(); password = null }
    }
}

@Composable
private fun AdminLogin(onLoggedIn: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        ZionEmblem(size = 96.dp)
        Spacer(Modifier.height(12.dp))
        Text("Zion Admin", fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Text("சீயோன் பேராலயம்", fontFamily = TamilFont, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        if (!ChurchApi.configured) {
            Text("Server link not set in this build yet.", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(
            value = pw, onValueChange = { pw = it; error = null }, singleLine = true,
            label = { Text("Admin password") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = pw.isNotBlank() && !busy,
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(pw, "login")
                    busy = false
                    if (err == null) onLoggedIn(pw) else error = if (err == "wrong password") "தவறான password" else err
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("Login", fontSize = 16.sp) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminHome(vm: BibleViewModel, password: String, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            ZionEmblem(size = 36.dp)
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Zion Admin", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("சீயோன் பேராலயம்", fontFamily = TamilFont, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onLogout) { Icon(Icons.AutoMirrored.Filled.ExitToApp, "Logout") }
        }
        val tabs = listOf("📢 அறிவிப்பு", "✏️ வசனம்", "🙏 ஸ்தோத்திரம்", "📋 பட்டியல்")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
            tabs.forEachIndexed { i, t ->
                SegmentedButton(selected = tab == i, onClick = { tab = i }, shape = SegmentedButtonDefaults.itemShape(i, tabs.size), icon = {}) {
                    Text(t, fontFamily = TamilFont, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        when (tab) {
            0 -> AnnounceForm(password)
            1 -> CorrectionForm(vm, password)
            2 -> PraiseForm(password)
            else -> PostedList(vm, password)
        }
    }
}

@Composable
private fun Status(msg: String?, ok: Boolean) {
    msg?.let {
        Surface(shape = RoundedCornerShape(12.dp), color = if (ok) GREEN.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer) {
            Text(it, fontFamily = TamilFont, color = if (ok) GREEN else MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.fillMaxWidth().padding(12.dp))
        }
    }
}

/**
 * Reads a picked photo, applies its rotation, shrinks it to at most 1280px and returns
 * (preview bitmap, base64 JPEG) — usually 150–300 KB, quick to send on mobile data.
 */
private fun preparePicture(context: Context, uri: android.net.Uri): Pair<android.graphics.Bitmap, String>? = runCatching {
    val max = 1280
    val bmp: android.graphics.Bitmap = if (android.os.Build.VERSION.SDK_INT >= 28) {
        val src = android.graphics.ImageDecoder.createSource(context.contentResolver, uri)
        android.graphics.ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val sz: android.util.Size = info.getSize()
            val w = sz.width; val h = sz.height
            val scale = minOf(1f, max.toFloat() / maxOf(w, h))
            dec.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
            dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } else {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2
        context.contentResolver.openInputStream(uri)!!.use {
            android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })!!
        }
    }
    val out = java.io.ByteArrayOutputStream()
    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
    bmp to android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
}.getOrNull()

@Composable
private fun AnnounceForm(password: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var picture by remember { mutableStateOf<Pair<android.graphics.Bitmap, String>?>(null) }
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) picture = preparePicture(context, uri) }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("எல்லா பயனர்களுக்கும் அறிவிப்பு அனுப்பு", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        OutlinedTextField(title, { title = it }, label = { Text("தலைப்பு", fontFamily = TamilFont) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(message, { message = it }, label = { Text("செய்தி", fontFamily = TamilFont) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp))
        // 📷 Optional picture
        val pic: Pair<android.graphics.Bitmap, String>? = picture
        if (pic == null) {
            OutlinedButton(onClick = {
                pick.launch(androidx.activity.result.PickVisualMediaRequest(
                    androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
            }, modifier = Modifier.fillMaxWidth()) { Text("📷 படம் சேர் (விருப்பம்)", fontFamily = TamilFont) }
        } else {
            Box {
                androidx.compose.foundation.Image(
                    pic.first.asImageBitmap(), contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                )
                IconButton(onClick = { picture = null }, modifier = Modifier.align(Alignment.TopEnd)) {
                    Surface(shape = androidx.compose.foundation.shape.CircleShape, color = Color.Black.copy(alpha = 0.55f), contentColor = Color.White) {
                        Text("✕", modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp))
                    }
                }
            }
            Text("படம் சுமார் ${pic.second.length * 3 / 4 / 1024} KB", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("மக்களின் phone-க்கு அடுத்த 6, 10, 12, 4, 8 மணி நேரங்களில் அல்லது app திறக்கும்போது notification ஆகச் செல்லும்.",
            fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(enabled = (title.isNotBlank() || message.isNotBlank() || picture != null) && !busy, onClick = { confirm = true },
            modifier = Modifier.fillMaxWidth().height(50.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp)
        }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("எல்லோருக்கும் அனுப்பவா?", fontFamily = TamilFont) },
            text = { Text("${title}\n\n${message}" + if (picture != null) "\n\n📷 படத்துடன்" else "", fontFamily = TamilFont) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false; busy = true
                    scope.launch {
                        val img = picture?.second
                        val err = ChurchApi.post(password, "announce", mapOf("title" to title.trim(), "message" to message.trim(), "image" to img))
                        busy = false
                        status = if (err == null) { title = ""; message = ""; picture = null; "✓ அனுப்பப்பட்டது" to true } else "✗ $err" to false
                    }
                }) { Text("அனுப்பு", fontFamily = TamilFont) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("வேண்டாம்", fontFamily = TamilFont) } },
        )
    }
}

@Composable
private fun CorrectionForm(vm: BibleViewModel, password: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { BibleRepository(context) }
    var bookOrd by remember { mutableIntStateOf(43) }
    var chapter by remember { mutableStateOf("") }
    var verse by remember { mutableStateOf("") }
    var ta by remember { mutableStateOf("") }
    var en by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val book = vm.books.firstOrNull { it.ord == bookOrd }

    // Show the verse as it is now, to copy and fix.
    LaunchedEffect(bookOrd, chapter, verse) {
        val c = chapter.toIntOrNull(); val v = verse.toIntOrNull()
        current = if (c != null && v != null) repo.verseWithBook(bookOrd, c, v)?.second?.ta else null
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("தவறான வசனத்தைத் திருத்து", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(book?.ta ?: "புத்தகம்", fontFamily = TamilFont, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.ArrowDropDown, null)
            }
            DropdownMenu(open, { open = false }, modifier = Modifier.heightIn(max = 380.dp)) {
                vm.books.forEach { b -> DropdownMenuItem(text = { Text("${b.ord}. ${b.ta}", fontFamily = TamilFont) }, onClick = { bookOrd = b.ord; open = false }) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(chapter, { chapter = it.filter(Char::isDigit).take(3) }, label = { Text("அதிகாரம்", fontFamily = TamilFont) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
            OutlinedTextField(verse, { verse = it.filter(Char::isDigit).take(3) }, label = { Text("வசனம்", fontFamily = TamilFont) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
        }
        current?.let { cur ->
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("இப்போது app-ல் உள்ளது:", fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(cur, fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                    TextButton(onClick = { ta = cur }) { Text("இதை copy செய்து திருத்து", fontFamily = TamilFont) }
                }
            }
        }
        OutlinedTextField(ta, { ta = it }, label = { Text("சரியான தமிழ் வசனம்", fontFamily = TamilFont) }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
        OutlinedTextField(en, { en = it }, label = { Text("English (தவறு இருந்தால் மட்டும்)", fontFamily = TamilFont) }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = !busy && chapter.isNotBlank() && verse.isNotBlank() && (ta.isNotBlank() || en.isNotBlank()) && current != null,
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(password, "correct", mapOf("book" to bookOrd, "chapter" to chapter.toInt(), "verse" to verse.toInt(),
                        "ta" to ta.trim(), "en" to en.trim()))
                    busy = false
                    status = if (err == null) { ta = ""; en = ""; "✓ திருத்தம் சேமிக்கப்பட்டது — எல்லோருக்கும் app திறக்கும்போது மாறும்" to true } else "✗ $err" to false
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("திருத்தத்தை அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp) }
        if (chapter.isNotBlank() && verse.isNotBlank() && current == null) {
            Text("இந்த வசனம் இல்லை — எண்களைச் சரிபாருங்கள்", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
}

@Composable
private fun PraiseForm(password: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lines = remember { praiseLines(context) }
    val fixed = remember { com.vicky.tamilbible.data.RemoteCache.load(context).praise.associate { it.n to it.text } }
    var number by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val n = number.toIntOrNull()
    val current: String? = n?.let { fixed[it] ?: lines.getOrNull(it - 1) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ஸ்தோத்திர பலி வரியைத் திருத்து (1 – ${lines.size})", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        OutlinedTextField(number, { number = it.filter(Char::isDigit).take(4); status = null }, label = { Text("எண்", fontFamily = TamilFont) },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        if (current != null) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("இப்போது app-ல் உள்ளது:", fontFamily = TamilFont, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$n. $current", fontFamily = TamilFont, fontSize = 15.sp, lineHeight = 23.sp)
                    TextButton(onClick = { text = current }) { Text("இதை copy செய்து திருத்து", fontFamily = TamilFont) }
                }
            }
        } else if (number.isNotBlank()) {
            Text("இந்த எண் இல்லை", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        OutlinedTextField(text, { text = it }, label = { Text("சரியான வரி", fontFamily = TamilFont) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
        Button(
            enabled = !busy && current != null && text.isNotBlank(),
            onClick = {
                busy = true
                scope.launch {
                    val err = ChurchApi.post(password, "praise", mapOf("n" to n, "text" to text.trim()))
                    busy = false
                    status = if (err == null) { text = ""; "✓ சேமிக்கப்பட்டது — எல்லோருக்கும் app திறக்கும்போது மாறும்" to true } else "✗ $err" to false
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("திருத்தத்தை அனுப்பு", fontFamily = TamilFont, fontSize = 16.sp) }
        val st: Pair<String, Boolean>? = status
        st?.let { Status(it.first, it.second) }
    }
}

@Composable
private fun PostedList(vm: BibleViewModel, password: String) {
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<RemoteData?>(null) }
    var loading by remember { mutableStateOf(true) }
    var del by remember { mutableStateOf<Triple<String, Long, String>?>(null) }
    fun load() { loading = true; scope.launch { data = ChurchApi.fetch(); loading = false } }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("அனுப்பியவை", fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { load() }) { Icon(Icons.Filled.Refresh, "Refresh") }
        }
        if (loading) CircularProgressIndicator()
        val d = data
        if (!loading && d == null) Text("Server-ஐ அடைய முடியவில்லை", fontFamily = TamilFont, color = MaterialTheme.colorScheme.error)
        if (d != null) {
            Text("📢 அறிவிப்புகள் (${d.announcements.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold)
            d.announcements.forEach { a ->
                Item(formatDate(a.id), a.title, a.message) { del = Triple("announcement", a.id, a.title.ifBlank { a.message }) }
            }
            Text("🙏 ஸ்தோத்திரத் திருத்தங்கள் (${d.praise.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            d.praise.sortedByDescending { it.id }.forEach { p ->
                Item("ஸ்தோத்திரம் ${p.n}", p.text, "") { del = Triple("praise", p.id, "ஸ்தோத்திரம் ${p.n}") }
            }
            Text("✏️ வசனத் திருத்தங்கள் (${d.corrections.size})", fontFamily = TamilFont, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            d.corrections.sortedByDescending { it.id }.forEach { c ->
                val name = vm.books.firstOrNull { it.ord == c.book }?.ta ?: c.book.toString()
                Item("$name ${c.chapter}:${c.verse}", c.ta, c.en) { del = Triple("correction", c.id, "$name ${c.chapter}:${c.verse}") }
            }
        }
    }
    val d0: Triple<String, Long, String>? = del
    d0?.let { t ->
        val type = t.first; val id = t.second; val label = t.third
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("நீக்கவா?", fontFamily = TamilFont) },
            text = { Text(label, fontFamily = TamilFont) },
            confirmButton = { TextButton(onClick = { del = null; scope.launch { ChurchApi.post(password, "delete", mapOf("type" to type, "id" to id)); load() } }) { Text("நீக்கு", fontFamily = TamilFont) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("வேண்டாம்", fontFamily = TamilFont) } },
        )
    }
}

@Composable
private fun Item(head: String, line1: String, line2: String, onDelete: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(head, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontFamily = TamilFont)
                if (line1.isNotBlank()) Text(line1, fontFamily = TamilFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 3)
                if (line2.isNotBlank()) Text(line2, fontFamily = TamilFont, fontSize = 13.sp, maxLines = 3)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}

