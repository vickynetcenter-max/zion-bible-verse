package com.vicky.tamilbible.data

import android.content.Context
import com.vicky.tamilbible.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** An announcement posted by the church admin. */
/**
 * [image] is a Google Drive file id ("" when the post has no picture). [publishAt] is when it goes
 * out (ms) — later than [id] for scheduled posts. Members see a post for 24 hours from [publishAt].
 */
data class Announcement(
    val id: Long, val date: String, val title: String, val message: String, val image: String = "",
    val publishAt: Long = id, val pushed: String = "", val link: String = "",
) {
    /** Drive ids of the pictures ([image] holds them comma-separated; first one = cover). */
    val images: List<String> get() = image.split(',').map { it.trim() }.filter { it.isNotEmpty() }

    /** YouTube video id when [link] is a YouTube video / Shorts / live link. */
    val youtubeId: String? get() = youtubeIdOf(link)
    val isShorts: Boolean get() = link.contains("/shorts/")

    val isLive: Boolean get() = System.currentTimeMillis().let { it >= publishAt && it - publishAt < ANNOUNCEMENT_LIFETIME }
    val isScheduled: Boolean get() = publishAt > System.currentTimeMillis()
}

/** Extracts the 11-character id from youtube.com/watch?v=, youtu.be/, /shorts/, /live/ or /embed/ links. */
fun youtubeIdOf(url: String): String? =
    Regex("""(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|live/|embed/))([A-Za-z0-9_-]{11})""")
        .find(url)?.groupValues?.get(1)

/** Announcements are shown for one day after they go out. */
const val ANNOUNCEMENT_LIFETIME = 24L * 60 * 60 * 1000

/** A corrected verse text posted by the admin; blank [ta]/[en] means "keep the original". */
data class Correction(val id: Long, val book: Int, val chapter: Int, val verse: Int, val ta: String, val en: String)

/** Corrected text for praise-list line number [n] (ஸ்தோத்திர பலி). */
data class PraiseFix(val id: Long, val n: Int, val text: String)

data class RemoteData(val announcements: List<Announcement>, val corrections: List<Correction>, val praise: List<PraiseFix> = emptyList())

/**
 * Talks to the church's Google Apps Script web app (see zion-apps-script.gs).
 * GET (anyone): announcements + corrections. POST (admin password): announce / correct / delete.
 */
object ChurchApi {
    val url: String get() = BuildConfig.CHURCH_API_URL
    val configured: Boolean get() = url.startsWith("https://")

    suspend fun fetch(): RemoteData? = withContext(Dispatchers.IO) {
        if (!configured) return@withContext null
        runCatching { parse(JSONObject(http("GET", url, null))) }.getOrNull()
    }

    /** Admin: everything including scheduled posts. */
    suspend fun list(password: String): RemoteData? = withContext(Dispatchers.IO) {
        if (!configured) return@withContext null
        runCatching {
            val res = JSONObject(http("POST", url, JSONObject().put("password", password).put("action", "list").toString()))
            if (res.optBoolean("ok")) parse(res) else null
        }.getOrNull()
    }

    /** Like [post] but returns the server's full JSON reply (null when unreachable). */
    suspend fun postJson(password: String, action: String, fields: Map<String, Any?> = emptyMap()): JSONObject? =
        withContext(Dispatchers.IO) {
            if (!configured) return@withContext null
            runCatching {
                val body = JSONObject().put("password", password).put("action", action)
                fields.forEach { (k, v) -> body.put(k, v) }
                JSONObject(http("POST", url, body.toString()))
            }.getOrNull()
        }

    /** Returns null on success, or an error message. */
    suspend fun post(password: String, action: String, fields: Map<String, Any?> = emptyMap()): String? =
        withContext(Dispatchers.IO) {
            if (!configured) return@withContext "Server link not set"
            runCatching {
                val body = JSONObject().put("password", password).put("action", action)
                fields.forEach { (k, v) -> body.put(k, v) }
                val res = JSONObject(http("POST", url, body.toString()))
                if (res.optBoolean("ok")) null else res.optString("error", "failed")
            }.getOrElse { "No internet / server not reachable" }
        }

    fun parse(o: JSONObject): RemoteData {
        fun arr(name: String) = o.optJSONArray(name) ?: JSONArray()
        val anns = arr("announcements").let { a ->
            List(a.length()) { i ->
                val x = a.getJSONObject(i)
                val id = x.optLong("id")
                Announcement(id, x.optString("date"), x.optString("title"), x.optString("message"), x.optString("image"),
                    x.optLong("publishAt", 0L).takeIf { it > 0 } ?: id, x.optString("pushed"), x.optString("link"))
            }
        }.filter { it.id > 0 }.sortedByDescending { it.publishAt }
        val cors = arr("corrections").let { a ->
            List(a.length()) { i ->
                val x = a.getJSONObject(i)
                Correction(x.optLong("id"), x.optInt("book"), x.optInt("chapter"), x.optInt("verse"),
                    x.optString("ta"), x.optString("en"))
            }
        }.filter { it.book > 0 && it.chapter > 0 && it.verse > 0 }.sortedBy { it.id }
        val pra = arr("praise").let { a ->
            List(a.length()) { i -> val x = a.getJSONObject(i); PraiseFix(x.optLong("id"), x.optInt("n"), x.optString("text")) }
        }.filter { it.n > 0 && it.text.isNotBlank() }.sortedBy { it.id }
        return RemoteData(anns, cors, pra)
    }

    private fun http(method: String, url: String, body: String?): String {
        // Apps Script answers POST with a redirect; HttpURLConnection follows it as a GET.
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000; readTimeout = 20000
            instanceFollowRedirects = true
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                outputStream.use { it.write(body.toByteArray()) }
            }
        }
        var code = c.responseCode
        var conn = c
        // Follow one manual redirect if the platform didn't (e.g. https → googleusercontent).
        if (code in 300..399) {
            val loc = c.getHeaderField("Location"); c.disconnect()
            conn = (URL(loc).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 20000 }
            code = conn.responseCode
        }
        return conn.inputStream.bufferedReader().use { it.readText() }.also { conn.disconnect() }
    }
}

/** Last fetched data, kept on the phone so corrections and announcements also work offline. */
object RemoteCache {
    private fun prefs(c: Context) = c.getSharedPreferences("remote", Context.MODE_PRIVATE)

    fun save(c: Context, raw: RemoteData) {
        val o = JSONObject()
        o.put("announcements", JSONArray().apply {
            raw.announcements.forEach { put(JSONObject().put("id", it.id).put("date", it.date).put("title", it.title).put("message", it.message).put("image", it.image).put("publishAt", it.publishAt).put("link", it.link)) }
        })
        o.put("corrections", JSONArray().apply {
            raw.corrections.forEach {
                put(JSONObject().put("id", it.id).put("book", it.book).put("chapter", it.chapter).put("verse", it.verse)
                    .put("ta", it.ta).put("en", it.en))
            }
        })
        o.put("praise", JSONArray().apply {
            raw.praise.forEach { put(JSONObject().put("id", it.id).put("n", it.n).put("text", it.text)) }
        })
        prefs(c).edit().putString("data", o.toString()).apply()
        Corrections.load(raw.corrections)
    }

    /** Adds a post that arrived by push straight into the saved list (shows instantly, before any sync). */
    fun addLocal(c: Context, a: Announcement) {
        val d = load(c)
        if (d.announcements.any { it.id == a.id }) return
        save(c, d.copy(announcements = (listOf(a) + d.announcements).sortedByDescending { it.publishAt }))
    }

    /** Builds an announcement from a push's data (FCM data map or notification-tap extras). */
    fun fromPush(get: (String) -> String?): Announcement? {
        val id = get("id")?.toLongOrNull() ?: return null
        val at = get("publishAt")?.toLongOrNull() ?: System.currentTimeMillis()
        return Announcement(id, "", get("title").orEmpty(), get("message").orEmpty(), get("image").orEmpty(), at, "200", get("link").orEmpty())
    }

    fun load(c: Context): RemoteData {
        val s = prefs(c).getString("data", null) ?: return RemoteData(emptyList(), emptyList(), emptyList())
        return runCatching { ChurchApi.parse(JSONObject(s)) }.getOrDefault(RemoteData(emptyList(), emptyList(), emptyList()))
    }

    /** Announcements the member cleared (✕) — hidden on this phone only. */
    fun hidden(c: Context): Set<Long> = prefs(c).getStringSet("hidden", emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()
    fun hide(c: Context, ids: Collection<Long>) =
        prefs(c).edit().putStringSet("hidden", (hidden(c) + ids).map { it.toString() }.toSet()).apply()

    /** Ids already shown as a notification on this phone (so push + sync never double up). */
    fun notified(c: Context): Set<Long> = prefs(c).getStringSet("notified", emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()
    fun markNotified(c: Context, ids: Collection<Long>) {
        val keep = (notified(c) + ids).filter { it > System.currentTimeMillis() - 21L * 24 * 60 * 60 * 1000 }
        prefs(c).edit().putStringSet("notified", keep.map { it.toString() }.toSet()).apply()
    }
    fun initialized(c: Context) = prefs(c).getBoolean("init", false)
    fun setInitialized(c: Context) = prefs(c).edit().putBoolean("init", true).apply()

    fun lastRead(c: Context) = prefs(c).getLong("last_read", 0L)
    fun setLastRead(c: Context, id: Long) = prefs(c).edit().putLong("last_read", id).apply()
}

/** Verse corrections applied on top of bible.db (the newest correction for a verse wins). */
object Corrections {
    @Volatile private var map: Map<String, Correction> = emptyMap()
    private fun key(b: Int, c: Int, v: Int) = "$b:$c:$v"

    fun load(list: List<Correction>) { map = list.associateBy { key(it.book, it.chapter, it.verse) } }

    fun ta(b: Int, c: Int, v: Int, original: String) = map[key(b, c, v)]?.ta?.takeIf { it.isNotBlank() } ?: original
    fun en(b: Int, c: Int, v: Int, original: String) = map[key(b, c, v)]?.en?.takeIf { it.isNotBlank() } ?: original
}

/** Downloads announcement pictures from Google Drive once and keeps them in the app's cache. */
object AnnouncementImages {
    private fun file(c: Context, id: String) = java.io.File(c.cacheDir, "ann_${id.filter { it.isLetterOrDigit() || it == '_' || it == '-' }}.jpg")

    suspend fun load(c: Context, id: String, maxSide: Int = 1280): android.graphics.Bitmap? =
        if (id.isBlank()) null
        else fromUrl(c, "https://lh3.googleusercontent.com/d/$id=w1280", id, maxSide)
            ?: fromUrl(c, "https://drive.google.com/uc?export=view&id=$id", id, maxSide)

    /** YouTube video thumbnail (cached like the pictures). */
    suspend fun youtubeThumb(c: Context, videoId: String): android.graphics.Bitmap? =
        fromUrl(c, "https://img.youtube.com/vi/$videoId/hqdefault.jpg", "yt_$videoId", 640)

    private suspend fun fromUrl(c: Context, url: String, key: String, maxSide: Int): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
        val f = file(c, key)
        if (!f.exists() || f.length() == 0L) {
            runCatching {
                var conn = URL(url).openConnection() as HttpURLConnection
                conn.instanceFollowRedirects = true; conn.connectTimeout = 15000; conn.readTimeout = 30000
                var hops = 0
                while (conn.responseCode in 300..399 && hops++ < 5) {
                    val loc = conn.getHeaderField("Location"); conn.disconnect()
                    conn = URL(loc).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000; conn.readTimeout = 30000
                }
                val tmp = java.io.File(c.cacheDir, f.name + ".part")
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                conn.disconnect()
                tmp.renameTo(f)
            }
        }
        if (!f.exists()) return@withContext null
        runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(f.path, o)
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2
            android.graphics.BitmapFactory.decodeFile(f.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
        }.getOrNull()
    }
}
