package com.vicky.tamilbible.games

import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * A ready-to-play board: [solution] is one full Hamiltonian path (every cell once) and
 * [letterAt] maps a cell to the index of the letter printed on it (0 = first letter).
 */
class LetterPathPuzzle(val n: Int, val letters: List<String>, val solution: List<Int>, val letterAt: Map<Int, Int>) {
    val cells: Int get() = n * n
}

/** Builds boards that are always solvable. */
object LetterPathGenerator {
    private const val STEP_CAP = 30_000

    fun neighbours(n: Int, cell: Int): List<Int> {
        val r = cell / n; val c = cell % n
        val out = ArrayList<Int>(4)
        if (r > 0) out += cell - n
        if (r < n - 1) out += cell + n
        if (c > 0) out += cell - 1
        if (c < n - 1) out += cell + 1
        return out
    }

    /** Random Hamiltonian path over the n × n grid: DFS + backtracking, Warnsdorff order, random ties. */
    fun hamiltonianPath(n: Int, rnd: Random = Random.Default): List<Int> {
        require(n >= 2)
        while (true) {
            val visited = BooleanArray(n * n)
            val path = ArrayList<Int>(n * n)
            var steps = 0
            fun free(cell: Int) = neighbours(n, cell).count { !visited[it] }
            fun dfs(): Boolean {
                if (path.size == n * n) return true
                if (++steps > STEP_CAP) return false
                val here = path.last()
                val options = neighbours(n, here).filter { !visited[it] }
                    .map { Triple(it, free(it), rnd.nextDouble()) }
                    .sortedWith(compareBy({ it.second }, { it.third }))
                for ((next) in options) {
                    visited[next] = true; path += next
                    if (dfs()) return true
                    visited[next] = false; path.removeAt(path.size - 1)
                }
                return false
            }
            val start = rnd.nextInt(n * n)
            visited[start] = true; path += start
            if (dfs()) return path
        }
    }

    /** Letter positions along the path: first at 0, last at n*n-1, others evenly spaced ± 2. */
    fun letterIndices(cells: Int, count: Int, rnd: Random = Random.Default): List<Int> {
        require(count in 2..cells)
        val last = cells - 1
        val idx = ArrayList<Int>(count)
        idx += 0
        for (i in 1 until count - 1) {
            val even = (i.toDouble() * last / (count - 1)).roundToInt()
            val jittered = even + rnd.nextInt(-2, 3)
            val low = idx.last() + 1
            val high = last - (count - 1 - i)          // leave room for the letters still to place
            idx += jittered.coerceIn(low, high)
        }
        idx += last
        return idx
    }

    fun build(level: LetterPathLevel, rnd: Random = Random.Default): LetterPathPuzzle {
        val path = hamiltonianPath(level.n, rnd)
        val at = letterIndices(level.n * level.n, level.letters.size, rnd)
        val letterAt = at.withIndex().associate { (i, pathIndex) -> path[pathIndex] to i }
        return LetterPathPuzzle(level.n, level.letters, path, letterAt)
    }
}

/** What happened when the finger reached a cell. */
enum class Move { STARTED, ADDED, REMOVED, CUT, NOT_FIRST, NOT_NEXT, IGNORED }

/** The line the player is drawing, with all the rules of எழுத்துப் பாதை. */
class LetterPathState(val puzzle: LetterPathPuzzle) {
    private val _path = ArrayList<Int>()
    val path: List<Int> get() = _path

    /** Index of the letter that must be entered next. */
    val nextLetter: Int get() = _path.count { puzzle.letterAt.containsKey(it) }

    val solved: Boolean get() = _path.size == puzzle.cells && nextLetter == puzzle.letters.size

    fun reset() = _path.clear()

    /** Removes the last square. */
    fun undo(): Boolean {
        if (solved || _path.isEmpty()) return false
        _path.removeAt(_path.size - 1); return true
    }

    fun touch(cell: Int): Move {
        if (solved || cell !in 0 until puzzle.cells) return Move.IGNORED
        if (_path.isEmpty()) {
            if (puzzle.letterAt[cell] != 0) return Move.NOT_FIRST
            _path += cell; return Move.STARTED
        }
        val last = _path.last()
        if (cell == last) return Move.IGNORED
        // Back over the previous square: remove the last one.
        if (_path.size >= 2 && cell == _path[_path.size - 2]) { _path.removeAt(_path.size - 1); return Move.REMOVED }
        // An earlier square of the line: cut back to it.
        val at = _path.indexOf(cell)
        if (at >= 0) { while (_path.size > at + 1) _path.removeAt(_path.size - 1); return Move.CUT }
        // Only one step up/down/left/right.
        val n = puzzle.n
        if (abs(last / n - cell / n) + abs(last % n - cell % n) != 1) return Move.IGNORED
        // A letter square only when it is the next letter of the word.
        val letter = puzzle.letterAt[cell]
        if (letter != null && letter != nextLetter) return Move.NOT_NEXT
        _path += cell
        return Move.ADDED
    }

    /** Stars: par = cells × 2 seconds; ≤ par → 3, ≤ 2 × par → 2, otherwise 1. */
    companion object {
        fun stars(cells: Int, seconds: Int): Int {
            val par = cells * 2
            return when { seconds <= par -> 3; seconds <= par * 2 -> 2; else -> 1 }
        }
    }
}
