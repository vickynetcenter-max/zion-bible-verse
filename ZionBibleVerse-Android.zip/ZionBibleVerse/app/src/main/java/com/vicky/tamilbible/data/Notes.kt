package com.vicky.tamilbible.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A personal note; [ref] is set when it was made from verses in the reader (e.g. "யோவான் 3:16"). */
data class Note(val id: Long, val title: String, val body: String, val ref: String?, val updated: Long)

/** Stores notes on the phone only (files/notes.json). */
class NotesStore(context: Context) {
    private val file = File(context.filesDir, "notes.json")

    fun all(): List<Note> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Note(o.getLong("id"), o.optString("title"), o.optString("body"),
                o.optString("ref").ifBlank { null }, o.getLong("updated"))
        }.sortedByDescending { it.updated }
    }.getOrDefault(emptyList())

    private fun save(notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)
                .put("ref", it.ref ?: "").put("updated", it.updated))
        }
        val tmp = File(file.parentFile, "notes.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }

    fun upsert(note: Note) = save(all().filter { it.id != note.id } + note)
    fun delete(id: Long) = save(all().filter { it.id != id })
}
