package com.vicky.tamilbible.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.launch

/** One row of the list: a section title, or a numbered praise line. */
private data class PraiseRow(val number: Int?, val text: String)

/** Reads assets/stothiram.txt — one praise per line, "# " lines are section titles. */
private fun loadPraises(context: Context): List<PraiseRow> {
    var n = 0
    return context.assets.open("stothiram.txt").bufferedReader().readLines()
        .map { it.trim() }.filter { it.isNotEmpty() }
        .map { if (it.startsWith("#")) PraiseRow(null, it.removePrefix("#").trim()) else PraiseRow(++n, it) }
}

@Composable
fun PraiseScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val rows = remember { loadPraises(context) }
    val total = remember(rows) { rows.count { it.number != null } }
    // Reopen where the reader stopped last time.
    val listState = rememberLazyListState(prefs.getInt("praise_pos", 0).coerceIn(0, (rows.size - 1).coerceAtLeast(0)))
    val scope = rememberCoroutineScope()
    var showGoTo by remember { mutableStateOf(false) }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { prefs.edit().putInt("praise_pos", it).apply() }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)
                .height(60.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "பின்செல்", tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Text(
                "$total ஸ்தோத்திரம்",
                fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1f),
            )
            OutlinedButton(onClick = { showGoTo = true }, modifier = Modifier.padding(end = 8.dp)) {
                Text("Go to")
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
            items(rows) { row ->
                if (row.number == null) {
                    Text(
                        row.text,
                        fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                    )
                } else {
                    Text(
                        "${row.number}. ${row.text}",
                        fontFamily = TamilFont, fontSize = (vm.fontSize + 3).sp, lineHeight = ((vm.fontSize + 3) * 1.5f).sp,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }

    if (showGoTo) {
        var input by remember { mutableStateOf("") }
        val num = input.toIntOrNull()
        val valid = num?.let { it in 1..total } ?: false
        AlertDialog(
            onDismissRequest = { showGoTo = false },
            title = { Text("எண்ணைக் கொடுக்கவும் (1 - $total)", fontFamily = TamilFont, fontSize = 17.sp) },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { v -> input = v.filter(Char::isDigit).take(4) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(enabled = valid, onClick = {
                    val index = rows.indexOfFirst { it.number == num }
                    showGoTo = false
                    if (index >= 0) scope.launch { listState.scrollToItem(index) }
                }) { Text("Go") }
            },
            dismissButton = { TextButton(onClick = { showGoTo = false }) { Text("ரத்து", fontFamily = TamilFont) } },
        )
    }
}
