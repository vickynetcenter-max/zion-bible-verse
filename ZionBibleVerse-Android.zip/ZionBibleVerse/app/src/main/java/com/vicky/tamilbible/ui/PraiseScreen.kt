package com.vicky.tamilbible.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.BibleViewModel
import com.vicky.tamilbible.ui.theme.TamilFont
import kotlinx.coroutines.launch

private const val PER_PAGE = 10

/** A numbered praise; [section] is set on the first praise of each section. */
private data class Praise(val number: Int, val text: String, val section: String?)

/** Reads assets/stothiram.txt — one praise per line, "# " lines are section titles. */
/** The praise lines as shipped in assets/stothiram.txt, numbered 1…N (used by the admin app too). */
internal fun praiseLines(context: Context): List<String> =
    context.assets.open("stothiram.txt").bufferedReader().readLines()
        .map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }

/** Praise list with the admin's corrections (from the church sheet) applied by number. */
private fun loadPraises(context: Context): List<Praise> {
    val fixes = com.vicky.tamilbible.data.RemoteCache.load(context).praise.associate { it.n to it.text }
    var n = 0
    var pending: String? = null
    val out = mutableListOf<Praise>()
    context.assets.open("stothiram.txt").bufferedReader().readLines()
        .map { it.trim() }.filter { it.isNotEmpty() }
        .forEach { line ->
            if (line.startsWith("#")) pending = line.removePrefix("#").trim()
            else { n++; out += Praise(n, fixes[n] ?: line, pending); pending = null }
        }
    return out
}

@Composable
fun PraiseScreen(vm: BibleViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val praises = remember { loadPraises(context) }
    val pages = remember(praises) { praises.chunked(PER_PAGE) }
    val total = praises.size
    val scope = rememberCoroutineScope()
    var showGoTo by remember { mutableStateOf(false) }

    // Swipe sideways between pages of 10, like chapters in the reader; reopen on the last page.
    val pager = rememberPagerState(
        initialPage = prefs.getInt("praise_page", 0).coerceIn(0, (pages.size - 1).coerceAtLeast(0))
    ) { pages.size }
    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage }.collect { prefs.edit().putInt("praise_page", it).apply() }
    }

    Column(Modifier.fillMaxSize().pageBackground().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)
                .height(60.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "பின்செல்", tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Text(
                "$total ஸ்தோத்திரம்",
                fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1f),
            )
            OutlinedButton(onClick = { showGoTo = true }, modifier = Modifier.padding(end = 8.dp)) {
                Text("Go to")
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        HorizontalPager(state = pager, key = { it }, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            LazyColumn(Modifier.fillMaxSize()) {
                items(pages[page], key = { it.number }) { p ->
                    if (p.section != null) {
                        Text(
                            p.section,
                            fontFamily = TamilFont, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                        )
                    }
                    Text(
                        "${p.number}. ${p.text}",
                        fontFamily = TamilFont, fontSize = (vm.fontSize + 2).sp,
                        lineHeight = ((vm.fontSize + 2) * 1.5f).sp,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                }
            }
        }

        // Page bar: ‹  பக்கம் 3 / 26 · 21–30  ›
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().height(56.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val cur = pager.currentPage
                IconButton(enabled = cur > 0, onClick = { scope.launch { pager.animateScrollToPage(cur - 1) } }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "முந்தைய பக்கம்")
                }
                val first = pages.getOrNull(cur)?.firstOrNull()?.number ?: 0
                val last = pages.getOrNull(cur)?.lastOrNull()?.number ?: 0
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("பக்கம் ${cur + 1} / ${pages.size}", fontFamily = TamilFont,
                        fontWeight = FontWeight.SemiBold, fontSize = 15.sp, textAlign = TextAlign.Center)
                    Text("$first – $last", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(enabled = cur < pages.size - 1, onClick = { scope.launch { pager.animateScrollToPage(cur + 1) } }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "அடுத்த பக்கம்")
                }
            }
        }
    }

    if (showGoTo) {
        var input by remember { mutableStateOf("") }
        val num = input.toIntOrNull()
        val valid = num?.let { it in 1..total } ?: false
        AlertDialog(
            onDismissRequest = { showGoTo = false },
            title = { Text("எண்ணைக் கொடுக்கவும் (1 - $total)", fontFamily = TamilFont, fontSize = 17.sp) },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { v -> input = v.filter(Char::isDigit).take(4) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(enabled = valid, onClick = {
                    showGoTo = false
                    if (num != null) scope.launch { pager.scrollToPage((num - 1) / PER_PAGE) }
                }) { Text("Go") }
            },
            dismissButton = { TextButton(onClick = { showGoTo = false }) { Text("ரத்து", fontFamily = TamilFont) } },
        )
    }
}
