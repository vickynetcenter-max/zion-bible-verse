package com.vicky.tamilbible.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vicky.tamilbible.data.QuizEngine
import com.vicky.tamilbible.data.QuizProgress
import com.vicky.tamilbible.games.GameProgress
import com.vicky.tamilbible.games.GameStore
import com.vicky.tamilbible.games.Games
import com.vicky.tamilbible.ui.theme.TamilFont

/** 🎮 விளையாட்டுகள் — all the Bible games in one place. */
@Composable
fun GamesScreen(
    onBack: () -> Unit,
    onQuiz: () -> Unit, onLetterPath: () -> Unit, onScramble: () -> Unit,
    onMemory: () -> Unit, onWho: () -> Unit, onTimeline: () -> Unit,
) {
    val context = LocalContext.current
    val quiz = remember { QuizProgress(context) }
    fun flow(game: String) = GameStore.progress(context, game)
    val empty = GameProgress(1, emptyMap())
    val lp by remember { flow(Games.LETTER_PATH) }.collectAsState(empty)
    val sc by remember { flow(Games.SCRAMBLE) }.collectAsState(empty)
    val me by remember { flow(Games.MEMORY) }.collectAsState(empty)
    val wh by remember { flow(Games.WHO) }.collectAsState(empty)
    val tl by remember { flow(Games.TIMELINE) }.collectAsState(empty)

    GameScaffold("விளையாட்டுகள்", GameThemes.QUIZ, onBack) {
        Text("விளையாடிக்கொண்டே வேதாகமத்தைக் கற்றுக்கொள்ளுங்கள்", fontFamily = TamilFont, fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        GameCard("❓", "வேத வினாடி வினா", "Bible Quiz", "கேள்விகள் · நேரம் · பரிசுகள்",
            quiz.unlocked().coerceAtMost(QuizEngine.LEVELS), QuizEngine.LEVELS, quiz.totalStars(), GameThemes.QUIZ, onQuiz)
        GameCard("✍️", "எழுத்துப் பாதை", "Letter Path", "எழுத்துகளை வரிசையாக இணைத்து எல்லாக் கட்டங்களையும் ஒரே கோட்டில் நிரப்புங்கள்",
            lp.unlocked, Games.LEVELS, lp.totalStars, GameThemes.LETTER_PATH, onLetterPath)
        GameCard("🧩", "வசன அடுக்கு", "Verse Scramble", "கலைந்த வார்த்தைகளைச் சரியான வரிசையில் அடுக்கி வசனத்தை அமையுங்கள்",
            sc.unlocked, Games.LEVELS, sc.totalStars, GameThemes.SCRAMBLE, onScramble)
        GameCard("🃏", "ஜோடி பொருத்து", "Memory Match", "அட்டைகளைத் திருப்பி வேதாகம ஜோடிகளைக் கண்டுபிடியுங்கள்",
            me.unlocked, Games.LEVELS, me.totalStars, GameThemes.MEMORY, onMemory)
        GameCard("🕵️", "யார் இவர்?", "Who am I?", "குறிப்புகளை வைத்து வேதாகம நபரைக் கண்டுபிடியுங்கள்",
            wh.unlocked, Games.LEVELS, wh.totalStars, GameThemes.WHO, onWho)
        GameCard("⏳", "காலவரிசை", "Timeline", "வேதாகம நிகழ்வுகளை நடந்த வரிசையில் அடுக்குங்கள்",
            tl.unlocked, Games.LEVELS, tl.totalStars, GameThemes.TIMELINE, onTimeline)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GameCard(
    icon: String, title: String, english: String, desc: String,
    level: Int, levels: Int, stars: Int, theme: GameTheme, onPlay: () -> Unit,
) {
    Surface(shape = RoundedCornerShape(22.dp), shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).clickable(onClick = onPlay)) {
        Box(Modifier.background(Brush.linearGradient(listOf(theme.start, theme.end)))) {
            // Big faint icon in the corner
            Text(icon, fontSize = 84.sp, modifier = Modifier.align(Alignment.TopEnd).padding(end = 6.dp)
                .graphicsLayer { alpha = 0.16f; rotationZ = -12f })
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center) { Text(icon, fontSize = 22.sp) }
                    Spacer(Modifier.size(12.dp))
                    Column {
                        Text(title, color = Color.White, fontFamily = TamilFont, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Text(english, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }
                Text(desc, color = Color.White.copy(alpha = 0.92f), fontFamily = TamilFont, fontSize = 13.sp, lineHeight = 19.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("நிலை $level / $levels", color = Color.White, fontFamily = TamilFont, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("⭐ $stars / ${levels * 3}", color = Color.White, fontSize = 12.sp)
                }
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.25f))) {
                    Box(Modifier.fillMaxWidth(((level - 1).toFloat() / levels).coerceIn(0.03f, 1f)).height(6.dp)
                        .clip(RoundedCornerShape(3.dp)).background(GAME_GOLD))
                }
                Surface(shape = RoundedCornerShape(20.dp), color = Color.White, contentColor = theme.start) {
                    Text(if (level > 1) "▶ தொடர்" else "▶ விளையாடு", fontFamily = TamilFont, fontWeight = FontWeight.Bold,
                        fontSize = 14.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp))
                }
            }
        }
    }
}
