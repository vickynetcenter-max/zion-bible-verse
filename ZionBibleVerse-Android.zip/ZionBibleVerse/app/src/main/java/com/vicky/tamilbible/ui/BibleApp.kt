package com.vicky.tamilbible.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.vicky.tamilbible.BibleViewModel

enum class Screen { Dashboard, Books, Reader, Search, Settings, Praise, Social, Songs, Notes, Legal, Reminders, Quiz }

@Composable
fun BibleApp(vm: BibleViewModel) {
    // Skip the splash when opened from the daily-verse notification.
    var splashDone by rememberSaveable { mutableStateOf(vm.pendingOpen != null) }
    // Surface sets the default text colour from the theme, so text is white in black mode.
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
    ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            !splashDone -> SplashScreen(onDone = { splashDone = true })
            vm.totalPages == 0 -> CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            else -> LoadedApp(vm)
        }
    }
    }
}

@Composable
private fun LoadedApp(vm: BibleViewModel) {
    // Simple back stack of screen names; Dashboard is always the root.
    var stack by rememberSaveable { mutableStateOf(listOf(Screen.Dashboard.name)) }
    val screen = Screen.valueOf(stack.last())
    fun push(s: Screen) { stack = stack + s.name }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun home() { stack = listOf(Screen.Dashboard.name) }
    /** Opening the reader always sits directly on top of the dashboard. */
    fun openReader() { stack = listOf(Screen.Dashboard.name, Screen.Reader.name) }

    var booksTestament by rememberSaveable { mutableStateOf("OT") }

    // Hoisted so the reading position survives trips to the book list and search.
    val pagerState = rememberPagerState(
        initialPage = vm.savedPage.coerceIn(0, vm.totalPages - 1)
    ) { vm.totalPages }

    BackHandler(enabled = stack.size > 1) { pop() }

    val open = vm.pendingOpen
    LaunchedEffect(open) {
        if (open != null) {
            vm.goTo(open.book, open.chapter, open.verse)
            openReader()
            vm.consumeOpen(open)
        }
    }

    AnimatedContent(
        targetState = screen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen"
    ) { target ->
        when (target) {
            Screen.Dashboard -> DashboardScreen(
                vm = vm,
                lastPage = pagerState.currentPage,
                onBible = {
                    // Open the book list on the testament of the chapter last read.
                    booksTestament = vm.refOf(pagerState.currentPage).first.testament
                    push(Screen.Books)
                },
                onContinue = { openReader() },
                onOpenVerse = { b, c, v -> vm.goTo(b, c, v); openReader() },
                onPraise = { push(Screen.Praise) },
                onSettings = { push(Screen.Settings) },
                onSearch = { push(Screen.Search) },
                onSongs = { push(Screen.Songs) },
                onNotes = { push(Screen.Notes) },
                onLegal = { push(Screen.Legal) },
                onReminders = { push(Screen.Reminders) },
                onQuiz = { push(Screen.Quiz) },
                onSocial = { push(Screen.Social) },
            )
            Screen.Reader -> ReaderScreen(
                vm = vm,
                pagerState = pagerState,
                onOpenBooks = {
                    booksTestament = vm.refOf(pagerState.currentPage).first.testament
                    push(Screen.Books)
                },
                onOpenSearch = { push(Screen.Search) },
                onHome = { home() },
                onAddNote = { ref, text -> vm.noteDraft = ref to text; push(Screen.Notes) },
            )
            Screen.Books -> BooksScreen(
                vm = vm,
                currentBookOrd = vm.refOf(pagerState.currentPage).first.ord,
                initialTestament = booksTestament,
                onClose = { pop() },
                onPick = { book, chapter ->
                    vm.goTo(book, chapter)
                    openReader()
                },
            )
            Screen.Search -> SearchScreen(
                vm = vm,
                onClose = { pop() },
                onPick = { book, chapter, verse ->
                    vm.goTo(book, chapter, verse)
                    openReader()
                },
            )
            Screen.Settings -> SettingsScreen(vm = vm, onBack = { pop() }, onLegal = { push(Screen.Legal) })
            Screen.Praise -> PraiseScreen(vm = vm, onBack = { pop() })
            Screen.Social -> SocialScreen(lang = vm.lang, onBack = { pop() })
            Screen.Songs -> SongsScreen(vm = vm, onBack = { pop() })
            Screen.Notes -> NotesScreen(vm = vm, onBack = { pop() })
            Screen.Legal -> LegalScreen(onBack = { pop() })
            Screen.Reminders -> CalendarScreen(lang = vm.lang, onBack = { pop() })
            Screen.Quiz -> QuizScreen(vm = vm, onBack = { pop() })
        }
    }
}
