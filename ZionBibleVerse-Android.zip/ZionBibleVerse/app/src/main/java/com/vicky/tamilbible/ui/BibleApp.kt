package com.vicky.tamilbible.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.vicky.tamilbible.BibleViewModel

enum class Screen { Reader, Books, Search }

@Composable
fun BibleApp(vm: BibleViewModel) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        if (vm.totalPages == 0) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        } else {
            LoadedApp(vm)
        }
    }
}

@Composable
private fun LoadedApp(vm: BibleViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.Reader) }
    // Hoisted so the reading position survives trips to the book list and search.
    val pagerState = rememberPagerState(
        initialPage = vm.savedPage.coerceIn(0, vm.totalPages - 1)
    ) { vm.totalPages }

    BackHandler(enabled = screen != Screen.Reader) { screen = Screen.Reader }

    AnimatedContent(
        targetState = screen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen"
    ) { target ->
        when (target) {
            Screen.Reader -> ReaderScreen(
                vm = vm,
                pagerState = pagerState,
                onOpenBooks = { screen = Screen.Books },
                onOpenSearch = { screen = Screen.Search },
            )
            Screen.Books -> BooksScreen(
                vm = vm,
                currentBookOrd = vm.refOf(pagerState.currentPage).first.ord,
                onClose = { screen = Screen.Reader },
                onPick = { book, chapter ->
                    vm.goTo(book, chapter)
                    screen = Screen.Reader
                },
            )
            Screen.Search -> SearchScreen(
                vm = vm,
                onClose = { screen = Screen.Reader },
                onPick = { book, chapter, verse ->
                    vm.goTo(book, chapter, verse)
                    screen = Screen.Reader
                },
            )
        }
    }
}
