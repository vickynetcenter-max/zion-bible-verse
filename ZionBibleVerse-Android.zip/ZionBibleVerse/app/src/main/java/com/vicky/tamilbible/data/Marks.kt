package com.vicky.tamilbible.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A verse the reader has highlighted (colour index into [HighlightColors]) and/or bookmarked. */
data class Mark(
    val book: Int,
    val chapter: Int,
    val verse: Int,
    val color: Int?,       // null = no highlight
    val bookmark: Boolean,
    val time: Long,
) {
    val key get() = key(book, chapter, verse)
    companion object { fun key(b: Int, c: Int, v: Int) = "$b:$c:$v" }
}

/** The five highlight colours (light-theme values; drawn softer in black mode). */
object HighlightColors {
    val ARGB = listOf(0xFFFFE066, 0xFF9BD8A0, 0xFF8EC5F2, 0xFFF6B3CF, 0xFFFFC27A)
    val NAMES_TA = listOf("மஞ்சள்", "பச்சை", "நீலம்", "இளஞ்சிவப்பு", "ஆரஞ்சு")
    val NAMES_EN = listOf("Yellow", "Green", "Blue", "Pink", "Orange")
}

/** Highlights and bookmarks, stored on this phone only (files/marks.json). */
class MarkStore(context: Context) {
    private val file = File(context.filesDir, "marks.json")

    fun load(): Map<String, Mark> = runCatching {
        if (!file.exists()) return emptyMap()
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Mark(o.getInt("b"), o.getInt("c"), o.getInt("v"),
                if (o.has("color") && !o.isNull("color")) o.getInt("color") else null,
                o.optBoolean("bm"), o.optLong("t"))
        }.associateBy { it.key }
    }.getOrDefault(emptyMap())

    fun save(marks: Collection<Mark>) {
        val arr = JSONArray()
        marks.forEach {
            arr.put(JSONObject().put("b", it.book).put("c", it.chapter).put("v", it.verse)
                .put("color", it.color ?: JSONObject.NULL).put("bm", it.bookmark).put("t", it.time))
        }
        val tmp = File(file.parentFile, "marks.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }
}
