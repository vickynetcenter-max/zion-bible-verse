plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.vicky.tamilbible"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vicky.zionbibleverse"
        minSdk = 26
        targetSdk = 34
        versionCode = 49
        versionName = "5.9"
    }

    // Permanent release key, supplied by GitHub Actions secrets (see README "Signing").
    // With the same key every build installs as an UPDATE over the previous one.
    val zionKeystore = System.getenv("ZION_KEYSTORE")?.let { file(it) }?.takeIf { it.exists() }
    signingConfigs {
        if (zionKeystore != null) {
            create("zion") {
                storeFile = zionKeystore
                storePassword = System.getenv("ZION_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ZION_KEY_ALIAS") ?: "zion"
                keyPassword = System.getenv("ZION_KEY_PASSWORD") ?: System.getenv("ZION_KEYSTORE_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // Falls back to the debug key only when no keystore is provided (e.g. a local test build).
            signingConfig = if (zionKeystore != null) signingConfigs.getByName("zion") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    // Material3 1.3+ no longer pulls in the icon set, so add it explicitly
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
