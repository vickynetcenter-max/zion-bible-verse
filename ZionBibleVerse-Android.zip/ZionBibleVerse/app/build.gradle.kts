plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Instant announcement push (Firebase Cloud Messaging) switches on when app/google-services.json is present.
if (file("google-services.json").exists()) apply(plugin = "com.google.gms.google-services")

android {
    namespace = "com.vicky.tamilbible"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vicky.zionbibleverse"
        minSdk = 26
        targetSdk = 34
        versionCode = 64
        versionName = "7.4"
        // Google Apps Script web-app link (…/exec) for announcements + verse corrections.
        buildConfigField("String", "CHURCH_API_URL", "\"https://script.google.com/macros/s/AKfycbzqitO_nLWizCp6ekg39qUTly3qjUIPZJN1I-bL08lYvsvCCLVr7D7cfql9uxKcdYfe/exec\"")
    }

    // Two apps from one project: the members' app and the admin app.
    flavorDimensions += "role"
    productFlavors {
        create("user") {
            dimension = "role"
            applicationId = "com.vicky.zionbibleverse"
            buildConfigField("Boolean", "IS_ADMIN", "false")
        }
        create("admin") {
            dimension = "role"
            applicationId = "com.vicky.zionbibleverse.admin"
            buildConfigField("Boolean", "IS_ADMIN", "true")
        }
    }

    // Permanent release key, supplied by GitHub Actions secrets (see README "Signing").
    // With the same key every build installs as an UPDATE over the previous one.
    val zionKeystore = System.getenv("ZION_KEYSTORE")?.let { file(it) }?.takeIf { it.exists() && it.length() > 0 }
    // On GitHub Actions never fall back to a temporary key: an APK signed with a different key
    // can't update the installed app ("package conflicts"). Fail the build instead.
    if (System.getenv("CI") == "true" && zionKeystore == null) {
        throw GradleException("Release signing key missing — add the ZION_KEYSTORE_BASE64 and ZION_KEYSTORE_PASSWORD secrets.")
    }
    signingConfigs {
        if (zionKeystore != null) {
            create("zion") {
                storeFile = zionKeystore
                storePassword = System.getenv("ZION_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ZION_KEY_ALIAS") ?: "zion"
                keyPassword = System.getenv("ZION_KEY_PASSWORD") ?: System.getenv("ZION_KEYSTORE_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // Falls back to the debug key only when no keystore is provided (e.g. a local test build).
            signingConfig = if (zionKeystore != null) signingConfigs.getByName("zion") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(composeBom)
    implementation(platform("com.google.firebase:firebase-bom:33.4.0"))
    implementation("com.google.firebase:firebase-messaging")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    // Material3 1.3+ no longer pulls in the icon set, so add it explicitly
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
