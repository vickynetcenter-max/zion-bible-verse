# Zion Bible Verse — Tamil + English Bible (Android)

Native Android app, Kotlin + Jetpack Compose. Works fully offline.

## Build
1. Open this folder in **Android Studio (Koala 2024.1 or newer)**.
2. Let Gradle sync (JDK 17, downloads Gradle 8.9 / AGP 8.5.2 automatically).
3. Run on a device/emulator, or build an APK:
   ```
   ./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
   ./gradlew assembleRelease      # signed with debug key — swap in your keystore for Play Store
   ```
Min Android 8.0 (API 26).

## Features
- Tamil / English / Both (parallel, Tamil with English beneath) — one tap in the bottom bar
- Swipe left/right through all 1,189 chapters; ‹ › buttons too
- Book list split into Old/New Testament, filter by Tamil or English name, chapter grid
- Search by word (அன்பு, love) or reference (யோவான் 3:16, John 3:16, Ps 23) — jumps and highlights the verse
- Tap verses to select → Copy or Share with reference
- Text size slider, Light / Dark / System theme
- Remembers last chapter, language, size and theme

## Data
- `app/src/main/assets/bible.db` — SQLite built from your `tamil_bible.json`
  plus the King James Version (public domain) for English. All 31,102 verses align 1:1.
  Tables: `books(ord, code, ta, en, testament, chapters)`, `verses(book, chapter, verse, ta, en)`.
- If you rebuild the DB, bump `DB_VERSION` in `BibleRepository.kt` so installed apps re-copy it.

## Fonts
Noto Serif Tamil and Literata (SIL Open Font License), bundled in `res/font`.

## Code map
```
MainActivity.kt          edge-to-edge + theme
BibleViewModel.kt        state, settings (SharedPreferences), page⇄reference, ref parser
data/BibleRepository.kt  SQLite access (copy-from-assets, chapter, search)
ui/BibleApp.kt           screen switching, shared PagerState
ui/ReaderScreen.kt       pager, verse rendering, selection, settings sheet
ui/BooksScreen.kt        testament tabs, book filter, chapter grid
ui/SearchScreen.kt       word + reference search
ui/theme/Theme.kt        colors + font families
```


## v1.1 changes
- Animated Zion Cathedral logo splash screen, then a dashboard with: Old Testament, New Testament,
  ஸ்தோத்திர பலி (placeholder), Settings, Social media, Exit — plus "continue reading" and 24/7 prayer call buttons.
- Default background is white; Settings lets the reader switch to black (or follow the phone).
- Tamil font: Noto Sans Tamil. English font: Literata.
- Launcher icon redrawn from the Zion Cathedral emblem (vector; swap for the official logo when available).
- Church details and social links live in `data/Church.kt` (set the exact YouTube channel URL there).

## v1.2 changes
- "இன்றைய தேவ வார்த்தை" card at the top of the dashboard (read the chapter or share the verse).
- Daily notification with the same verse, default 6:00 AM; on/off and time in Settings.
  Tapping it opens the reader at that verse. Re-armed after reboot/app update.
- Promise-verse list (positive verses only, one per day, changes at midnight, cycling) lives in `data/DailyVerse.kt`.

## v1.5 changes
- ஸ்தோத்திர பலி: numbered praise list with "Go to" number jump; remembers where you stopped.
  The list is plain text in `app/src/main/assets/stothiram.txt` — one praise per line,
  lines starting with `# ` are section titles. Replace/extend it with the church's own list.

## v2.0 changes
- Dashboard fits one screen on any phone (no scrolling): compact header, today's verse,
  continue-reading strip, 3×2 tile grid that stretches to fill, one-line prayer numbers.
- Faint Zion Cathedral logo watermark behind the reader, book list, search, praise and settings pages
  (`ui/BibleBackdrop.kt`, `Modifier.pageBackground()`).
- Promise notifications: up to 15 a day (adjustable 1–15 in Settings) at random times
  between 6 AM and 10 PM; every one shows the same "இன்றைய தேவ வார்த்தை" (the day's verse).

## v2.7 changes
- Today's verse is now different for each install: every phone shuffles the promise list with
  its own random seed (saved once), then shows one verse per day in that order.

## v2.8 changes
- Notifications fixed at 60 a day (6 AM–10 PM, random times, ~every 16 min); the on/off and
  count controls were removed from Settings.
- New high-importance channel with the phone's default notification sound + vibration
  (old channel deleted, since Android doesn't allow changing a channel's sound later).

## v2.9 changes
- Reader: row of chapter numbers under the top bar (current one in red, centred); swipe it and tap to jump.
- Dashboard: "அமைப்பு" tile replaced by "வார்த்தை தேடல்" (word search); Settings stays on the user icon.
- Book list search box now reads "அதிகாரத்தைத் தேடு".
- Black mode: search results and any text without an explicit colour now follow the theme (white).

## v2.9 changes
- Reader: row of chapter numbers under the top bar (current one red, centred); swipe and tap to jump.
- Book list search box now says "அதிகாரத்தைத் தேடு".
- Dashboard: "வார்த்தை தேடல்" tile replaces "அமைப்பு" (Settings is on the profile icon).
- Search: அனைத்தும் / பழைய / புதிய ஏற்பாடு scope, book picker, on-screen Tamil letter keypad.
- Black mode: all default text now follows the theme (search results were black on black).

## v3.0 changes
- Dashboard now has 8 tiles (4 × 2): + பாடல்கள் (Songs) and குறிப்புகள் (Notes).
- Songs: read from `app/src/main/assets/songs.txt` ("## 1. Title", optional "youtube: <link>",
  then lyrics). Searchable list, lyrics view, YouTube button. Add the church's own songs there.
- Notes: personal / sermon notes stored on the phone; in the reader, select verses → "குறிப்பு"
  to start a note with the verse reference and text.

## v3.1 changes
- Reader: the verse actions (குறிப்பு / நகலெடு / பகிர்) are a floating panel that appears only while
  verses are selected — v3.2: small vertical pill on the right, slides down from the top; ✕ last.

## v3.3 changes
- Disclaimer & Privacy Policy (English) in Settings › "Disclaimer & Privacy Policy".
- One-time "Before you begin" notice on first launch (I agree / Read); the notification
  permission is asked only after it. Bump `Legal.VERSION` to show it again after big changes.
- `docs/privacy-policy.html` — the same text as a web page for the Play Store privacy-policy URL
  (publish with GitHub Pages: Settings › Pages › Branch: main, folder: /docs).

## v3.4 changes
- Dashboard: Old/New Testament tiles merged into one "பைபிள்" tile (the book list has both tabs). 7 tiles.

## v3.5 changes
- Exit moved from the dashboard into Settings (with a confirm dialog). Dashboard: 6 tiles, 3 × 2.

## v3.9 changes
- New "நினைவூட்டல்" (Reminders) tile: church programme reminders with sound. Programmes come from
  `app/src/main/assets/church_events.txt` ("title | SUN WED | 19:00" per line, DAILY for every day).
  Each can be switched off; one "remind before" setting (on time / 15 / 30 / 60 min). Re-armed after reboot.
- Dashboard: 7 tiles (4 + 3).

## v4.0 changes
- "நினைவூட்டல்" is now a personal booking calendar (on this phone only, files/bookings.json):
  month view with booked dates in red, tap a date to see what is booked or that it is free,
  "+ முன்பதிவு" to add (title, date, optional time, note, reminder). Saving on a date that
  already has a booking warns and offers "another date". Reminders: 8 PM the day before and
  on the day. Church programmes (church_events.txt) are listed below the calendar.
- Privacy policy updated to mention calendar entries (still stored only on the phone).

## v4.1 changes
- Songs tile removed from the dashboard for now (code kept). Dashboard: 6 tiles, 3 × 2.

## v4.2 changes
- "வேத வினாடி வினா" (Bible Quiz) tile — 15 levels, 10 questions each, fresh random questions
  every play (curated facts in `data/QuizBank.kt` + questions generated from the Bible DB:
  which book, which chapter, fill the missing word, next book, testament, chapter count).
  Timer + score (10 + speed bonus), stars (7/9/10 correct), 7 correct unlocks the next level,
  confetti on a new high score, and a prize box per level (badge + promise verse).
  Progress stays on the phone; reset from the quiz screen.
- Dashboard: 7 tiles (4 + 3).

## v4.3 changes
- Dashboard tiles in rows of three (3 + 3 + 1, last tile centred).

## v4.3 changes
- Dashboard: tiles 3 per row (fixed height), page scrolls; last row (Social media) centred.
- v4.4: dashboard scrolls; tiles have a fixed height.
- v4.5: dashboard tile names always on one line (font shrinks slightly to fit, e.g. வேத வினாடி வினா).

## v4.6 changes
- Quiz levels page is now a journey through the life of Jesus: cartoon scenes drawn in code
  (`ui/JesusJourney.kt`, 15 scenes from the nativity to the resurrection), a sky that goes from
  the night over Bethlehem to the resurrection sunrise, and a winding road joining the 15 levels.
  The page opens scrolled to the player's current level.
- v4.7: dashboard "ஸ்தோத்திர / பலி" label on two lines.
- v4.8: two-line tile names (ஸ்தோத்திர/பலி, வார்த்தை/தேடல், வேத வினாடி/வினா, சோசியல்/மீடியா); all tile names share one font size.

## v5.0 changes — harder Bible Quiz, 20 levels
- 20 levels; the journey map has 20 scenes (adds flight to Egypt, Nicodemus, transfiguration,
  Zacchaeus, raising of Lazarus). 20 badges.
- Harder questions: exact reference (with near-miss options: next verse, next chapter, sister
  book), "which verse comes next" (options from the same chapter), missing word with look-alike
  words from the same chapter, book position in the Bible, chapter counts with close numbers,
  wrong books chosen from the same section (Gospels, Pauline letters…). 30 new hard facts
  (89 curated in total). Timer: 30s (1–7), 25s (8–14), 22s (15–20).
- No repeats: each phone remembers every question it has asked (prefs "quiz_seen") and avoids
  them; a pool only starts over once it is used up. Random per player and per attempt.

## v5.1 changes
- ஸ்தோத்திர பலி now has the full 1000 ஸ்தோத்திரங்கள் (10 sections, 100 pages of 10), from the supplied book.
- v5.2: Disclaimer credits the public-domain source of the praise list.
- v5.3: word search box shows just a search icon and "வார்த்தை தேடல்".

## v5.4 changes — Highlights & Bookmarks
- Reader: select verses → "வண்ணம்" opens 5 highlight colours (yellow, green, blue, pink, orange)
  + remove; "குறி" bookmarks / un-bookmarks. Highlighted verses show their colour (softer in black
  mode); bookmarked verses show a 🔖 at the right.
- New "என் வசனங்கள்" (My Verses) tile: Bookmarks and Highlights tabs with counts, colour filter,
  newest / Bible-order sort, tap to open the verse in the reader, remove, and share the whole list.
- Stored on the phone only (files/marks.json); privacy policy updated.
- Dashboard: 8 tiles; a short last row is centred.

## Signing (permanent key)
Release builds are signed with the church's permanent key so every new APK installs as an update.
GitHub repo → Settings → Secrets and variables → Actions → add `ZION_KEYSTORE_BASE64` and
`ZION_KEYSTORE_PASSWORD`; `.github/workflows/build.yml` restores the key before building.
Keep `zion-release.jks` and its password safe — if lost, installed apps can no longer be updated.
- v5.6: larger default reading size (22sp, applied once to everyone), praise list a bit larger; verse action panel labels always in English.

## v5.6 changes
- Bigger reading text by default (22sp; Noto Sans Tamil looks smaller than the old serif font).
  Praise list is 2sp larger than the reading size.
- Dashboard tiles back to large fixed sizes (132dp tall, 48dp icon, 15sp name) — never shrunk;
  the page scrolls instead.
- Verse action panel (right side) labels are always English: selected, Colour, Bookmark/Unmark,
  Note, Copy, Share.

## v5.7 changes
- Daily verse notification: 5 fixed times a day — 6 AM, 10 AM, 12 noon, 4 PM, 8 PM (was 60 random). Disclaimer updated.

## v6.1 changes (merged on top of 6.0)
- "Before you begin / I agree" and the "notification permission asked" flag are kept in
  `legal.xml`, excluded from Android backup (`res/xml/*_rules.xml`), so every fresh install
  shows the notice and asks for notification permission again.
- Dashboard shows a "🔔 Turn on Today's Word notifications" banner whenever notifications are off;
  the button asks for permission or opens the app's notification settings. Hidden once enabled.

## v6.2 — two apps: members + admin
- Product flavors: `user` (com.vicky.zionbibleverse, "Zion Bible Verse") and `admin`
  (com.vicky.zionbibleverse.admin, "Zion Admin", navy icon). Build: `assembleUserRelease assembleAdminRelease`.
- Backend: Google Apps Script web app (`zion-apps-script.gs`) on a Google Sheet with two tabs,
  Announcements and Corrections. Set its /exec link in `app/build.gradle.kts` → `CHURCH_API_URL`.
- Admin app: password login (checked by the script, never stored in code), send announcements,
  correct verses (shows the current text to copy & fix), list + delete.
- Members app: syncs on open and at 6/10/12/4/8 → notifications for new announcements
  (channel "சபை அறிவிப்புகள்"), 🔔 bell with red dot on the dashboard → announcements list.
  Verse corrections are applied over bible.db everywhere (reader, search, quiz, daily verse),
  cached for offline use.
- INTERNET permission added; privacy policy updated (Legal.VERSION = 2, users see the notice once more).
- Announcements can carry a picture: the admin app picks a photo (Android photo picker, no permission),
  shrinks it to ≤1280px JPEG (~150–300 KB) and sends it; the script stores it in the Drive folder
  "Zion Announcements" (view-only link) and keeps the file id in the sheet's `image` column.
  Members see it in the notification (big picture) and in the announcements list (tap = full screen).
  Deleting an announcement also trashes its picture.

## v6.3
- CHURCH_API_URL set to the church Apps Script web app. First release with announcements, pictures, verse corrections and the Zion Admin app.

## v6.4
- Admin app: 🙏 ஸ்தோத்திரம் tab — correct any praise-list line by number (shows current text to copy & fix).
  Script stores them in a "Praise" tab (created automatically); members' app applies them by number.
- CI safety: a GitHub build without the signing secrets now FAILS instead of producing an APK signed with a
  temporary key (that would cause "package conflicts" for everyone who has the app).

## v6.5
- Members: ✕ on each announcement and "எல்லாம் அழி" (hidden on that phone only); opening the list
  clears announcement notifications. Newest first; every post disappears 24 h after it goes out
  (list and status bar).
- Instant push: Firebase Cloud Messaging topic "zion-news". The app code is ready; it switches on when
  `app/google-services.json` (with BOTH package names) is added. Script sends the push on announce /
  when a scheduled post becomes due (needs FIREBASE_PROJECT_ID + appsscript.json scopes).
- Admin: gradient header with counts (live / scheduled / corrections / praise), bottom navigation,
  "⚡ இப்போதே / ⏰ பின்னர்" scheduling up to 7 days ahead, preview of how members will see the post,
  list shows 🟢 live / ⏰ scheduled / ⌛ finished.
- Script: `publishAt` + `pushed` columns, 5-minute trigger `publishDue`, admin `list` action.

## v6.6
- app/google-services.json added (Firebase project zion-bible-verse, both packages) → instant announcement push is ON.

## v6.6
- app/google-services.json added (Firebase project zion-bible-verse, both packages) → instant announcement push is on.

## v6.7
- Update notice: every GitHub release now carries `version.json` (versionCode, versionName, notes from
  `release-notes.txt`). The apps check it (on open, at most every 6 h) and show a "🆕 New version" banner
  + one notification per version; tapping downloads the new APK. Settings has "Check for updates".
- When publishing: bump versionCode/versionName and write one line in `release-notes.txt`.

## v6.8
- Push is now a Firebase *notification* message (plus data): Android shows it itself even when the app is
  closed or the phone blocks background apps. Channel "church_news" is created at start; manifest sets the
  default channel / icon / colour. Polling no longer re-notifies posts whose `pushed` = 200.
- Tapping a system-shown push opens the announcements list. Script: redeploy as a New version.

## v6.9
- Announcements can carry a link (sheet column `link`). YouTube videos / Shorts / live links show a thumbnail
  card with ▶ that opens the YouTube app; other links get an "open" button; URLs inside messages are tappable.
- Admin: 🔗 link field with YouTube detection and preview.
