# Zion Bible Verse — Tamil + English Bible (Android)

Native Android app, Kotlin + Jetpack Compose. Works fully offline.

## Build
1. Open this folder in **Android Studio (Koala 2024.1 or newer)**.
2. Let Gradle sync (JDK 17, downloads Gradle 8.9 / AGP 8.5.2 automatically).
3. Run on a device/emulator, or build an APK:
   ```
   ./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
   ./gradlew assembleRelease      # signed with debug key — swap in your keystore for Play Store
   ```
Min Android 8.0 (API 26).

## Features
- Tamil / English / Both (parallel, Tamil with English beneath) — one tap in the bottom bar
- Swipe left/right through all 1,189 chapters; ‹ › buttons too
- Book list split into Old/New Testament, filter by Tamil or English name, chapter grid
- Search by word (அன்பு, love) or reference (யோவான் 3:16, John 3:16, Ps 23) — jumps and highlights the verse
- Tap verses to select → Copy or Share with reference
- Text size slider, Light / Dark / System theme
- Remembers last chapter, language, size and theme

## Data
- `app/src/main/assets/bible.db` — SQLite built from your `tamil_bible.json`
  plus the King James Version (public domain) for English. All 31,102 verses align 1:1.
  Tables: `books(ord, code, ta, en, testament, chapters)`, `verses(book, chapter, verse, ta, en)`.
- If you rebuild the DB, bump `DB_VERSION` in `BibleRepository.kt` so installed apps re-copy it.

## Fonts
Noto Serif Tamil and Literata (SIL Open Font License), bundled in `res/font`.

## Code map
```
MainActivity.kt          edge-to-edge + theme
BibleViewModel.kt        state, settings (SharedPreferences), page⇄reference, ref parser
data/BibleRepository.kt  SQLite access (copy-from-assets, chapter, search)
ui/BibleApp.kt           screen switching, shared PagerState
ui/ReaderScreen.kt       pager, verse rendering, selection, settings sheet
ui/BooksScreen.kt        testament tabs, book filter, chapter grid
ui/SearchScreen.kt       word + reference search
ui/theme/Theme.kt        colors + font families
```


## v1.1 changes
- Animated Zion Cathedral logo splash screen, then a dashboard with: Old Testament, New Testament,
  ஸ்தோத்திர பலி (placeholder), Settings, Social media, Exit — plus "continue reading" and 24/7 prayer call buttons.
- Default background is white; Settings lets the reader switch to black (or follow the phone).
- Tamil font: Noto Sans Tamil. English font: Literata.
- Launcher icon redrawn from the Zion Cathedral emblem (vector; swap for the official logo when available).
- Church details and social links live in `data/Church.kt` (set the exact YouTube channel URL there).

## v1.2 changes
- "இன்றைய தேவ வார்த்தை" card at the top of the dashboard (read the chapter or share the verse).
- Daily notification with the same verse, default 6:00 AM; on/off and time in Settings.
  Tapping it opens the reader at that verse. Re-armed after reboot/app update.
- Promise-verse list (positive verses only, one per day, changes at midnight, cycling) lives in `data/DailyVerse.kt`.

## v1.5 changes
- ஸ்தோத்திர பலி: numbered praise list with "Go to" number jump; remembers where you stopped.
  The list is plain text in `app/src/main/assets/stothiram.txt` — one praise per line,
  lines starting with `# ` are section titles. Replace/extend it with the church's own list.

## v2.0 changes
- Dashboard fits one screen on any phone (no scrolling): compact header, today's verse,
  continue-reading strip, 3×2 tile grid that stretches to fill, one-line prayer numbers.
- Faint Zion Cathedral logo watermark behind the reader, book list, search, praise and settings pages
  (`ui/BibleBackdrop.kt`, `Modifier.pageBackground()`).
- Promise notifications: up to 15 a day (adjustable 1–15 in Settings) at random times
  between 6 AM and 10 PM; every one shows the same "இன்றைய தேவ வார்த்தை" (the day's verse).

## v2.7 changes
- Today's verse is now different for each install: every phone shuffles the promise list with
  its own random seed (saved once), then shows one verse per day in that order.

## v2.8 changes
- Notifications fixed at 60 a day (6 AM–10 PM, random times, ~every 16 min); the on/off and
  count controls were removed from Settings.
- New high-importance channel with the phone's default notification sound + vibration
  (old channel deleted, since Android doesn't allow changing a channel's sound later).

## v2.9 changes
- Reader: row of chapter numbers under the top bar (current one in red, centred); swipe it and tap to jump.
- Dashboard: "அமைப்பு" tile replaced by "வார்த்தை தேடல்" (word search); Settings stays on the user icon.
- Book list search box now reads "அதிகாரத்தைத் தேடு".
- Black mode: search results and any text without an explicit colour now follow the theme (white).

## v2.9 changes
- Reader: row of chapter numbers under the top bar (current one red, centred); swipe and tap to jump.
- Book list search box now says "அதிகாரத்தைத் தேடு".
- Dashboard: "வார்த்தை தேடல்" tile replaces "அமைப்பு" (Settings is on the profile icon).
- Search: அனைத்தும் / பழைய / புதிய ஏற்பாடு scope, book picker, on-screen Tamil letter keypad.
- Black mode: all default text now follows the theme (search results were black on black).

## v3.0 changes
- Dashboard now has 8 tiles (4 × 2): + பாடல்கள் (Songs) and குறிப்புகள் (Notes).
- Songs: read from `app/src/main/assets/songs.txt` ("## 1. Title", optional "youtube: <link>",
  then lyrics). Searchable list, lyrics view, YouTube button. Add the church's own songs there.
- Notes: personal / sermon notes stored on the phone; in the reader, select verses → "குறிப்பு"
  to start a note with the verse reference and text.

## v3.1 changes
- Reader: the verse actions (குறிப்பு / நகலெடு / பகிர்) are a floating panel that appears only while
  verses are selected — v3.2: small vertical pill on the right, slides down from the top; ✕ last.

## v3.3 changes
- Disclaimer & Privacy Policy (English) in Settings › "Disclaimer & Privacy Policy".
- One-time "Before you begin" notice on first launch (I agree / Read); the notification
  permission is asked only after it. Bump `Legal.VERSION` to show it again after big changes.
- `docs/privacy-policy.html` — the same text as a web page for the Play Store privacy-policy URL
  (publish with GitHub Pages: Settings › Pages › Branch: main, folder: /docs).

## v3.4 changes
- Dashboard: Old/New Testament tiles merged into one "பைபிள்" tile (the book list has both tabs). 7 tiles.

## v3.5 changes
- Exit moved from the dashboard into Settings (with a confirm dialog). Dashboard: 6 tiles, 3 × 2.

## v3.9 changes
- New "நினைவூட்டல்" (Reminders) tile: church programme reminders with sound. Programmes come from
  `app/src/main/assets/church_events.txt` ("title | SUN WED | 19:00" per line, DAILY for every day).
  Each can be switched off; one "remind before" setting (on time / 15 / 30 / 60 min). Re-armed after reboot.
- Dashboard: 7 tiles (4 + 3).

## v4.0 changes
- "நினைவூட்டல்" is now a personal booking calendar (on this phone only, files/bookings.json):
  month view with booked dates in red, tap a date to see what is booked or that it is free,
  "+ முன்பதிவு" to add (title, date, optional time, note, reminder). Saving on a date that
  already has a booking warns and offers "another date". Reminders: 8 PM the day before and
  on the day. Church programmes (church_events.txt) are listed below the calendar.
- Privacy policy updated to mention calendar entries (still stored only on the phone).

## v4.1 changes
- Songs tile removed from the dashboard for now (code kept). Dashboard: 6 tiles, 3 × 2.
